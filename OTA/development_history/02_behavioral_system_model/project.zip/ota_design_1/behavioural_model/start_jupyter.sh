#!/usr/bin/env bash
set -euo pipefail
project_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$project_dir"
exec "$project_dir/.venv/bin/python" -m jupyterlab --no-browser --ServerApp.ip=127.0.0.1 --ServerApp.port="${OTA_JUPYTER_PORT:-8888}" --ServerApp.root_dir="$project_dir" --ServerApp.default_url=/lab/tree/notebooks/SC_OTA_ADC_behavioural_v1.ipynb "$@"
