"""Parameterized SC charge-transfer / OTA / ideal SAR behavioural model.
All SI values internally. This is a reduced model, not a transistor simulation.
"""
from pathlib import Path
import json
import numpy as np
K_B = 1.380649e-23

def load_config(path=None):
    p = Path(path) if path else Path(__file__).resolve().parents[1]/'config.json'
    c=json.loads(p.read_text()); validate(c); return c

def validate(c):
    s=c['sc']; a=c['adc']; se=c['sensor']; o=c['ota']
    if not 0 < s['sample_fraction'] <= 1 or not 0 < s['amplify_fraction'] <= 1 or s['sample_fraction']+s['amplify_fraction'] > 1+1e-12:
        raise ValueError('Phase fractions must be positive with sum <= 1.')
    if s['clock_hz']<=0 or s['feedback_cap_pf_per_branch']<=0 or s['excitation_v']<=0: raise ValueError('Clock, Cf and excitation must be positive.')
    if s['switch_on_resistance_ohm']<0 or any(s[k]<0 for k in ['input_cap_pf_per_branch','input_parasitic_pf_per_branch','explicit_output_load_pf_per_branch']): raise ValueError('Resistance and capacitances cannot be negative.')
    if s['initial_condition'] not in ['reset_to_common_mode','hold_previous']: raise ValueError('Unsupported initial condition.')
    if not isinstance(a['bits'],int) or a['bits']<1 or a['maximum_differential_v']<=a['minimum_differential_v']: raise ValueError('Invalid ADC range or bits.')
    if se['minimum_pf']<=0 or se['maximum_pf']<=se['minimum_pf'] or se['complementary_sum_pf']<=se['maximum_pf']: raise ValueError('Invalid sensor capacitance range.')
    if abs(se['complementary_sum_pf']-2*se['center_pf'])>1e-9: raise ValueError('This symmetric model requires sum=2*Ccenter.')
    if o['unity_gain_hz']<=0 or o['slew_positive_v_per_us_diff']<=0 or o['slew_negative_v_per_us_diff']<=0: raise ValueError('Positive UGF and slew rates required.')
    if not o['cmfb_assumed_ideal']: raise ValueError('Nonideal CMFB has not been implemented; use a transistor/common-mode model.')
    if c['noise']['temperature_k']<=0 or c['noise']['uncorrelated_sample_count']<0 or o['sampled_input_noise_uv_rms_diff']<0: raise ValueError('Invalid noise parameters.')
    p=parameters_unchecked(c)
    if p['sample_time_s']<=0 or p['amplify_time_s']<=0: raise ValueError('Phase overhead consumes the available interval.')
    if p['per_output_half_range_v']<=0: raise ValueError('No output swing within common-mode/headroom limits.')

def parameters_unchecked(c):
    s=c['sc']; cf=s['feedback_cap_pf_per_branch']*1e-12
    cs=c['sensor']['center_pf']*1e-12
    cin=(s['input_cap_pf_per_branch']+s['input_parasitic_pf_per_branch'])*1e-12
    beta=cf/(cf+cs+cin)
    a=10**(c['ota']['gain_db']/20)
    return dict(beta=beta, feedback_cap_f=cf, finite_gain_factor=a*beta/(1+a*beta),
        sample_time_s=s['sample_fraction']/s['clock_hz']-s['sample_overhead_s'],
        amplify_time_s=s['amplify_fraction']/s['clock_hz']-s['amplify_overhead_s'],
        tau_s=1/(2*np.pi*beta*c['ota']['unity_gain_hz']),
        sensitivity_v_per_pf=2*s['excitation_v']*1e-12/cf,
        lsb_v=(c['adc']['maximum_differential_v']-c['adc']['minimum_differential_v'])/(2**c['adc']['bits']),
        approximate_output_load_f=s['explicit_output_load_pf_per_branch']*1e-12+cf*(1-beta),
        per_output_half_range_v=min(c['output_common_mode_v']-c['output_headroom_v'],c['supply_v']-c['output_headroom_v']-c['output_common_mode_v']))

def parameters(c):
    validate(c); return parameters_unchecked(c)

def ideal_transfer(cap_pf,c):
    """Vdiff=Vexc*(Cp-Cn)/Cf. Polarity selected by switch connections."""
    cp=np.asarray(cap_pf,float); cn=c['sensor']['complementary_sum_pf']-cp
    return c['sc']['excitation_v']*(cp-cn)*1e-12/(c['sc']['feedback_cap_pf_per_branch']*1e-12)

def acquired_transfer(cap_pf,c):
    p=parameters(c); cp=np.asarray(cap_pf,float)*1e-12;cn=c['sensor']['complementary_sum_pf']*1e-12-cp
    r=c['sc']['switch_on_resistance_ohm']
    fp=1 if r==0 else -np.expm1(-p['sample_time_s']/(r*cp))
    fn=1 if r==0 else -np.expm1(-p['sample_time_s']/(r*cn))
    return c['sc']['excitation_v']*(cp*fp-cn*fn)/p['feedback_cap_f']

def adc_code(v,c):
    a=c['adc'];levels=2**a['bits'];x=(np.asarray(v)-a['minimum_differential_v'])/(a['maximum_differential_v']-a['minimum_differential_v'])
    return np.clip(np.floor(x*levels),0,levels-1).astype(int)

def sar_adc(v,c):
    """Ideal straight-binary SAR consistent with floor quantization.
    Trial DAC = Vmin + code*Vspan/2**N. No comparator noise or DAC mismatch.
    """
    a=c['adc'];n=a['bits'];v=float(v)
    if v<=a['minimum_differential_v']:return 0
    if v>=a['maximum_differential_v']:return 2**n-1
    result=0
    for bit in range(n-1,-1,-1):
        trial=result | (1<<bit)
        threshold=a['minimum_differential_v']+(a['maximum_differential_v']-a['minimum_differential_v'])*trial/2**n
        if v>=threshold:result=trial
    return result

def evolve(initial,target,time_s,tau_s,sr_pos,sr_neg):
    """Exact evolution of dy/dt=clip((target-y)/tau,-SRneg,SRpos)."""
    t=np.asarray(time_s,float)
    if np.any(t<0):raise ValueError('Negative evolution time.')
    err=float(target-initial); mag=abs(err);sr=sr_pos if err>=0 else sr_neg
    if mag==0:return np.zeros_like(t)+target
    cross=sr*tau_s
    if mag<=cross:return target-err*np.exp(-t/tau_s)
    ts=(mag-cross)/sr
    # Maximum avoids overflow in the unused exponential branch of np.where.
    residual=np.where(t<=ts,mag-sr*t,cross*np.exp(-np.maximum(t-ts,0)/tau_s))
    return target-np.sign(err)*residual

def noise_sigma(cap_pf,c):
    p=parameters(c);cp=np.asarray(cap_pf,float)*1e-12;cn=c['sensor']['complementary_sum_pf']*1e-12-cp
    var=0*cp
    if c['noise']['sample_charge_noise_enabled']:
        var=c['noise']['uncorrelated_sample_count']*K_B*c['noise']['temperature_k']*(cp+cn)/p['feedback_cap_f']**2
        var=var*p['finite_gain_factor']**2
    amp=c['ota']['sampled_input_noise_uv_rms_diff']*1e-6/p['beta']*p['finite_gain_factor']
    return np.sqrt(var+amp**2)

def simulate(cap_pf,c,noise=True,seed=None):
    p=parameters(c);s=c['sc'];o=c['ota'];caps=np.atleast_1d(np.asarray(cap_pf,float))
    if np.any(caps<c['sensor']['minimum_pf']) or np.any(caps>c['sensor']['maximum_pf']):raise ValueError('Sensor outside configured span.')
    ideal=ideal_transfer(caps,c);acq=acquired_transfer(caps,c)
    fg=acq*p['finite_gain_factor']
    offset=o['residual_input_offset_uv_diff']*1e-6/p['beta']*p['finite_gain_factor']
    injection=s['residual_charge_injection_c_diff']/p['feedback_cap_f']*p['finite_gain_factor']
    unconstrained=fg+offset+injection
    limit=2*p['per_output_half_range_v'];target=np.clip(unconstrained,-limit,limit)
    clipped=unconstrained!=target
    initial=[];settled=[];prev=0.
    for goal in target:
        start=(0. if s['initial_condition']=='reset_to_common_mode' else prev)+s['initial_differential_kick_v']
        start=float(np.clip(start,-limit,limit));initial.append(start)
        y=float(evolve(start,goal,p['amplify_time_s'],p['tau_s'],o['slew_positive_v_per_us_diff']*1e6,o['slew_negative_v_per_us_diff']*1e6))
        settled.append(y);prev=y
    settled=np.asarray(settled)
    rng=np.random.default_rng(c['seed'] if seed is None else seed)
    vn=rng.normal(0,noise_sigma(caps,c)) if noise else np.zeros_like(caps)
    before_clip=settled+vn;sampled=np.clip(before_clip,-limit,limit)
    a=c['adc'];overrange=(sampled<a['minimum_differential_v'])|(sampled>a['maximum_differential_v'])
    return dict(cap_pf=caps,ideal_v=ideal,acquired_v=acq,finite_gain_only_v=fg,
        static_target_unclipped_v=unconstrained,static_target_v=target,initial_v=np.asarray(initial),
        deterministic_sample_v=settled,noise_v=vn,sampled_v=sampled,
        acquisition_error_v=acq-ideal,finite_gain_error_v=fg-acq,
        residual_offset_error_v=np.full_like(caps,offset),charge_injection_error_v=np.full_like(caps,injection),
        static_error_v=target-ideal,dynamic_error_v=settled-target,total_analog_error_v=sampled-ideal,
        ota_clipped=clipped| (before_clip!=sampled),adc_overrange=overrange,
        ideal_code=adc_code(ideal,c),actual_code=adc_code(sampled,c),
        voutp_v=c['output_common_mode_v']+sampled/2,voutn_v=c['output_common_mode_v']-sampled/2)

def minimum_ugf_for_step(c,max_step_v,tolerance_v):
    """One-pole/slew screening solver, not transistor stability certification."""
    p=parameters(c);o=c['ota'];time=p['amplify_time_s']
    sr=min(o['slew_positive_v_per_us_diff'],o['slew_negative_v_per_us_diff'])*1e6
    if tolerance_v<=0 or max_step_v<=0:raise ValueError('Positive step and tolerance required.')
    if max_step_v<=tolerance_v:return 0.
    if sr*time<max_step_v-tolerance_v:return None
    def error(f):return abs(max_step_v-float(evolve(0,max_step_v,time,1/(2*np.pi*p['beta']*f),sr,sr)))
    lo,hi=1.,1e12
    if error(hi)>tolerance_v:return None
    for _ in range(90):
        mid=np.sqrt(lo*hi)
        if error(mid)<=tolerance_v:hi=mid
        else:lo=mid
    return hi
