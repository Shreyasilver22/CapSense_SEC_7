from pathlib import Path
import os,json,csv,copy,hashlib,sys
os.environ.setdefault('MPLCONFIGDIR','/tmp/ota_sc_mpl')
import matplotlib
# Keep the notebook's inline backend; use headless plotting for shell runs.
if 'ipykernel' not in sys.modules:
    matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from sc_model import load_config,parameters,simulate,evolve,minimum_ugf_for_step,validate
ROOT=Path(__file__).resolve().parents[1]
plt.rcParams.update({'axes.grid':True,'grid.alpha':.25,'font.size':10,'figure.dpi':130})

def run(root=ROOT, config=None):
    root=Path(root);c=load_config(root/'config.json') if config is None else copy.deepcopy(config);validate(c);p=parameters(c)
    plots=root/'plots';out=root/'results';plots.mkdir(exist_ok=True);out.mkdir(exist_ok=True)
    caps=np.linspace(c['sensor']['minimum_pf'],c['sensor']['maximum_pf'],1001)
    d=simulate(caps,c,noise=False);n=simulate(caps,c,noise=True)
    cols=['cap_pf','ideal_v','acquired_v','static_target_v','deterministic_sample_v','sampled_v','total_analog_error_v','ideal_code','actual_code','voutp_v','voutn_v','ota_clipped','adc_overrange']
    with (out/'transfer.csv').open('w',newline='') as f:
        w=csv.writer(f);w.writerow(cols)
        for row in zip(*(n[k] for k in cols)):w.writerow(row)
    def save(fig,name):
        fig.text(.5,.015,'Behavioural assumption study — not SCL transistor simulation or final specifications',ha='center',fontsize=8,color='#555')
        fig.tight_layout(rect=(0,.05,1,.97))
        fig.savefig(plots/(name+'.png'),dpi=180);fig.savefig(plots/(name+'.pdf'));plt.close(fig)
    f,a=plt.subplots(2,1,figsize=(9,7),sharex=True)
    a[0].plot(caps,d['ideal_v'],label='Ideal differential transfer',ls='--',color='#333')
    a[0].plot(caps,n['sampled_v'],label='Sampled output',color='#1864ab');a[0].set(ylabel='Differential voltage (V)',title='SC charge transfer: 5–10 pF complementary sensor scenario');a[0].legend()
    a[1].plot(caps,n['voutp_v'],label='Vout+',color='#1864ab');a[1].plot(caps,n['voutn_v'],label='Vout−',color='#d9480f');a[1].axhline(c['output_common_mode_v'],color='gray',ls=':',label='Ideal CMFB reference');a[1].set(xlabel='Sensor P capacitance (pF)',ylabel='Per-output voltage (V)');a[1].legend();save(f,'01_charge_transfer')
    f,a=plt.subplots(2,1,figsize=(9,7),sharex=True)
    for bits in [8,10]:
        cc=copy.deepcopy(c);cc['adc']['bits']=bits;rr=simulate(caps,cc)
        ax=a[0 if bits==8 else 1];ax.step(caps,rr['ideal_code'],where='post',label='Ideal',ls='--',color='#333');ax.step(caps,rr['actual_code'],where='post',label='With model errors',color='#1864ab');ax.set(ylabel=f'{bits}-bit code');ax.legend()
    a[0].set_title('Ideal SAR conversion: configurable bit count and differential input range');a[1].set_xlabel('Sensor P capacitance (pF)');save(f,'02_adc_transfer')
    f,a=plt.subplots(2,1,figsize=(9,7),sharex=True)
    for key,label in [('finite_gain_error_v','Finite gain'),('residual_offset_error_v','Residual offset'),('dynamic_error_v','Incomplete settling'),('acquisition_error_v','Incomplete acquisition')]:a[0].plot(caps,d[key]*1e3,label=label)
    a[0].set(ylabel='Error (mV)',title='Analog error decomposition — errors relative to ideal charge transfer');a[0].legend(ncol=2)
    a[1].plot(caps,n['total_analog_error_v']/p['lsb_v'],label='Total incl. one noise realization',color='#1864ab');a[1].plot(caps,d['total_analog_error_v']/p['lsb_v'],label='Deterministic error',color='#d9480f');a[1].axhline(.5,color='gray',ls='--');a[1].axhline(-.5,color='gray',ls='--');a[1].set(xlabel='Sensor P capacitance (pF)',ylabel=f'Error (LSB, {c["adc"]["bits"]}-bit scale)');a[1].legend();save(f,'03_error_budget')
    # Timed amplification response after a worst-case full differential reversal.
    step=c['adc']['maximum_differential_v']-c['adc']['minimum_differential_v'];start=-step/2;target=step/2
    t=np.linspace(0,p['amplify_time_s'],1200);tol=c['error_allocation_lsb']['dynamic_settling']*p['lsb_v']
    f,a=plt.subplots(2,1,figsize=(9,7),sharex=True)
    for fu in [1e6,c['ota']['unity_gain_hz']]:
        y=evolve(start,target,t,1/(2*np.pi*p['beta']*fu),c['ota']['slew_positive_v_per_us_diff']*1e6,c['ota']['slew_negative_v_per_us_diff']*1e6)
        a[0].plot(t*1e6,y,label=f'UGF={fu/1e6:g} MHz');a[1].semilogy(t*1e6,np.maximum(abs(y-target)/p['lsb_v'],1e-8),label=f'{fu/1e6:g} MHz')
    a[0].axhline(target,color='gray',ls='--');a[0].set(ylabel='Differential voltage (V)',title='Full-scale reversal stress test — fixed target, initial output held from previous sample');a[0].legend()
    a[1].axhline(c['error_allocation_lsb']['dynamic_settling'],color='#d9480f',ls='--',label='Illustrative dynamic allowance');a[1].set(xlabel='Time into amplification (µs)',ylabel='Dynamic error (LSB)');a[1].legend();save(f,'04_settling_stress')
    fs=np.geomspace(1e4,1e6,80);fu=np.geomspace(1e5,2e7,90);z=np.zeros((len(fu),len(fs)))
    for i,g in enumerate(fu):
        for j,h in enumerate(fs):
            ta=c['sc']['amplify_fraction']/h-c['sc']['amplify_overhead_s']
            z[i,j]=abs(target-float(evolve(start,target,ta,1/(2*np.pi*p['beta']*g),c['ota']['slew_positive_v_per_us_diff']*1e6,c['ota']['slew_negative_v_per_us_diff']*1e6)))/p['lsb_v']
    f,a=plt.subplots(figsize=(9,6));a.grid(False);v=a.pcolormesh(fs/1e3,fu/1e6,np.log10(np.maximum(z,1e-6)),shading='auto',cmap='viridis');a.set_xscale('log');a.set_yscale('log');f.colorbar(v,ax=a,label='log10(dynamic error / LSB)')
    contour=a.contour(fs/1e3,fu/1e6,z,levels=[c['error_allocation_lsb']['dynamic_settling']],colors='white',linewidths=1.5);a.clabel(contour,fmt=lambda x:f'{x:g} LSB');a.plot(c['sc']['clock_hz']/1e3,c['ota']['unity_gain_hz']/1e6,'rx',ms=10,label='Illustrative default');a.set(xlabel='SC clock (kHz)',ylabel='OTA UGF (MHz)',title='Settling feasibility — fixed β and differential slew rate; excludes static/noise error');a.legend();save(f,'05_clock_bandwidth_tradeoff')
    # Explicit non-overlapping two-phase timing and reset-to-CM waveform.
    seq=np.array([c['sensor']['minimum_pf'],c['sensor']['maximum_pf'],c['sensor']['center_pf']])
    ct=copy.deepcopy(c);ct['sc']['initial_condition']='reset_to_common_mode'
    rd=simulate(seq,ct,noise=False);period=1/c['sc']['clock_hz'];amp_start=c['sc']['sample_fraction']*period
    tt=[];phi1=[];phi2=[];vo=[]
    for k,goal in enumerate(rd['static_target_v']):
        local=np.linspace(0,period,1600,endpoint=False);amp=(local>=amp_start)&(local<amp_start+p['amplify_time_s'])
        response=np.zeros_like(local)
        response[amp]=evolve(rd['initial_v'][k],goal,local[amp]-amp_start,p['tau_s'],c['ota']['slew_positive_v_per_us_diff']*1e6,c['ota']['slew_negative_v_per_us_diff']*1e6)
        response[local>=amp_start+p['amplify_time_s']]=rd['deterministic_sample_v'][k]
        tt.extend(local+k*period);phi1.extend((local<p['sample_time_s']).astype(int));phi2.extend(amp.astype(int));vo.extend(response)
    f,a=plt.subplots(2,1,figsize=(9,7),sharex=True)
    tt=np.array(tt)
    a[0].step(tt*1e6,phi1,where='post',label='Sample / reset',color='#1864ab');a[0].step(tt*1e6,np.array(phi2)+1.4,where='post',label='Amplify (offset for visibility)',color='#d9480f');a[0].set(ylabel='Logic state + plot offset',title='Illustrative SC clock phases and reset-to-common-mode output');a[0].legend()
    a[1].plot(tt*1e6,vo,label='Differential output',color='#1864ab')
    for k,vv in enumerate(rd['deterministic_sample_v']):a[1].plot((k*period+amp_start+p['amplify_time_s'])*1e6,vv,'o',color='#d9480f')
    a[1].set(xlabel='Time (µs)',ylabel='Differential output (V)');a[1].legend();save(f,'06_clock_phases')
    with (out/'clock_bandwidth_sweep.csv').open('w',newline='') as f:
        w=csv.writer(f);w.writerow(['clock_hz','ugf_hz','dynamic_error_lsb'])
        for i,g in enumerate(fu):
            for j,h in enumerate(fs):w.writerow([h,g,z[i,j]])
    cc=copy.deepcopy(c);cc['sc']['initial_condition']='hold_previous'
    sequence=np.tile([c['sensor']['minimum_pf'],c['sensor']['maximum_pf']],100)
    alt=simulate(sequence,cc,noise=False)
    from sc_model import noise_sigma
    sig=float(noise_sigma(np.array([c['sensor']['center_pf']]),c)[0])
    allocations=c['error_allocation_lsb']
    amplitude=step/2;eps=allocations['finite_gain']*p['lsb_v']/amplitude
    a_req=(1/eps-1)/p['beta'];gain_req=20*np.log10(a_req) if a_req>0 else None
    fu_req=minimum_ugf_for_step(c,step,tol)
    sr_lower=(step-tol)/p['amplify_time_s']/1e6
    summary={'status':c['status'],'config_sha256':hashlib.sha256(json.dumps(c,sort_keys=True).encode()).hexdigest(),'parameters':p,
        'deterministic_ramp_peak_abs_error_v':float(np.max(abs(d['total_analog_error_v']))),
        'noisy_ramp_peak_abs_error_v_one_seed':float(np.max(abs(n['total_analog_error_v']))),
        'peak_finite_gain_error_v':float(np.max(abs(d['finite_gain_error_v']))),
        'residual_offset_output_v':float(d['residual_offset_error_v'][0]),
        'reset_mode_peak_dynamic_error_v':float(np.max(abs(d['dynamic_error_v']))),
        'hold_previous_alternating_peak_dynamic_error_v':float(np.max(abs(alt['dynamic_error_v']))),
        'predicted_sampled_noise_sigma_output_v':sig,'predicted_sampled_noise_sigma_input_equiv_fF':sig/p['sensitivity_v_per_pf']*1000,
        'clipped_sample_count':int(np.count_nonzero(n['ota_clipped'])),'adc_overrange_count':int(np.count_nonzero(n['adc_overrange'])),
        'conditional_requirements':{'assumed_dynamic_step_v':step,'assumed_static_signal_amplitude_v':amplitude,'gain_min_db_for_finite_gain_allocation':float(gain_req),'ugf_min_hz_for_dynamic_allocation_at_configured_slew':fu_req,'absolute_slew_lower_bound_v_per_us_diff':sr_lower,'sampled_noise_rms_output_budget_v':allocations['noise_rms']*p['lsb_v']},
        'not_predicted':['Power/energy','Phase margin or higher-order stability','Nonideal CMFB dynamics','True sampled CDS flicker noise','Transistor mismatch','Pressure resolution','SCL transistor performance']}
    (out/'config_used.json').write_text(json.dumps(c,indent=2))
    (out/'summary.json').write_text(json.dumps(summary,indent=2))
    fu_text='not attainable at this slew rate' if fu_req is None else f'{fu_req/1e6:.3f} MHz'
    txt=f'''# Behavioural scenario results\n\nThese are reduced-model calculations, not PDK simulations or frozen requirements.\n\n| Quantity | Calculated value |\n|---|---:|\n| SC clock | {c['sc']['clock_hz']/1e3:.3f} kHz |\n| Sampling interval | {p['sample_time_s']*1e6:.3f} µs |\n| Amplification interval | {p['amplify_time_s']*1e6:.3f} µs |\n| Feedback factor β | {p['beta']:.6f} |\n| C-to-V sensitivity | {p['sensitivity_v_per_pf']:.3f} V/pF |\n| {c['adc']['bits']}-bit LSB | {p['lsb_v']*1e3:.6f} mV |\n| Peak finite-gain error | {summary['peak_finite_gain_error_v']*1e3:.6f} mV |\n| Residual offset at output | {summary['residual_offset_output_v']*1e3:.6f} mV |\n| Deterministic ramp peak error | {summary['deterministic_ramp_peak_abs_error_v']*1e3:.6f} mV |\n| Sampled noise rms (assumed model) | {sig*1e6:.3f} µV |\n| Reset-mode peak dynamic error | {summary['reset_mode_peak_dynamic_error_v']*1e6:.6f} µV |\n| Alternating held-output peak dynamic error | {summary['hold_previous_alternating_peak_dynamic_error_v']*1e6:.3f} µV |\n\nFor the arbitrary {allocations['finite_gain']} LSB finite-gain allocation, conditional gain minimum is {gain_req:.3f} dB. For the arbitrary {allocations['dynamic_settling']} LSB dynamic allocation and {step:g} V reversal at the specified slew rate, the scalar settling solver requires UGF approximately {fu_text}. The absolute slew lower bound is {sr_lower:.3f} V/µs differential, excluding linear-settling margin. The independently configured noise allowance is {allocations['noise_rms']} LSB rms.\n\nThese conditional numbers depend on the assumed sensor/excitation/Cf, phase time, error allocations and first-order model. Actual sampled SC behaviour and CMFB must be verified at transistor level. A full-scale reversal is a stress scenario and differs from the default reset-to-common-mode conversion.\n\nThe ramp's seeded noise maximum is one realization, not a yield bound. ADC code differences near thresholds do not on their own constitute INL/DNL or ENOB measurements. The model does not predict power.\n'''
    (out/'SUMMARY.md').write_text(txt)
    print(txt)
    return summary
if __name__=='__main__':run()
