"""Analytical/limiting-case checks; independent of plotting and source notebook."""
import copy
import numpy as np
from sc_model import *
c=load_config();p=parameters(c)
# The configured charge relation preserves original sensitivity but uses signed differential output.
np.testing.assert_allclose(ideal_transfer([5,7.5,10],c),[-1.65,0,1.65],rtol=1e-12,atol=1e-15)
assert abs(p['sensitivity_v_per_pf']-.66)<1e-12
# SAR must work for multiple bit depths, endpoints and out-of-range inputs.
rng=np.random.default_rng(11)
for bits in [8,10,12]:
 cc=copy.deepcopy(c);cc['adc']['bits']=bits
 vals=rng.uniform(-1.6499,1.6499,200)
 assert np.array_equal([sar_adc(v,cc) for v in vals],adc_code(vals,cc))
 assert sar_adc(-10,cc)==0 and sar_adc(10,cc)==2**bits-1
# Unslewed exact RC exponential and t=0 boundary.
t=np.array([0,1e-6,3e-6])
np.testing.assert_allclose(evolve(0,1,t,1e-6,1e12,1e12),1-np.exp(-t/1e-6),atol=1e-14)
# A current-limited ramp must have the configured slope before handoff, and be continuous.
y=evolve(0,2,np.array([0,1e-6,1.9e-6]),1e-7,1e6,1e6)
np.testing.assert_allclose(y,[0,1,1.9],atol=1e-12)
np.testing.assert_allclose(evolve(0,-2,1e-6,1e-7,1e6,2e6),-1.9264241117657115,atol=1e-12)
# Ideal limits recover charge transfer and independent acquisition limits.
cc=copy.deepcopy(c);cc['ota'].update(gain_db=300,unity_gain_hz=1e10,slew_positive_v_per_us_diff=1e9,slew_negative_v_per_us_diff=1e9,residual_input_offset_uv_diff=0)
cc['sc']['switch_on_resistance_ohm']=0
rr=simulate([5,7.5,10],cc,noise=False)
np.testing.assert_allclose(rr['sampled_v'],rr['ideal_v'],atol=1e-12)
# Error accounting and complementary outputs preserve common mode.
rr=simulate([5,6,9,10],c,noise=False)
np.testing.assert_allclose(rr['static_error_v']+rr['dynamic_error_v'],rr['total_analog_error_v'],atol=1e-14)
np.testing.assert_allclose((rr['voutp_v']+rr['voutn_v'])/2,c['output_common_mode_v'])
slow=copy.deepcopy(c);slow['sc']['switch_on_resistance_ohm']=1e8
assert np.max(abs(acquired_transfer([5,10],slow)))<np.max(abs(ideal_transfer([5,10],slow)))
# Seeded independent sampled-noise process should reproduce specified sigma and zero mean.
rr=simulate(np.full(20000,7.5),c,noise=True)
sigma=float(noise_sigma(np.array([7.5]),c)[0])
assert abs(np.std(rr['noise_v'])/sigma-1)<.03
assert abs(np.mean(rr['noise_v']))<.03*sigma
# No possible UGF can fix an insufficient hard slew ceiling.
cc=copy.deepcopy(c);cc['ota']['slew_positive_v_per_us_diff']=.01
assert minimum_ugf_for_step(cc,3.3,1e-4) is None
cc=copy.deepcopy(c);cc['sc']['clock_hz']=1e12
try:validate(cc)
except ValueError:pass
else:raise AssertionError('Invalid phase timing was accepted.')
print('PASS: charge transfer, 8/10/12-bit SAR, clipping, exponential/slew limits, error accounting, common mode, acquisition, noise statistics, impossible slew and timing validation.')
