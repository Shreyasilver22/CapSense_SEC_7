# Behavioural scenario results

These are reduced-model calculations, not PDK simulations or frozen requirements.

| Quantity | Calculated value |
|---|---:|
| SC clock | 200.000 kHz |
| Sampling interval | 2.450 µs |
| Amplification interval | 2.450 µs |
| Feedback factor β | 0.279799 |
| C-to-V sensitivity | 0.660 V/pF |
| 10-bit LSB | 3.222656 mV |
| Peak finite-gain error | 0.331552 mV |
| Residual offset at output | 0.178664 mV |
| Deterministic ramp peak error | 0.510268 mV |
| Sampled noise rms (assumed model) | 136.530 µV |
| Reset-mode peak dynamic error | 0.052360 µV |
| Alternating held-output peak dynamic error | 73.700 µV |

For the arbitrary 0.125 LSB finite-gain allocation, conditional gain minimum is 83.308 dB. For the arbitrary 0.125 LSB dynamic allocation and 3.3 V reversal at the specified slew rate, the scalar settling solver requires UGF approximately 3.960 MHz. The absolute slew lower bound is 1.347 V/µs differential, excluding linear-settling margin. The independently configured noise allowance is 0.1 LSB rms.

These conditional numbers depend on the assumed sensor/excitation/Cf, phase time, error allocations and first-order model. Actual sampled SC behaviour and CMFB must be verified at transistor level. A full-scale reversal is a stress scenario and differs from the default reset-to-common-mode conversion.

The ramp's seeded noise maximum is one realization, not a yield bound. ADC code differences near thresholds do not on their own constitute INL/DNL or ENOB measurements. The model does not predict power.
