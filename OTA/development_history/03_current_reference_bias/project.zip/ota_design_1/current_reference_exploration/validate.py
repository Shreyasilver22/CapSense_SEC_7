from pathlib import Path
import json,re,subprocess
import numpy as np
R=Path(__file__).resolve().parent
j=json.loads((R/'results/summary.json').read_text());best=j['selected'];d=R/'results/runs'/f"run_{int(best['run']):03d}"
# Validate extracted schematic topology and geometry against the authored core.
s=(R/'results/extracted.spice').read_text()
expected={'M1':'n1 inn tail vss N','M2':'n2 inp tail vss N','M3':'n1 n1 vdd vdd P','M4':'n2 n1 vdd vdd P','M5':'tail iref vss vss N','M6':'out n2 vdd vdd P','M7':'out iref vss vss N','M8':'iref iref vss vss N'}
widths={'M1':10,'M2':10,'M3':10,'M4':10,'M5':20,'M6':28,'M7':40,'M8':20}
for name,nodes in expected.items():
 line=next(x for x in s.splitlines() if x.startswith(name+' ')); assert line.split()[1:6]==nodes.split(),line
 assert f'w={widths[name]}u l=3.2u' in line,line
assert 'Cc out n2 20p' in s
inc='\n'.join(x.replace('**.subckt','.subckt').replace('**.ends','.ends') for x in s.splitlines() if x!='.end')
(R/'designs/extracted.inc').write_text(inc)
net=(d/'ac.cir').read_text().replace(str(R)+'/designs/ota8.inc',str(R)+'/designs/extracted.inc').replace('ota8 LS=4 CC=20p','ota_current_ref').replace('wrdata ac.dat','wrdata extracted_ac.dat')
(R/'results/extracted_check.cir').write_text(net)
p=subprocess.run(['ngspice','-b','-o','extracted_check.log','extracted_check.cir'],cwd=R/'results',capture_output=True,text=True,timeout=30);assert p.returncode==0,p.stdout+p.stderr
assert np.allclose(np.loadtxt(R/'results/extracted_ac.dat',skiprows=1),np.loadtxt(d/'ac.dat',skiprows=1),rtol=1e-6,atol=1e-6)
loads=[]
for cl in [1,5,10]:
 net=(d/'ac.cir').read_text().replace('CL out 0 5p',f'CL out 0 {cl}p').replace('wrdata ac.dat',f'wrdata load_{cl}.dat')
 (R/'results'/f'load_{cl}.cir').write_text(net)
 p=subprocess.run(['ngspice','-b','-o',f'load_{cl}.log',f'load_{cl}.cir'],cwd=R/'results',capture_output=True,text=True,timeout=30);assert p.returncode==0
 a=np.loadtxt(R/'results'/f'load_{cl}.dat',skiprows=1);ix=np.where((a[:-1,1]>=0)&(a[1:,1]<0))[0][0];f=-a[ix,1]/(a[ix+1,1]-a[ix,1]);loads.append(dict(CL_pF=cl,PM_deg=float(180+a[ix,2]+f*(a[ix+1,2]-a[ix,2]))))
# large-step settling: relative to final value, 0.1% of 2 V = 2 mV.
t=np.loadtxt(R/'results/large_step.dat',skiprows=1)
for label,start,end,window in [('rise',10.01e-6,39e-6,(38e-6,39e-6)),('fall',40.02e-6,69e-6,(68e-6,69e-6))]:
 target=np.mean(t[(t[:,0]>window[0])&(t[:,0]<window[1]),2]);mask=(t[:,0]>=start)&(t[:,0]<end);tt=t[mask,0];yy=t[mask,2];bad=np.where(abs(yy-target)>.002)[0];j['large_step'][label+'_settle_0p1pct_us']=float((tt[bad[-1]+1]-start)*1e6) if len(bad) and bad[-1]+1<len(tt) else None
j['load_checks']=loads;j['schematic_verification']='PASS: eight MOS nodes, models and dimensions; capacitor nodes/value; extracted AC matches authored netlist';(R/'results/summary.json').write_text(json.dumps(j,indent=2))
# Copy working project rc and build native follower testbench.
P=Path('/home/berson_meshak/final year project/ota/ota_design_1')
(R/'xschemrc').write_text((P/'xschemrc').read_text())
s=(P/'tb/ota_follower_tb.sch').read_text().replace('ota_scl08.sym','ota_current_ref.sym').replace('lab=vbn','lab=iref').replace('{devices/vsource.sym} 240 600 0 0 {name=VBN value="0.95"}','{devices/isource.sym} 240 600 0 0 {name=IREF value="5u"}').replace('240 570 0 0 {name=l32 sig_type=std_logic lab=iref}','240 570 0 0 {name=l32 sig_type=std_logic lab=vdd}').replace('240 630 0 0 {name=l33 sig_type=std_logic lab=0}','240 630 0 0 {name=l33 sig_type=std_logic lab=iref}').replace('ota_follower_tb.raw','ota_current_ref_tb.raw').replace('.temp 27','.temp 27\n.options reltol=1e-5 vntol=1e-8 abstol=1e-12').replace('tran 20n 120u','tran 5n 120u').replace('Use the ota_scl08 symbol in your switched-capacitor circuit.\nConnect all six pins; keep the external VBN bias supply.','Current-reference candidate: IREF = 5 uA; L = 3.2 um; Cc = 20 pF.\nIREF sources current from VDD into the iref pin; CL = 5 pF.')
(R/'tb/ota_current_ref_tb.sch').write_text(s)
print(json.dumps({k:j[k] for k in ['selected','large_step','load_checks','schematic_verification']},indent=2))
