from pathlib import Path
import csv,json,re,subprocess,hashlib
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parent
rows=list(csv.DictReader((R/'results/sweep.csv').open()))
for r in rows:
 for k,v in r.items(): r[k]=float(v)
valid=[r for r in rows if r['PM_deg']>=60 and r['crossings']==1 and r['minimum_saturation_margin_V']>0 and np.isfinite(r['rise_settle_0p1pct_us']) and np.isfinite(r['fall_settle_0p1pct_us'])]
valid.sort(key=lambda r:(-r['gain_dB'],r['power_uW'],r['Cc_pF']))
best=valid[0]; selected=int(best['run']); d=R/'results/runs'/f'run_{selected:03d}'
# Copy complete selected testbenches with paths relative to tb.
for kind in ['ac','tran']:
 s=(d/f'{kind}.cir').read_text().replace(str(R)+'/designs/ota8.inc','../designs/ota8.inc').replace('wrdata ac.dat','wrdata ../results/selected_ac.dat').replace('wrdata tran.dat','wrdata ../results/selected_tran.dat')
 (R/'tb'/f'selected_{kind}.cir').write_text(s)
 (R/'results'/f'selected_{kind}.dat').write_bytes((d/f'{kind}.dat').read_bytes())
 # large step and finer time resolution check
s=(d/'tran.cir').read_text().replace('dc 2.5 pulse(2.5 2.6','dc 1.5 pulse(1.5 3.5').replace('tran 5n 75u','tran 2n 75u').replace('wrdata tran.dat','wrdata large_step.dat')
(R/'tb/large_step.cir').write_text(s.replace(str(R)+'/designs/ota8.inc','../designs/ota8.inc').replace('wrdata large_step.dat','wrdata ../results/large_step.dat'))
p=subprocess.run(['ngspice','-b','-o','../results/large_step.log','large_step.cir'],cwd=R/'tb',capture_output=True,text=True,timeout=30)
assert p.returncode==0,p.stdout+p.stderr
# Native schematic: exact fixed geometry of selected candidate, separate from baseline.
base=Path('/home/berson_meshak/final year project/ota/ota_design_1/designs/ota_scl08.sch').read_text()
ls=best['L_um']/.8
base=re.sub(r'w=([\d.]+)u l=0.8u',lambda m:f'w={float(m[1])*ls:g}u l={best["L_um"]:g}u',base)
base=base.replace('value=5p',f'value={best["Cc_pF"]:g}p').replace('lab=vbn','lab=iref').replace('{devices/ipin.sym} 200 650 0 0 {name=p_vbn lab=iref}','{devices/lab_pin.sym} 200 650 0 0 {name=p_iref_label lab=iref}')
base=base[:base.index('T {SCL08 two-stage OTA')]+f'''T {{SCL800 current-reference OTA - exploratory candidate}} 0 -20 0 0 0.5 0.5 {{}}
T {{IREF = {best['IREF_uA']:g} uA sourced into iref; L = {best['L_um']:g} um, Cc = {best['Cc_pF']:g} pF.
All widths scaled with length to preserve W/L. External CL = 5 pF.
Seven-transistor core + diode-connected M8. Ideal reference generator remains external.}} 0 850 0 0 0.28 0.28 {{}}
C {{devices/nmos4.sym}} 100 650 0 0 {{name=M8 model=N w={5*ls:g}u l={best['L_um']:g}u m=1}}
N 120 600 120 620 {{lab=iref}}
N 60 600 120 600 {{lab=iref}}
N 60 600 60 650 {{lab=iref}}
N 60 650 80 650 {{lab=iref}}
N 120 560 120 600 {{lab=iref}}
C {{devices/iopin.sym}} 120 560 0 0 {{name=p_iref lab=iref}}
N 120 680 120 740 {{lab=vss}}
C {{devices/lab_pin.sym}} 120 740 0 0 {{name=l12 lab=vss}}
N 120 650 180 650 {{lab=vss}}
C {{devices/lab_pin.sym}} 180 650 2 0 {{name=l13 lab=vss}}
T {{Cc = {best['Cc_pF']:g} pF}} 795 345 0 0 0.3 0.3 {{}}
'''
(R/'designs/ota_current_ref.sch').write_text(base)
sym=Path('/home/berson_meshak/final year project/ota/ota_design_1/designs/ota_scl08.sym').read_text().replace('vbn','iref').replace('name=iref dir=in}', 'name=iref dir=inout}')
(R/'designs/ota_current_ref.sym').write_text(sym)
# Supporting plots
fig,axs=plt.subplots(2,2,figsize=(11,8))
for lsval in [0.8,1.6,2.4,3.2]:
 subset=[r for r in rows if abs(r['L_um']-lsval)<1e-6 and r['IREF_uA']==5]
 axs[0,0].semilogx([r['Cc_pF'] for r in subset],[r['PM_deg'] for r in subset],'-o',label=f'L={lsval:g} um')
axs[0,0].axhline(60,color='k',linestyle='--');axs[0,0].set(xlabel='Cc (pF), IREF=5 uA',ylabel='Phase margin (degrees)');axs[0,0].legend()
a=np.loadtxt(R/'results/selected_ac.dat',skiprows=1)
axs[0,1].semilogx(a[:,0],a[:,1]);axs[0,1].set(xlabel='Frequency (Hz)',ylabel='Gain (dB)',title=f'Selected run {selected}')
t=np.loadtxt(R/'results/selected_tran.dat',skiprows=1)
axs[1,0].plot(t[:,0]*1e6,t[:,1],label='input');axs[1,0].plot(t[:,0]*1e6,t[:,2],label='output');axs[1,0].set(xlabel='Time (us)',ylabel='Voltage (V)',xlim=(9,15));axs[1,0].legend()
t=np.loadtxt(R/'results/large_step.dat',skiprows=1)
axs[1,1].plot(t[:,0]*1e6,t[:,1],label='input');axs[1,1].plot(t[:,0]*1e6,t[:,2],label='output');axs[1,1].set(xlabel='Time (us)',ylabel='Voltage (V)',title='Large-step follower: 1.5 to 3.5 V');axs[1,1].legend()
for ax in axs.flat:ax.grid(alpha=.3)
fig.tight_layout();fig.savefig(R/'plots/selected_candidate.png',dpi=180);fig.savefig(R/'plots/selected_candidate.pdf');plt.close(fig)
summary=dict(total=len(rows),screened=len(valid),selection_rule='highest gain among PM>=60, one descending unity crossing, positive DC saturation margins, finite small-step settling; ties prefer smaller Cc',selected=best,screened_candidates=valid,model_sha256=hashlib.sha256(Path('/home/berson_meshak/pdk/scl08/ngspice_models49/mos/tntp49_5v').read_bytes()).hexdigest(),large_step=dict(low_output_V=float(np.mean(t[(t[:,0]>8e-6)&(t[:,0]<9e-6),2])),high_output_V=float(np.mean(t[(t[:,0]>38e-6)&(t[:,0]<39e-6),2]))))
(R/'results/summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))
