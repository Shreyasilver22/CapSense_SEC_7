from pathlib import Path
import subprocess,itertools,json,csv
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent
for d in ['designs','tb','results/runs','plots']: (ROOT/d).mkdir(parents=True,exist_ok=True)
model='/home/berson_meshak/pdk/scl08/ngspice_models49/mos/tntp49_5v'
core='''* Seven-MOS core plus diode-connected reference transistor M8.
* IREF must source current INTO iref; M8 returns it to vss.
* W/L kept constant as length is swept: increased area is counted.
.subckt ota8 inp inn out vdd vss iref params: LS=1 CC=5p
M1 n1 inn tail vss N W={2.5u*LS} L={0.8u*LS}
M2 n2 inp tail vss N W={2.5u*LS} L={0.8u*LS}
M3 n1 n1 vdd vdd P W={2.5u*LS} L={0.8u*LS}
M4 n2 n1 vdd vdd P W={2.5u*LS} L={0.8u*LS}
M5 tail iref vss vss N W={5u*LS} L={0.8u*LS}
M6 out n2 vdd vdd P W={7u*LS} L={0.8u*LS}
M7 out iref vss vss N W={10u*LS} L={0.8u*LS}
M8 iref iref vss vss N W={5u*LS} L={0.8u*LS}
Cc n2 out {CC}
.ends ota8
'''
(ROOT/'designs/ota8.inc').write_text(core)
rows=[]
for k,(ls,iref,cc) in enumerate(itertools.product([1,2,3,4],[5,15,30,60],[1,2.5,5,10,20,40])):
 d=ROOT/'results/runs'/f'run_{k:03d}'; d.mkdir(exist_ok=True)
 common=f'''SCL800 current-reference exploration {k}
.include "{model}"
.include "{ROOT}/designs/ota8.inc"
.temp 27
.options reltol=1e-5 vntol=1e-8 abstol=1e-12
VDD vdd 0 5
IREF vdd bias {iref}u
CL out 0 5p
XU inp inn out vdd 0 bias ota8 LS={ls} CC={cc}p
'''
 ac=common+'''VIN inp 0 dc 2.5 ac 1
LDC out inn 1e12
CAC inn 0 1e12
.control
set wr_singlescale
set wr_vecnames
op
print v(out) v(bias) i(vdd)
'''+''.join(f'print @m.xu.m{i}[vds] @m.xu.m{i}[vdsat]\n' for i in range(1,9))+'''ac dec 80 1 1G
let gain_db=db(v(out))
let phase_deg=180/PI*cph(v(out))
wrdata ac.dat gain_db phase_deg
quit
.endc
.end
'''
 tr=common+'''VIN inp 0 dc 2.5 pulse(2.5 2.6 10u 10n 10n 30u 60u)
VFB inn out 0
.control
set wr_singlescale
set wr_vecnames
tran 5n 75u
wrdata tran.dat v(inp) v(out) i(vdd)
quit
.endc
.end
'''
 for name,net in [('ac',ac),('tran',tr)]:
  (d/f'{name}.cir').write_text(net)
  p=subprocess.run(['ngspice','-b','-o',f'{name}.log',f'{name}.cir'],cwd=d,capture_output=True,text=True,timeout=30)
  if p.returncode: raise RuntimeError(f'{d} {name} failed: {p.stdout} {p.stderr}')
 a=np.loadtxt(d/'ac.dat',skiprows=1); t=np.loadtxt(d/'tran.dat',skiprows=1)
 gain=a[0,1]; cross=np.where((a[:-1,1]>=0)&(a[1:,1]<0))[0]
 ugf=pm=float('nan')
 if len(cross):
  j=cross[0]; f=-a[j,1]/(a[j+1,1]-a[j,1]); ugf=10**(np.log10(a[j,0])+f*np.log10(a[j+1,0]/a[j,0])); pm=180+a[j,2]+f*(a[j+1,2]-a[j,2])
 def settling(start,end,target):
  mask=(t[:,0]>=start)&(t[:,0]<end); tt=t[mask,0]; yy=t[mask,2]; bad=np.where(abs(yy-target)>.0001)[0]
  return float((tt[bad[-1]+1]-start)*1e6) if len(bad) and bad[-1]+1<len(tt) else (0.0 if not len(bad) else float('nan'))
 low=float(np.mean(t[(t[:,0]>8e-6)&(t[:,0]<9e-6),2])); high=float(np.mean(t[(t[:,0]>38e-6)&(t[:,0]<39e-6),2]))
 log=(d/'ac.log').read_text(); import re
 vals={m.group(1):float(m.group(2)) for m in re.finditer(r'^([^\s=]+)\s*=\s*([-+\d.eE]+)',log,re.M)}
 margins=[abs(vals.get(f'@m.xu.m{i}[vds]',float('nan')))-abs(vals.get(f'@m.xu.m{i}[vdsat]',float('nan'))) for i in range(1,9)]
 row=dict(run=k,L_um=.8*ls,IREF_uA=iref,Cc_pF=cc,gain_dB=gain,UGF_MHz=ugf/1e6,PM_deg=pm,crossings=len(cross),power_uW=-5*vals.get('i(vdd)',float('nan'))*1e6,bias_V=vals.get('v(bias)'),minimum_saturation_margin_V=min(margins),low_error_mV=(low-2.5)*1e3,high_error_mV=(high-2.6)*1e3,rise_settle_0p1pct_us=settling(10.01e-6,39e-6,high),fall_settle_0p1pct_us=settling(40.02e-6,69e-6,low),gate_area_um2=37*.8*ls*ls)
 rows.append(row)
 if k%16==15: print(f'Completed {k+1}/96',flush=True)
with (ROOT/'results/sweep.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
valid=[r for r in rows if r['PM_deg']>=60 and r['crossings']==1 and r['minimum_saturation_margin_V']>0 and np.isfinite(r['rise_settle_0p1pct_us']) and np.isfinite(r['fall_settle_0p1pct_us'])]
valid.sort(key=lambda r:(-r['gain_dB'],r['power_uW']))
(ROOT/'results/summary.json').write_text(json.dumps(dict(total=len(rows),screened=len(valid),highest_gain_screened=valid[:5]),indent=2))
fig,axs=plt.subplots(1,3,figsize=(15,4))
for ax,x,y in zip(axs,['power_uW','UGF_MHz','gate_area_um2'],['gain_dB','PM_deg','gain_dB']):
 sc=ax.scatter([r[x] for r in rows],[r[y] for r in rows],c=[r['L_um'] for r in rows],cmap='viridis'); ax.set_xlabel(x);ax.set_ylabel(y);ax.grid(alpha=.3)
fig.colorbar(sc,ax=list(axs),label='Channel length (um)');fig.savefig(ROOT/'plots/tradeoffs.png',dpi=180,bbox_inches='tight');plt.close(fig)
print(json.dumps(dict(total=len(rows),screened=len(valid),best=valid[:3]),indent=2))
