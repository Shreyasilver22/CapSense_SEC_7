from pvt import *
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:rows=list(ex.map(lambda c:ac(c,10,3.3),configs))
save('output_3p3_stress',rows)
for arch in ['previous6R','stable12R']:
 q=min([x for x in rows if x['arch']==arch and x['status']=='OK'],key=lambda x:x['PM_deg']);print(q,flush=True)
