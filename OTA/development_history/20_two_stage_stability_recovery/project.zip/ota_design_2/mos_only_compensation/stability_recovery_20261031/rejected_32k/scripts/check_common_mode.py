from pvt import *
def ac_fixed_cm(c,cl,vc,vout):
 tag=f'ac_cl{cl}_v{vc}_out{vout}';text=base(c,cl)+f'''VIN inp 0 dc {vc} ac 1
VSHIFT out fbnode {vout-vc}
LDC fbnode inn 1e12
CAC inn 0 1e12
.control
set wr_singlescale
set wr_vecnames
op
print v(out) i(vdd)
ac dec 120 1 1G
let gd=db(v(out))
let pd=180/PI*cph(v(out))
wrdata {tag}.dat gd pd
quit
.endc
.end
'''
 rec=dict(**c,CL_pF=cl,VC_V=vc,output_target_V=vout,status='OK')
 try:
  d,log,code=run(c,tag,text);a=np.loadtxt(d/(tag+'.dat'),skiprows=1);assert code==0 and len(a)>100
  cross=np.where(a[:-1,1]*a[1:,1]<0)[0];pm=ugf=None
  if len(cross)==1:
   z=cross[0];f=-a[z,1]/(a[z+1,1]-a[z,1]);pm=float(180+a[z,2]+f*(a[z+1,2]-a[z,2]));ugf=float(10**(np.log10(a[z,0])+f*np.log10(a[z+1,0]/a[z,0]))/1e6)
  op={k:float(v) for k,v in re.findall(r'^(v\(out\)|i\(vdd\))\s*=\s*([-+\d.eE]+)',log,re.M)}
  rec.update(gain_dB=float(a[0,1]),UGF_MHz=ugf,PM_deg=pm,crossings=len(cross),out_dc_V=op['v(out)'],power_uW=-c['VDD']*op['i(vdd)']*1e6)
 except Exception as e:rec.update(status='FAILED',error=str(e))
 return rec
if __name__=='__main__':
 jobs=[(c,10,1.5,vout) for c in configs for vout in [3.3,3.5]]
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:rows=list(ex.map(lambda x:ac_fixed_cm(*x),jobs))
 save('fixed_input_common_mode',rows)
 for arch in ['previous6R','stable12R']:
  for vout in [3.3,3.5]:
   rr=[x for x in rows if x['arch']==arch and x['output_target_V']==vout and x['status']=='OK'];print(arch,vout,min(rr,key=lambda x:x['PM_deg']),flush=True)
