from pathlib import Path
import re,subprocess,tempfile,json,sys
R=Path(__file__).resolve().parents[1]
tech=Path('/home/berson_meshak/pdk/scl08/analog_pdk/Open_Source_SCL_0.8micron_PDK/open_source_scl_cp8d/open_pdks/scl_cp8d/libs.tech/magic/SCL_CP8D.tech')
s=tech.read_text();start=s.index('cifinput');end=s.index('\nend',start);section=s[start:end]
# Ignore raw mask-marker paint only. Raw mask boolean expressions still derive actual devices and taps.
removed=[]
for name in ['nwell_rev','boron_rev','boron','CONT','respin']:
 pattern=r'(?m)^layer '+name+r' .*?(?=^layer |^calma |\Z)'
 section,n=re.subn(pattern,'',section,flags=re.S);assert n==1,(name,n);removed.append(name)
s=s[:start]+section+s[end:]
# Include resistor body paint in the existing poly area/perimeter capacitance rules.
s=s.replace('allpolynonfet    *poly','allpolynonfet    *poly,*mrp1,*mrp2')
with tempfile.TemporaryDirectory(prefix='scl08_extract_') as tmp:
 p=Path(tmp)/'SCL_CP8D.tech';p.write_text(s)
 q=subprocess.run(['/tmp/magic_ota_tool/bin/magic','-dnull','-noconsole','-norcfile','-T',str(p),('extract_C_only.tcl' if '--cap-only' in sys.argv else 'extract.tcl')],cwd=R/'pex',capture_output=True,text=True)
 (R/('pex/extract_C_only.log' if '--cap-only' in sys.argv else 'pex/extract_import_filtered.log')).write_text(q.stdout+q.stderr);assert q.returncode==0
(R/'pex/import_filter.json').write_text(json.dumps({'raw_marker_paint_omitted':removed,'purpose':'Prevent non-electrical mask marker types overwriting electrical well/active planes during Magic CIF import; device/tap boolean masks unchanged. Extraction-only adaptation; not a foundry-qualified deck.'},indent=2))
print('Extraction completed')
