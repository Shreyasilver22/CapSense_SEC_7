from pvt import *
def ac_fixed_cm(c,cl,vc,vout):
 tag=f'ac_cl{cl}_v{vc}_out{vout}';text=base(c,cl)+f'''VIN inp 0 dc {vc} ac 1
VSHIFT out fbnode {vout-vc}
LDC fbnode inn 1e12
CAC inn 0 1e12
.control
set wr_singlescale
set wr_vecnames
op
print v(out) i(vdd)
ac dec 120 1 1G
let gd=db(v(out))
let pd=180/PI*cph(v(out))
wrdata {tag}.dat gd pd
quit
.endc
.end
'''
 rec=dict(**c,CL_pF=cl,VC_V=vc,output_target_V=vout,status='OK')
 try:
  d,log,code=run(c,tag,text);a=np.loadtxt(d/(tag+'.dat'),skiprows=1);assert code==0 and len(a)>100
  cross=np.where(a[:-1,1]*a[1:,1]<0)[0];pm=ugf=None;crossing_details=[]
  for z in cross:
   f=-a[z,1]/(a[z+1,1]-a[z,1]);freq=float(10**(np.log10(a[z,0])+f*np.log10(a[z+1,0]/a[z,0]))/1e6);margin=float(180+a[z,2]+f*(a[z+1,2]-a[z,2]));crossing_details.append(dict(UGF_MHz=freq,PM_deg=margin,direction='down' if a[z,1]>0 else 'up'))
  if crossing_details:
   pm=min(x['PM_deg'] for x in crossing_details);ugf=max(x['UGF_MHz'] for x in crossing_details if x['direction']=='down')
  loop=10**(a[:,1]/20)*np.exp(1j*a[:,2]*np.pi/180);closed=np.r_[loop,np.conj(loop[::-1]),loop[:1]];q=1+closed;winding=float(np.sum(np.angle(q[1:]/q[:-1]))/(2*np.pi))
  op={k:float(v) for k,v in re.findall(r'^(v\(out\)|i\(vdd\))\s*=\s*([-+\d.eE]+)',log,re.M)}
  rec.update(gain_dB=float(a[0,1]),UGF_MHz=ugf,PM_deg=pm,crossings=len(cross),crossing_details=crossing_details,nyquist_winding=winding,high_frequency_gain_dB=float(a[-1,1]),out_dc_V=op['v(out)'],power_uW=-c['VDD']*op['i(vdd)']*1e6)
 except Exception as e:rec.update(status='FAILED',error=str(e))
 return rec
if __name__=='__main__':
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:rows=list(ex.map(lambda x:ac_fixed_cm(*x),[(c,10,1.5,v) for c in configs for v in [3.3,3.5]]))
 save('fixed_input_common_mode',rows)
 print(min((x for x in rows if x['status']=='OK'),key=lambda x:x['PM_deg']))
