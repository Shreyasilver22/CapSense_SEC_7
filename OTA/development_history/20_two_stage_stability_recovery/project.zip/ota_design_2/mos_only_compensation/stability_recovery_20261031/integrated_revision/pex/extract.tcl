crashbackups stop
drc off
gds read ../layout/ota_design2_mos.gds
load ota_design2_mos
select top cell
extresist threshold 0
extresist minres 10
extresist mindelay 0
extract do resistance
extract all
ext2spice default
ext2spice format ngspice
ext2spice scale off
ext2spice cthresh 0
ext2spice resistor tee on
ext2spice extresist on
ext2spice subcircuits top on
ext2spice -o ota_extracted.spice
quit -noprompt
