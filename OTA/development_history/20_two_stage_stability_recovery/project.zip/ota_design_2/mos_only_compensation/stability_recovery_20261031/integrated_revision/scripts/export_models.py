from pathlib import Path
import re,shlex,json,subprocess
R=Path(__file__).resolve().parents[1]
# Export resistor tee networks from actual extractor device records. Native ext2spice emits
# only one half for this PDK's rsubckt type when resistor-tee mode is enabled.
raw=[shlex.split(s) for s in (R/'pex/ota_design2_mos.ext').read_text().splitlines()]
scale=next(float(x[3])*1e-8 for x in raw if x and x[0]=='scale')
dev=[x for x in raw if x[:3]==['device','rsubckt','RPP']];assert len(dev)==10
rr=[]
for k,x in enumerate(dev):
 l=float(x[7].split('=')[1])*scale;w=float(x[8].split('=')[1])*scale
 for side,a,b in [('A',x[13],x[10]),('B',x[10],x[16])]:rr.append(f'XR{k}{side} {a} {b} RPP W={w:.12g} L={l/2:.12g}')
for src,label in [('ota_C_only.spice','integrated_C'),('ota_extracted.spice','integrated_RC_diagnostic')]:
 s=(R/'pex'/src).read_text();ls=[]
 for line in s.splitlines():
  if line.startswith('X') and ' RPP ' in line:continue
  if line.lower().startswith('.ends'):ls+=rr
  if line.startswith('M'):line=re.sub(r'\s([np])\s',lambda m:' '+m[1].upper()+' ',line)
  ls.append(line)
 (R/f'models/{label}.spice').write_text('\n'.join(ls)+'\n')
# Make a resistor-contracted topology view of each model for independent LVS.
for label in ['integrated_C','integrated_RC_diagnostic']:
 s=(R/f'models/{label}.spice').read_text();parent={}
 def root(a):
  parent.setdefault(a,a)
  if parent[a]!=a:parent[a]=root(parent[a])
  return parent[a]
 for line in s.splitlines():
  a=line.split()
  if a and a[0].startswith('R'):parent[root(a[2])]=root(a[1])
 groups={}
 for n in list(parent):groups.setdefault(root(n),[]).append(n)
 ren={}
 for v in groups.values():
  pick=next((n for n in ['INP','INN','OUT','VDD','VSS','IREF'] if n in v),min(v,key=len))
  ren.update({n:pick for n in v})
 out=[]
 for line in s.splitlines():
  a=line.split()
  if not a:continue
  if a[0].startswith(('R','C')):continue
  if a[0].startswith('M'):a[1:5]=[ren.get(n,n) for n in a[1:5]];line=' '.join(a)
  if a[0].startswith('X') and 'RPP' in a:
   w=float(next(t[2:] for t in a if t.startswith('W=')));l=float(next(t[2:] for t in a if t.startswith('L=')));line=f'R{a[0]} {ren.get(a[1],a[1])} {ren.get(a[2],a[2])} {28*l/w:.12g} RPP'
  out.append(line)
 (R/f'schematic/{label}.cdl').write_text('\n'.join(out)+'\n')
 deck='/home/berson_meshak/pdk/scl08/analog_pdk/Open_Source_SCL_0.8micron_PDK/open_source_scl_cp8d/open_pdks/scl_cp8d/libs.tech/klayout/tech/lvs/lvs_os_scl_cp8d.lvs'
 p=subprocess.run(['klayout','-b','-r',deck,'-rd',f'input={R}/layout/ota_design2_mos.gds','-rd',f'schematic1={R}/schematic/{label}.cdl','-rd',f'report={R}/verification/{label}.lvsdb','-rd',f'target_netlist1={R}/verification/{label}.cir'],capture_output=True,text=True)
 (R/f'verification/{label}.log').write_text(p.stdout+p.stderr);print(label,p.returncode,'MATCH' if 'Netlists match.' in p.stdout else 'MISMATCH')
 if label=='integrated_C':assert p.returncode==0 and 'Netlists match.' in p.stdout,p.stdout+p.stderr
nodecaps={x[1]:float(x[3])*1e-18 for x in raw if x and x[0]=='node'}
(R/'verification/resistor_export.json').write_text(json.dumps({'body_segments':len(dev),'tee_half_instances':len(rr),'body_ground_cap_total_F':sum(nodecaps[x[10]] for x in dev),'export':'Both half-resistors explicitly emitted from .ext terminals/geometry; native ext2spice rsubckt tee output drops the second half. Topology independently compared in KLayout.','limits':'RPP body capacitance uses an extraction-only poly alias extension; not foundry-qualified. Full resistor/substrate-network RC remains diagnostic.'},indent=2))
