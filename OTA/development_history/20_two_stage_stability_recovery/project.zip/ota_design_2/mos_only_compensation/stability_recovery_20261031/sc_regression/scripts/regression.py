from simulate import *
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:rows=list(ex.map(lambda x:run(*x),[(sw,'actual',f,0,5) for sw in ['ideal','tg'] for f in [50000,100000,200000]]))
(R/'summary.json').write_text(json.dumps(rows,indent=2))
for x in rows:print(x['name'],x['last_out_V'],x['max_sample_error_mV'])
