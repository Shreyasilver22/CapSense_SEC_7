from screen import *
rows=[]
for current in [3.5,5,6]:
 key=f'n12_g4_r2_i{current}';(R/f'models/{key}.spice').write_text((R/'models/n12_g4_r2.spice').read_text());c=dict(key=key,Ncap=12,M6scale=4,Rscale=2,I_uA=current)
 rows.append(ac(c))
 for vo,vcm,tag in [(3.3,1.5,'worst_fixed3p3'),(3.5,1.5,'worst_fixed3p5'),(3.5,3.5,'worst_follower')]:rows.append(ac(c,'wnwp49_5v',4.5,85,'best',vcm,vo,10,tag))
save('current_screen',rows);print(json.dumps(rows,indent=2))
