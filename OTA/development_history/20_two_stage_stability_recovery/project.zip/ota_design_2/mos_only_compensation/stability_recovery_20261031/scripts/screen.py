from pathlib import Path
import re,json,itertools,subprocess,concurrent.futures,csv
import numpy as np
R=Path(__file__).resolve().parents[1];source=(R/'models/baseline.spice').read_text()
# Native RPP and MOS geometry changes; old routing kept for sizing screening.
cases=[]
for nn,gm,rf in itertools.product([6,9,12],[1,2,4],[1,1.5,2,3,4]):
 key=f'n{nn}_g{gm}_r{rf}';ls=[]
 for line in source.splitlines():
  a=line.split()
  if a and a[0].startswith('M'):
   if 'l=10u' in line.lower():line+=f' m={nn/6}'
   elif 'w=28u l=3.2u' in line.lower():line+=f' m={gm}'
  if a and a[0].startswith('XR') and 'RPP' in a:
   line=re.sub(r'L=([\deE+.-]+)',lambda m:f'L={float(m[1])*rf:.12g}',line)
  if a and a[0].startswith('C') and len(a)>=4 and a[2]=='0' and re.fullmatch(r'a_80000_\d+#',a[1]):
   # Predicted resistor-body ground loading scales with segment length; re-extraction required.
   match=re.fullmatch(r'([\d.eE+-]+)([fpnum]?)',a[3]);a[3]=f'{float(match[1])*rf:.12g}'+match[2];line=' '.join(a)
  ls.append(line)
 (R/f'models/{key}.spice').write_text('\n'.join(ls)+'\n');cases.append(dict(key=key,Ncap=nn,M6scale=gm,Rscale=rf))
def ac(case,mos='tntp49_5v',vdd=5,temp=27,rc='typ',vcm=2.5,vo=2.5,cl=5,tag='nominal'):
 key=case['key'];d=R/'results'/key;d.mkdir(exist_ok=True);name=tag
 text=f'''Stability recovery screening {key} {tag}
.include "/home/berson_meshak/pdk/scl08/ngspice_models49/mos/{mos}"
.include "/home/berson_meshak/pdk/scl08/ngspice_models49/res/{rc}/ppr"
.include "{R}/models/{key}.spice"
.temp {temp}
.options reltol=1e-5 vntol=1e-8 abstol=1e-12 numdgt=12
VDD vdd 0 {vdd}
IREF vdd bias {case.get('I_uA',3.5)}u
VIN inp 0 dc {vcm} ac 1
VSHIFT out fbnode {vo-vcm}
LDC fbnode inn 1e12
CAC inn 0 1e12
CL out 0 {cl}p
XU inp inn out vdd 0 bias ota_design2_mos
.control
set wr_singlescale
set wr_vecnames
op
print v(out) v(xu.a_76400_312800#) i(vdd)
ac dec 120 1 1G
let gd=db(v(out))
let pd=180/PI*cph(v(out))
wrdata {tag}.dat gd pd
quit
.endc
.end
''';(d/f'{name}.cir').write_text(text);p=subprocess.run(['ngspice','-b','-o',name+'.log',name+'.cir'],cwd=d,capture_output=True,text=True,timeout=60);assert p.returncode==0
 a=np.loadtxt(d/f'{tag}.dat',skiprows=1);ix=np.where(a[:-1,1]*a[1:,1]<0)[0];pm=None;ugf=None
 if len(ix)==1:
  z=ix[0];f=-a[z,1]/(a[z+1,1]-a[z,1]);ugf=float(10**(np.log10(a[z,0])+f*np.log10(a[z+1,0]/a[z,0]))/1e6);pm=float(180+a[z,2]+f*(a[z+1,2]-a[z,2]))
 log=(d/f'{name}.log').read_text();op={k:float(v) for k,v in re.findall(r'^(v\(out\)|v\(xu.a_76400_312800#\)|i\(vdd\))\s*=\s*([-+\d.eE]+)',log,re.M)}
 return dict(**case,tag=tag,mos=mos,VDD=vdd,temp=temp,res=rc,VCM=vcm,VOUT=vo,CL_pF=cl,gain_dB=float(a[0,1]),UGF_MHz=ugf,PM_deg=pm,crossings=len(ix),out_V=op.get('v(out)'),power_uW=-vdd*op['i(vdd)']*1e6,gate_body_V=op.get('v(xu.a_76400_312800#)',0)-op.get('v(out)',0))
def save(name,rows):
 (R/f'{name}.json').write_text(json.dumps(rows,indent=2))
 if rows:
  with (R/f'{name}.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=list(dict.fromkeys(k for x in rows for k in x)));w.writeheader();w.writerows(rows)
if __name__=='__main__':
 jobs=[]
 for c in cases:
  jobs.append((c,))
  for vo,vcm,tag in [(3.3,1.5,'worst_fixed3p3'),(3.5,1.5,'worst_fixed3p5'),(3.5,3.5,'worst_follower')]:jobs.append((c,'wnwp49_5v',4.5,85,'best',vcm,vo,10,tag))
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:rows=list(ex.map(lambda args:ac(*args),jobs))
 save('screening',rows);out=[]
 for c in cases:
  rr=[x for x in rows if x['key']==c['key']];nom=next(x for x in rr if x['tag']=='nominal');m=min(x['PM_deg'] if x['PM_deg'] is not None else -999 for x in rr)
  out.append(dict(**c,nominal_UGF_MHz=nom['UGF_MHz'],minimum_screen_PM=m,power_uW=nom['power_uW']))
 save('screen_candidates',out);print(json.dumps(sorted(out,key=lambda x:-x['minimum_screen_PM']),indent=2))
