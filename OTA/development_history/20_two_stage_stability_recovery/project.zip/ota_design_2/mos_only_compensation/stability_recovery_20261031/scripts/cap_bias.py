from pathlib import Path
import subprocess,json,numpy as np
R=Path(__file__).resolve().parents[1];rows=[]
for name,mos,temp,vgb in [('nominal','tntp49_5v',27,1.188),('worst_same_bias','wnwp49_5v',85,1.188),('worst_3p3','wnwp49_5v',85,-.360),('worst_3p5','wnwp49_5v',85,-.562)]:
 s=f'''MOS compensation incremental capacitance {name}
.include "/home/berson_meshak/pdk/scl08/ngspice_models49/mos/{mos}"
.temp {temp}
VG gate 0 dc {vgb} ac 1
MC 0 gate 0 0 P W=20u L=10u M=6
.control
set wr_singlescale
set wr_vecnames
ac lin 1 1Meg 1Meg
let cc=-imag(i(VG))/(2*PI*frequency)
wrdata {name}_cap.dat cc
quit
.endc
.end
''';p=R/f'results/{name}_cap.cir';p.write_text(s);q=subprocess.run(['ngspice','-b','-o',name+'_cap.log',p.name],cwd=p.parent,capture_output=True,text=True);assert q.returncode==0;a=np.loadtxt(p.parent/(name+'_cap.dat'),skiprows=1);rows.append(dict(case=name,mos=mos,temp=temp,Vgb=vgb,C_pF=float(a[1])*1e12))
(R/'cap_bias.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows,indent=2))
