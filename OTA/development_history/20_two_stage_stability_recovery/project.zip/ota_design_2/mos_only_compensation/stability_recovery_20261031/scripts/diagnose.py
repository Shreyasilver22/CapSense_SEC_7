from pathlib import Path
import subprocess,json,re
R=Path(__file__).resolve().parents[1];src=Path('/home/berson_meshak/final year project/ota/ota_design_2/mos_only_compensation/integrated_rpp_pvt_20261031/models/integrated_C.spice');(R/'models/baseline.spice').write_text(src.read_text());out=[]
for label,mos,vdd,temp,vo in [('nominal','tntp49_5v',5,27,2.5),('low_supply_high_output','wnwp49_5v',4.5,85,3.5),('sc_output_corner','wnwp49_5v',4.5,85,3.3)]:
 text=f'''Bias diagnosis {label}
.include "/home/berson_meshak/pdk/scl08/ngspice_models49/mos/{mos}"
.include "/home/berson_meshak/pdk/scl08/ngspice_models49/res/typ/ppr"
.include "{R}/models/baseline.spice"
.temp {temp}
VDD vdd 0 {vdd}
IREF vdd bias 3.5u
VIN inp 0 1.5
VSHIFT out inn {vo-1.5}
XU inp inn out vdd 0 bias ota_design2_mos
.control
op
print v(out) v(xu.a_76400_258800#) v(xu.a_76400_312800#) i(vdd)
print @m.xu.m1003[vgs] @m.xu.m1003[vds] @m.xu.m1003[vdsat] @m.xu.m1003[gm]
quit
.endc
.end
''';(R/f'results/{label}.cir').write_text(text);p=subprocess.run(['ngspice','-b','-o',f'{label}.log',f'{label}.cir'],cwd=R/'results',capture_output=True,text=True);assert p.returncode==0;log=(R/f'results/{label}.log').read_text();print(label,log[log.find('No. of Data Rows'):],flush=True)
