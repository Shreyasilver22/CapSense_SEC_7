from pathlib import Path
import json,hashlib,re,subprocess
import numpy as np,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,Patch
R=Path(__file__).resolve().parents[1];D=R/'integrated_revision';OLD=Path('/home/berson_meshak/final year project/ota/ota_design_2/mos_only_compensation/integrated_rpp_pvt_20261031');O=json.loads((OLD/'comparison_summary.json').read_text())['integrated6R'];a=json.loads((D/'pvt_ac.json').read_text());t=json.loads((D/'pvt_transients.json').read_text());n=json.loads((D/'pvt_noise.json').read_text());cm=json.loads((D/'fixed_input_common_mode.json').read_text());stress=json.loads((D/'output_3p3_stress.json').read_text())
def nominal(x):return x['mos']=='tntp49_5v' and x['VDD']==5 and x['temp']==27 and x['res']=='typ'
rr=[x for x in a if x['arch']=='stable12R'];assert len(rr)==675 and all(x['status']=='OK' and x['PM_deg'] is not None for x in rr)
assert min(x['PM_deg'] for x in rr)>=60
assert all(abs(x['nyquist_winding'])<.01 and x['high_frequency_gain_dB']<-40 for x in rr)
assert all(x['status']=='OK' and x['PM_deg']>=60 for x in cm+stress)
nom=next(x for x in rr if nominal(x) and x['CL_pF']==5 and x['VC_V']==2.5);step=next(x for x in t if x['arch']=='stable12R' and nominal(x) and x['large'] and x['CL_pF']==10 and x['dt_ns']==1);no=next(x for x in n if x['arch']=='stable12R' and nominal(x));worst=min(rr,key=lambda x:x['PM_deg']);fixed33=min([x for x in cm if x['output_target_V']==3.3],key=lambda x:x['PM_deg'])
result=dict(previous=O,updated_nominal=nom,updated_worst_main=worst,updated_fixed_input_1p5_output3p3_worst=fixed33,updated_step=step,updated_noise=no,main_cases=675,multiple_crossing_cases=sum(x['crossings']>1 for x in rr),all_crossing_min_PM_deg=min(x['PM_deg'] for x in rr),numeric_nyquist_max_abs_winding=max(abs(x['nyquist_winding']) for x in rr),fixed_CM_cases=len(cm),follower_3p3_cases=len(stress),noise_cases=len(n),transient_cases=len(t),layout_area_mm2=364.1*502.2/1e6,qualification='Model-based corner recovery, not foundry signoff. Full-RC substrate errors and MOS/noise translation warnings remain. Transients selected only, not exhaustive PVT.')
(R/'comparison.json').write_text(json.dumps(result,indent=2))
fig,axs=plt.subplots(2,2,figsize=(13,9))
for arch,root,key,label in [('integrated6R',OLD,'integrated6R','Previous: 6 caps, M6 W112, R16k'),('stable12R',D,'stable12R','Updated: 12 caps, M6 W448, R28k')]:
 p=root/'results'/f'{key}_tntp49_5v_5_27_typ';ac=np.loadtxt(p/'ac_cl5_v2.5.dat',skiprows=1);tr=np.loadtxt(p/'tran_large_cl10_1ns.dat',skiprows=1);axs[0,0].semilogx(ac[:,0],ac[:,1],label=label);axs[0,1].plot(tr[:,0]*1e6,tr[:,2],label=label)
 data=json.loads((root/'pvt_ac.json').read_text());vals=[min(x['PM_deg'] for x in data if x['arch']==arch and x['status']=='OK' and x['PM_deg'] is not None and x['VDD']==v) for v in [4.5,5,5.5]];axs[1,0].plot([4.5,5,5.5],vals,'-o',label=label)
 p=root/'results'/f'{key}_wnwp49_5v_4.5_85_best';ac=np.loadtxt(p/'ac_cl10_v3.5.dat',skiprows=1);axs[1,1].semilogx(ac[:,0],ac[:,2],label=label)
axs[0,0].set(xlim=(1e3,1e8),xlabel='Frequency (Hz)',ylabel='Gain (dB)',title='Nominal CL=5 pF, DC=2.5 V');axs[0,1].set(xlim=(9.5,18),xlabel='Time (us)',ylabel='Output (V)',title='Nominal 2 V follower step at 10 pF');axs[1,0].axhline(60,color='k',ls=':');axs[1,0].set(xlabel='Supply (V)',ylabel='Minimum checked PM (degrees)',title='All process/resistor/temperature/load/bias points');axs[1,1].set(xlim=(1e4,1e8),xlabel='Frequency (Hz)',ylabel='Phase (degrees)',title='Former bad corner: 4.5 V, 85 C, wnwp, best R, 3.5 V, 10 pF')
for ax in axs.flat:ax.grid(alpha=.25);ax.legend(fontsize=7)
fig.tight_layout();fig.savefig(R/'plots/stability_recovery.png',dpi=170);fig.savefig(R/'plots/stability_recovery.pdf')
subprocess.run(['klayout','-b','-r',str(D/'scripts/export_geometry.py')],capture_output=True,check=True);data=json.loads((D/'verification/geometry.json').read_text());colors={1:'#ac87cc',3:'#d7c6e3',2:'#53b966',5:'#ffcda0',6:'#f8b56a',4:'#dc5454',8:'#5599dd',10:'#d3bc40',7:'#272727',9:'#7c512d',44:'#dd8822',36:'#777777'}
fig,ax=plt.subplots(figsize=(8,11))
for layer in [3,1,5,6,2,4,44,36,8,10,7,9]:
 for la,x1,y1,x2,y2 in data:
  if la==layer:ax.add_patch(Rectangle((x1,y1),x2-x1,y2-y1,facecolor=colors[layer],edgecolor=colors[layer],alpha=.65,linewidth=.1))
ax.set(xlim=(-5,380),ylim=(-8,520),xlabel='x (um)',ylabel='y (um)',title='Stability-first integrated OTA\n16 output-PMOS fingers, 12 MOS-cap units, 28k RPP');ax.set_aspect('equal');fig.tight_layout();fig.savefig(R/'plots/stable_layout.png',dpi=170);fig.savefig(R/'plots/stable_layout.pdf')
# Portable nominal testbench, exact new model and native PDK references.
for name,tag in [('large_10p','tran_large_cl10_1ns'),('small_10p','tran_small_cl10_5ns')]:
 p=D/'results/stable12R_tntp49_5v_5_27_typ';s=(p/(tag+'.cir')).read_text().replace(str(D)+'/models/','../models/').replace('wrdata '+tag+'.dat','wrdata '+name+'.dat');(D/'tb'/(name+'.cir')).write_text(s)
(D/'verification/final_status.json').write_text(json.dumps(dict(DRC='0 markers',LVS='MATCH',core_extraction_C_topology='MATCH',RC_contracted_topology='MATCH; substrate-network extraction remains diagnostic',pvt_phase_margin='All 675 main-grid and 405 extra bias AC cases >=60 degrees',noise='Simulation only; not qualified',main_multiple_crossings=result['multiple_crossing_cases'],Nyquist='No sampled -1 encirclement; assumes open-loop stability; not a formal all-frequency proof'),indent=2))
(R/'hashes.json').write_text(json.dumps({str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [D/'layout/ota_design2_mos.gds',D/'models/integrated_C.spice',D/'models/integrated_RC_diagnostic.spice',D/'schematic/reference.cdl']},indent=2));print(json.dumps(result,indent=2))
