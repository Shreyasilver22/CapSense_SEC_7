from engine import *
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
summary=json.loads((R/'all_candidates.json').read_text());save('all_candidates',summary)
best=min([x for x in summary if x['min_PM_deg']>=65 and x.get('large_10p_us') is not None],key=lambda x:x['large_10p_us']);baseline=next(x for x in summary if x['N']=='9_r0')
j=dict(selected=best,baseline=baseline,scope='Compensation modification simulated. Class AB, cascoded first stage and fully differential CMFB are proposals only. Fixed v3 routing C; ideal series resistor; physical resistor/layout/noise remain unverified.')
(R/'selection.json').write_text(json.dumps(j,indent=2));print(json.dumps(j,indent=2));print('stress',(R/'stress.json').read_text());print('fine',(R/'fine.json').read_text())
fig,axs=plt.subplots(1,3,figsize=(15,4.5))
for x,label in [(baseline,'Direct MOS compensation'),(best,'Series-R MOS compensation')]:
 d=R/f"results/n{x['N']}_i3.5";a=np.loadtxt(d/'ac_cl5_v2.5_ex0/ac.dat',skiprows=1);t=np.loadtxt(d/'tran_large_cl10_5ns/tran.dat',skiprows=1);axs[0].semilogx(a[:,0],a[:,1],label=label);axs[1].semilogx(a[:,0],a[:,2],label=label);axs[2].plot(t[:,0]*1e6,t[:,2],label=label)
axs[0].set(xlim=(1e3,1e8),xlabel='Frequency (Hz)',ylabel='Gain (dB)');axs[1].set(xlim=(1e4,1e8),xlabel='Frequency (Hz)',ylabel='Phase (degrees)');axs[2].set(xlim=(9.5,16),xlabel='Time (us)',ylabel='Output (V)',title='2 V follower step into 10 pF')
for ax in axs:ax.grid(alpha=.25);ax.legend(fontsize=8)
fig.suptitle('Same 3.5 uA reference current; fixed previous routing-capacitance model');fig.tight_layout();fig.savefig(R/'plots/compensation_comparison.png',dpi=170);fig.savefig(R/'plots/compensation_comparison.pdf')
for label,x in [('baseline',baseline),('selected',best)]:
 d=R/f"results/n{x['N']}_i3.5";s=(d/'tran_large_cl10_5ns/tran.cir').read_text().replace(str(R)+'/models/','../models/').replace('wrdata tran.dat',f'wrdata {label}.dat');(R/'tb'/f'{label}.cir').write_text(s)
