from engine import *
from transient import tran
pairs=list(itertools.product([6,7,8,9],[0,1000,2000,4000,8000,16000]))
keys=[]
for n,rz in pairs:
 s=(R/f'models/n{n}.spice').read_text();lines=[];count=0
 for line in s.splitlines():
  if line.startswith('M') and 'l=10u' in line.lower():
   a=line.split();assert a[2]=='a_15600_31700#';a[2]='gcomp' if rz else a[2];line=' '.join(a);count+=1
  if line.startswith('.ends') and rz:lines.append(f'RNULL a_15600_31700# gcomp {rz}')
  lines.append(line)
 assert count==9
 key=f'{n}_r{rz}';(R/f'models/n{key}.spice').write_text('\n'.join(lines)+'\n');keys.append(key)
jobs=[(key,3.5,cl,v) for key in keys for cl,v in itertools.product([1,5,10],[1.5,2.5,3.5])]
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:acs=list(ex.map(lambda x:ac(*x),jobs))
save('ac_grid',acs);summary=[]
for key in keys:
 rr=[x for x in acs if x['N']==key];nom=next(x for x in rr if x['CL_pF']==5 and x['VC_V']==2.5);summary.append(dict(**nom,units=int(key.split('_')[0]),R_ohm=int(key.split('r')[1]),min_PM_deg=min(x['PM_deg'] if x['PM_deg'] is not None else -999 for x in rr)))
save('candidates',summary);print('AC completed',flush=True)
# Screen both 63- and 65-degree reserve groups, selecting several fast contenders for step tests.
chosen={'9_r0'}
for threshold in [63,65]:
 valid=sorted([x for x in summary if x['min_PM_deg']>=threshold],key=lambda x:-x['UGF_MHz']);chosen.update(x['N'] for x in valid[:4])
jobs=[(key,3.5,cl,big) for key in sorted(chosen) for cl,big in itertools.product([5,10],[False,True])]
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:trs=list(ex.map(lambda x:tran(*x),jobs))
save('transients',trs)
for x in summary:
 if x['N'] in chosen:
  for cl in [5,10]:
   for size in ['small','large']:x[f'{size}_{cl}p_us']=next(t['settling_us'] for t in trs if t['N']==x['N'] and t['CL_pF']==cl and t['step']==size)
valid=[x for x in summary if x['min_PM_deg']>=65 and x.get('large_10p_us') is not None]
best=min(valid,key=lambda x:x['large_10p_us'])
stress=[ac(best['N'],3.5,5,4),ac(best['N'],3.5,10,2.5,1),ac(best['N'],3.5,10,2.5,3)];save('stress',stress)
fine=tran(best['N'],3.5,10,True,1);save('fine',[fine])
save('all_candidates',summary)
(R/'selection.json').write_text(json.dumps(dict(selected=best,baseline=next(x for x in summary if x['N']=='9_r0'),scope='Only the compensation architecture has been simulated; class AB/cascode variants remain proposed. All new resistor/C sizing models retain fixed v3 routing C and require layout/extraction; resistor is ideal, not a PDK resistor implementation.'),indent=2));print((R/'selection.json').read_text(),flush=True)
