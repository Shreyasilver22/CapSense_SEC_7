import json,itertools,concurrent.futures
import study as s
if __name__=='__main__':
 p=next(x for x in json.loads((s.R/'candidates.json').read_text()) if x['name']=='complementary_40')
 curves=[s.characterize(p['name'],p['L_um'],p['alpha'],cm=c,span=min(1.5,2*c-.1),step=.01) for c in [.5,1,1.3359,1.75,2.25]]
 old=[x for x in json.loads((s.R/'iv_curves.json').read_text()) if x['name']!='complementary_40'];s.save('iv_curves',old+curves)
 jobs=[dict(arch=a,switch='tg',method='gear',mos='bnbp49_5v',vdd=5.5,temp=t) for a,t in itertools.product(['reference_layout_C','complementary_40'],[0,85])]
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:rr=list(ex.map(lambda j:s.sc.run(**j),jobs))
 old=[x for x in json.loads((s.R/'SC_comparison.json').read_text()) if x['name'] not in {z['name'] for z in rr}];s.save('SC_comparison',old+rr)
