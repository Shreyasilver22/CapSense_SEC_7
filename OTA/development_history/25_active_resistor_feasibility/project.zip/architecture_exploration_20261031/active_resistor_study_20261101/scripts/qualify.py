import json,itertools,concurrent.futures
import study as s
R=s.R
if __name__=='__main__':
 variants=['reference_layout_C','nmos','complementary_40']
 jobs=[dict(tag=a,vd=vd,model=R/'models'/(a+'.spice')) for a,vd in itertools.product(variants,[-2,-1.6,-1.2,-.8,-.4,0,.4,.8,1.2,1.6,2])]
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:rr=list(ex.map(lambda j:s.w.ac({},**j),jobs))
 s.save('signal_range',rr);print('Signal range',len(rr),flush=True)
 jobs=[dict(tag=a,model=R/'models'/(a+'.spice'),mos=m,vdd=v,temp=t,vd=sg*max(v-3,6.6-v)) for a,m,v,t,sg in itertools.product(variants,['tntp49_5v','bnbp49_5v','bnwp49_5v','wnbp49_5v','wnwp49_5v'],[4.5,5.5],[0,85],[-1,0,1])]
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:rr=list(ex.map(lambda j:s.w.ac({},**j),jobs))
 s.save('corner_screen',rr);print('Corner cases',len(rr),flush=True)
 jobs=[dict(arch=a,switch=sw,method='gear',mos=m,vdd=v,temp=t) for a,sw,(m,v,t) in itertools.product(variants,['smooth','tg'],[('tntp49_5v',5,27),('wnwp49_5v',4.5,85),('wnbp49_5v',5.5,0)])]
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:rr=list(ex.map(lambda j:s.sc.run(**j),jobs))
 s.save('SC_comparison',rr);print('SC cases',len(rr),flush=True)
 for a in variants:
  rows=[x for x in json.loads((R/'corner_screen.json').read_text()) if x['candidate']==a and x['status']=='OK'];print(a,'worst CM',max(abs(x['CM_error_mV']) for x in rows),'minPM',min(x['PM_deg'] for x in rows if x['PM_deg'] is not None),flush=True)
