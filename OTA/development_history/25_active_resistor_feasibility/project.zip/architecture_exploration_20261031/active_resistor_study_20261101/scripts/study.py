from pathlib import Path
import json,re,subprocess,concurrent.futures,itertools
import numpy as np
import sweep as w
import sc_simulate as sc
R=w.R;PDK=w.PDK

def device(a,b,L,alpha=0,gateN='VDD',gateP='0',bulkN='0',bulkP='VDD',name='AR'):
 line=f'M{name}N {a} {gateN} {b} {bulkN} N W=2.5u L={L:.10g}u AD=11.25p AS=11.25p PD=14u PS=14u\n'
 if alpha:line+=f'M{name}P {a} {gateP} {b} {bulkP} P W=2.5u L={L:.10g}u M={alpha} AD=11.25p AS=11.25p PD=14u PS=14u\n'
 return line

def characterize(name,L,alpha,cm=1.3359,vdd=5,temp=27,mos='tntp49_5v',span=.02,step=.01):
 tag=f'{name}_cm{cm}_v{vdd}_t{temp}_{mos}_{span}'
 d=R/'results'/'characterization'/tag;d.mkdir(parents=True,exist_ok=True)
 text=f'''Native SCL08 MOS resistor characterization: {tag}
.include "{PDK}/mos/{mos}"
.temp {temp}
.options reltol=1e-6 abstol=1e-14 vntol=1e-9 numdgt=12
VDD VDD 0 {vdd}
VCMD vd 0 0
EA na 0 value={{{cm}+v(vd)/2}}
EB b 0 value={{{cm}-v(vd)/2}}
VMEAS na a 0
{device('a','b',L,alpha)}
.control
set wr_singlescale
set wr_vecnames
dc VCMD {-span} {span} {step}
wrdata curve.dat v(a) v(b) i(VMEAS)
quit
.endc
.end
'''
 (d/'tb.cir').write_text(text);p=subprocess.run(['ngspice','-b','-o','sim.log','tb.cir'],cwd=d,capture_output=True,timeout=60)
 a=np.loadtxt(d/'curve.dat',skiprows=1);assert p.returncode==0
 slope=(np.interp(.01,a[:,0],a[:,3])-np.interp(-.01,a[:,0],a[:,3]))/.02
 return dict(name=name,L_um=L,alpha=alpha,cm_V=cm,VDD=vdd,temp=temp,mos=mos,R_small_ohm=1/slope,folder=str(d.relative_to(R)))

def build(candidates):
 source=(R/'models/reference_layout_C.spice').read_text();lines=source.splitlines();edges=[]
 for ln in lines:
  a=ln.split()
  if a and a[0].startswith('X') and 'RPP' in a:edges.append((a[1],a[2]))
 assert len(edges)==160,len(edges)
 rnodes={n for e in edges for n in e};ends={}
 for ln in lines:
  a=ln.split()
  if not a or not a[0].startswith('M'):continue
  if a[2] in ['OUTP','OUTM'] and re.search(r'\bw=20u\s+l=1.6u',ln,re.I):
   n=next(x for x in [a[1],a[3]] if x!='VDD');ends['SP' if a[2]=='OUTP' else 'SM']=n
  if a[2] in rnodes and re.search(r'\bw=5u\s+l=2.4u',ln,re.I):ends['SENSE']=a[2]
 assert set(ends)=={'SP','SM','SENSE'},ends
 internal=rnodes-set(ends.values());kept=[];removed=[]
 for ln in lines:
  a=ln.split()
  if a and a[0].startswith('X') and 'RPP' in a:removed.append(ln);continue
  if a and a[0].startswith('C') and (a[1] in internal or a[2] in internal):removed.append(ln);continue
  if ln.lower().startswith('.ends'):continue
  kept.append(ln)
 (R/'verification/replacement.json').write_text(json.dumps(dict(terminal_map=ends,removed_RPP_halves=len(edges),removed_cap_entries=sum(x.startswith('C') for x in removed),internal_resistor_nodes=len(internal),limits='Hybrid preview only: old resistor-bank networks removed, other extracted OTA capacitances retained, new MOS intrinsic and estimated junction capacitances added. No new layout/DRC/LVS/PEX.'),indent=2))
 (R/'models/compact_RPP_control.spice').write_text('\n'.join(kept)+f"\nXRCSP {ends['SP']} {ends['SENSE']} RPP W=2.4u L=17142.857142857u\nXRCSM {ends['SM']} {ends['SENSE']} RPP W=2.4u L=17142.857142857u\n.ends ota_telescopic_layout\n")
 for p in candidates:
  text='\n'.join(kept)+'\n'
  for leg in ['SP','SM']:text+=device(ends[leg],ends['SENSE'],p['L_um'],p['alpha'],gateP='VSS',bulkN='VSS',name=leg)
  text+='.ends ota_telescopic_layout\n';(R/'models'/(p['name']+'.spice')).write_text(text)

def save(n,r):w.save(n,r)
if __name__=='__main__':
 candidates=[];cal=[]
 for alpha in [0,1,2,4,8,16,24,32,40,48,64]:
  name='nmos' if alpha==0 else 'complementary_'+str(alpha);L=100
  for j in range(3):
   r=characterize(name+'_cal'+str(j),L,alpha);cal.append(r);L*=200000/r['R_small_ohm']
  r=characterize(name,L,alpha);cal.append(r);candidates.append(dict(name=name,alpha=alpha,L_um=L,R_small_ohm=r['R_small_ohm'],channel_area_per_branch_um2=2.5*L*(1+alpha)))
 save('calibration',cal);(R/'candidates.json').write_text(json.dumps(candidates,indent=2));print('Candidates',candidates,flush=True)
 build(candidates)
 jobs=[(p,cm) for p in candidates for cm in [.5,1,1.3359,1.75,2.25]]
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:curves=list(ex.map(lambda j:characterize(j[0]['name'],j[0]['L_um'],j[0]['alpha'],cm=j[1],span=min(1.5,2*j[1]-.1),step=.01),jobs))
 save('iv_curves',curves);print('I-V curves',len(curves),flush=True)
 variants=['reference_layout_C','compact_RPP_control']+[p['name'] for p in candidates]
 jobs=[dict(tag=a,vd=vd,model=R/'models'/(a+'.spice')) for a,vd in itertools.product(variants,[0,-1.6,1.6])]
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:rows=list(ex.map(lambda j:w.ac({},**j),jobs))
 save('cmfb_nominal',rows);print('CMFB cases',len(rows),flush=True)
 for name in variants:
  rr=[x for x in rows if x['candidate']==name];print(name,'maxCM_mV',max(abs(x.get('CM_error_mV',999)) for x in rr),'minPM',min((x['PM_deg'] for x in rr if x.get('PM_deg') is not None),default=None),flush=True)
