from pathlib import Path
import os,json,hashlib
os.environ.setdefault('MPLCONFIGDIR','/tmp/active_resistor_mpl')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import study as s
R=s.R
load=lambda f:json.loads((R/f).read_text())
candidates=load('candidates.json');iv=load('iv_curves.json');ac=load('signal_range.json');corners=load('corner_screen.json');sc=load('SC_comparison.json')
names={'reference_layout_C':'Existing 200k RPP layout','compact_RPP_control':'200k RPP without bank parasitics (control)','nmos':'Single NMOS resistor','complementary_40':'Tuned complementary MOS resistor'}
colors={'reference_layout_C':'#444444','nmos':'#c24a4a','complementary_40':'#246faf'}
summary=[]
for variant in colors:
 rr=[x for x in corners if x['candidate']==variant and x['status']=='OK'];nn=[x for x in ac if x['candidate']==variant and abs(abs(x['vd'])-1.6)<1e-6]
 x=next(x for x in sc if x['arch']==variant and x['switch']=='tg' and x['VDD']==5 and x['temp']==27)
 summary.append(dict(variant=variant,nominal_end_CM_error_mV=max(abs(z['CM_error_mV']) for z in nn),worst_screened_CM_error_mV=max(abs(z['CM_error_mV']) for z in rr),minimum_screened_CMFB_PM_deg=min(z['PM_deg'] for z in rr if z['PM_deg'] is not None),nominal_SC_TG_error_mV=x.get('max_sample_error_mV'),nominal_SC_TG_CM_error_mV=x.get('max_CM_error_mV'),nominal_SC_power_uW=x.get('avg_VDD_power_uW')))
s.save('comparison',summary)
plt.rcParams.update({'font.size':10,'axes.grid':True,'grid.alpha':.25})
fig,ax=plt.subplots(1,2,figsize=(11,4.8))
for variant in ['nmos','complementary_40']:
 rows=sorted([x for x in iv if x['name']==variant],key=lambda x:x['cm_V']);ax[0].semilogy([x['cm_V'] for x in rows],[x['R_small_ohm']/1000 for x in rows],'o-',label=names[variant],color=colors[variant])
ax[0].axhline(200,color='grey',ls='--',label='200k target');ax[0].set(xlabel='Resistor terminal common-mode voltage (V)',ylabel='Small-signal resistance (kohm)',title='Same geometry: resistance changes with bias');ax[0].legend(fontsize=8)
for variant in colors:
 rr=sorted([x for x in ac if x['candidate']==variant],key=lambda x:x['vd']);ax[1].plot([x['vd'] for x in rr],[x['CM_error_mV'] for x in rr],'o-',label=names[variant],color=colors[variant])
ax[1].set(xlabel='Commanded OTA differential output (V)',ylabel='Output common-mode error (mV)',title='5 V, 27 C: tuned complementary cell looks good here');ax[1].legend(fontsize=8)
fig.tight_layout();fig.savefig(R/'plots/bias_and_averaging.png',dpi=170);fig.savefig(R/'plots/bias_and_averaging.pdf');plt.close(fig)
fig,ax=plt.subplots(1,2,figsize=(11,4.7))
for i,x in enumerate(summary):
 ax[0].bar(i,x['worst_screened_CM_error_mV'],color=colors[x['variant']]);ax[1].bar(i,x['minimum_screened_CMFB_PM_deg'],color=colors[x['variant']])
for a in ax:a.set_xticks(range(3),['Poly RPP','NMOS','Complementary']);a.tick_params(axis='x',labelrotation=15)
ax[0].set(ylabel='Worst absolute output CM error (mV)',title='Identical selected process / voltage / temperature grid');ax[1].set(ylabel='Minimum CMFB phase margin (degrees)',title='Nominal tuning does not establish corner performance');ax[1].axhline(60,color='grey',ls='--',label='60 degree screening target');ax[1].legend()
fig.tight_layout();fig.savefig(R/'plots/corner_comparison.png',dpi=170);fig.savefig(R/'plots/corner_comparison.pdf');plt.close(fig)
fig,ax=plt.subplots(2,1,figsize=(11,8),sharex=True)
for variant in ['reference_layout_C','complementary_40']:
 x=next(x for x in sc if x['arch']==variant and x['switch']=='tg' and x['mos']=='bnbp49_5v' and x['VDD']==5.5 and x['temp']==85);d=np.loadtxt(R/'results'/x['name']/'transient.dat',skiprows=1);ax[0].plot(d[:,0]*1e6,d[:,1],label=names[variant],color=colors[variant]);ax[1].plot(d[:,0]*1e6,((d[:,1]+d[:,3])/2-2.75)*1000,color=colors[variant])
ax[0].set(ylabel='SC output (V)',title='Actual transistor switches: bnbp49_5v, 5.5 V, 85 C, 50 kHz');ax[0].legend(fontsize=8);ax[1].set(ylabel='Output common-mode error (mV)',xlabel='Time (us)',xlim=(45,205))
# The NMOS fast/hot SC case was not part of the saved grid; only plot existing data.
fig.tight_layout();fig.savefig(R/'plots/SC_corner.png',dpi=170);fig.savefig(R/'plots/SC_corner.pdf');plt.close(fig)
table='| CMFB averaging element | Nominal endpoint CM error (mV) | Worst screened CM error (mV) | Lowest CMFB margin |\n|---|---:|---:|---:|\n'
for x in summary:table+=f"| {names[x['variant']]} | {x['nominal_end_CM_error_mV']:.2f} | {x['worst_screened_CM_error_mV']:.2f} | {x['minimum_screened_CMFB_PM_deg']:.2f} deg |\n"
failed=[x for x in sc if x['status']!='OK'];best=next(x for x in candidates if x['name']=='complementary_40');nmos=next(x for x in candidates if x['name']=='nmos')
status=dict(study='MOS-based voltage-controlled resistor feasibility in CMFB',replaced_verified_design=False,new_layout_done=False,models='Hybrid preview: retained OTA extracted C; removed old RPP-bank R/C; new MOS intrinsic + assumed junction geometry',N_unit_W_um=2.5,N_unit_L_um=nmos['L_um'],best_nominal_complementary_P_multiplicity=40,selected_corner_CM_cases=len(corners),selected_corner_CM_execution_failures=sum(x['status']!='OK' for x in corners),SC_cases=len(sc),SC_successes=len(sc)-len(failed),SC_numerical_failures=[x['name'] for x in failed],conclusion='Simple MOS cells substantially degrade common-mode regulation; the tuned complementary cell fails the 60-degree margin target. No final accuracy budget is assumed. Retain the verified poly implementation while investigating linearized/tunable active cells.')
(R/'verification/final_status.json').write_text(json.dumps(status,indent=2))
# Standalone reusable element definitions (nominal-only resistance, not a precision primitive).
cells=[]
for p in [nmos,best]:
 nm='cmfb_res_nmos' if p['alpha']==0 else 'cmfb_res_complementary'
 cells+=['* NOMINAL-ONLY MODEL: about 200k near terminal CM=1.3359V, VDD=5V, typical,27C.',f'.subckt {nm} A B VDD VSS',s.device('A','B',p['L_um'],p['alpha'],gateP='VSS',bulkN='VSS',name='R').strip(),f'.ends {nm}','']
(R/'models/active_resistor_cells.spice').write_text('\n'.join(cells))
for variant in ['reference_layout_C','nmos','complementary_40']:
 x=next(x for x in sc if x['arch']==variant and x['switch']=='tg' and x['VDD']==5 and x['temp']==27)
 txt=(R/'results'/x['name']/'tb.cir').read_text().replace(str(R/'models'/(variant+'.spice')),'../models/'+variant+'.spice').replace('wrdata transient.dat','wrdata '+variant+'.dat');(R/'tb'/(variant+'.cir')).write_text(txt)
R.joinpath('README.md').write_text(f'''# MOS active-resistor feasibility — 1 November 2026

MOSFET voltage-controlled resistors were actually simulated with the native SCL08 models in ngspice. The verified poly-resistor OTA design was not changed. This study tests a direct MOS substitution in its CMFB averaging network; it does not claim that all active-resistor topologies are unsuitable.

## What was tested

- Single NMOS in triode, gateVDD, bodyVSS.
- Parallel NMOS/PMOS resistor: gatesVDD/VSS, bodiesVSS/VDD. PMOS multiplicities1,2,4,8,16,24,32,40,48,64 were investigated. Both resistor branches use identical devices.
- UnitW2.5 um and length tuned to a differential resistance of200 kohm at terminal common-mode1.3359 V, VDD5 V,27 C, typical native model. The NMOS length is**{nmos['L_um']:.3f} um**. The best nominal common-mode cancellation in the explored set uses**one NMOS plus40 PMOS units per branch**, with length**{best['L_um']:.3f} um**. It is not a simple equal-size transmission gate.
- Full existing200 kohm RPP capacitance-extracted OTA as reference; a separate bank-parasitic-free200 kohm RPP model as a diagnostic.

All MOS variants are approximately200 kohm at the calibration point. That does not make them constant200 kohm components over their operating range. Effective resistance changes with both terminal voltages, gate overdrive, body effect and process/temperature. Consequently equal geometries in the two averaging branches can have unequal effective resistance when the outputs differ. The sensed voltage then differs from the arithmetic mean. The tuned complementary network can partly cancel this error at nominal conditions, but its P/N tracking changes across corners.

## Measured CMFB results

Nominal endpoints here mean commanded differential output plus/minus1.6 V at5 V/27 C; the full nominal sweep covers−2 to+2 V. The selected corner grid uses the same five native MOS files for every variant,4.5/5.5 V,0/85 C, and balanced or opposite-polarity differential levels covering SC integration/reset endpoints. CL5 pF per output. Native RPP corner remains typical for the reference; these selected cases are not the full prior1442-case qualification grid.

{table}
The complementary cell looks excellent at the nominal calibration range but reaches roughly0.66 V output-common-mode error in a selected corner and falls below the previous60-degree margin target. The single NMOS keeps adequate loop margin in this screen, but biases the common-mode average substantially. Thus **neither simple cell is accepted as a drop-in replacement** for the current verified200 kohm poly network.

`signal_range.json` and `corner_screen.json` include `averaging_error_mV`, the direct sensed-node deviation from `(SP+SM)/2`, separately from the OTA's output-common-mode error. The reference includes pre-existing sensing-buffer nonlinearity; a small output-common-mode error alone does not prove a linear resistor or an exact averaging function.

## SC checks

The original SC topology and stimulus remain unchanged:CS2.5 pF,CF7.5 pF,VREF1.5 V,VP0.3 V,50 kHz,3 cycles per frame, two frames,5 pF per output. Transistor switch sizes and clocks are unchanged. Both actual transistor switches and the prior smoothly controlled100-ohm diagnostic were tested with Gear integration.

Nominal transistor-switch SC sampled common-mode errors are about24.8 mV for the poly reference,94.9 mV for the single NMOS and24.1 mV for the tuned complementary cell. A nominal waveform therefore does not reject the complementary cell by itself. Additional nativebnbp49_5v,5.5 V tests reveal roughly264 mV CM error at0 C and375 mV at85 C for the complementary version, versus approximately11/13 mV for the poly reference. Raw output error can partially cancel against switching error; a smaller raw offset is not proof of improved common-mode regulation or calibrated accuracy.

SC simulations saved:{len(sc)}; completed:{len(sc)-len(failed)}; numerical failures:{len(failed)}. The single-NMOS/native-switch case atwnbp49_5v,5.5 V,0 C did not complete, and no valid result is claimed for it. Inspect its raw log for the convergence failure. Other cases and their six sampled values are in`SC_comparison.json`.

## Model scope and area interpretation

This is a **hybrid electrical preview**, not a new post-layout MOS-resistor result. The existing OTA's extracted core/controller capacitances are retained. The old poly-resistor bank resistances and capacitances touching resistor-only internal nodes are removed, and MOS channel/intrinsic capacitances plus estimated junction geometry are inserted. Remaining old metal capacitances at the three retained endpoints remain. `verification/replacement.json` records the endpoint mapping and removal counts. The bank-parasitic-free RPP control preserves the reference DC result, providing a check on the replacement operation.

No active-resistor GDS, DRC, LVS or new extraction was performed. Estimated gate-channel area is about{nmos['channel_area_per_branch_um2']:.1f} um2 per NMOS branch or{best['channel_area_per_branch_um2']:.1f} um2 for the40-PMOS complementary branch. Those are channel areas only, excluding wells, contacts and routing; they are not total layout areas or measured parasitic improvements. Long-channel MOS model accuracy near51 um has not been validated against characterization or foundry geometry limits. Supply-noise coupling, mismatch, resistor noise, reference loading and final ASIC specifications remain unqualified. Existing native-model/ngspice translation and engineering C-extraction limitations carry over.

## Conclusion

MOS-based resistance is a reasonable area-reduction experiment. The simulated rail-gated cells need linearization, bias/process tracking or trimming before replacing this CMFB network. Keep the verified poly implementation as the reference for now. A different linearized MOS cell or clocked CMFB is a further design task; this study does not establish its performance.

## Files and reproduction

- `models/active_resistor_cells.spice`: standalone four-terminal nominal-only element definitions, pins`A B VDD VSS`; nativeN/P cards must be supplied by the user. Their resistance is not independently value-programmable or guaranteed200 kohm.
- `models/nmos.spice`, `complementary_40.spice`: OTA hybrid previews; `reference_layout_C.spice`: unchanged physical reference. Include one OTA variant at a time because they share the same subcircuit name.
- `tb/nmos.cir`, `complementary_40.cir`, `reference_layout_C.cir`: nominal native-switch SC tests. Run from`tb`, for example`ngspice -b -o nmos.log nmos.cir`. PDK remains at`/home/berson_meshak/pdk/scl08/ngspice_models49`; no native cards were copied here.
- Regenerate with`scripts/study.py`, then`qualify.py`, `additional.py`, `report.py`. Raw decks retain their original execution paths; regenerate after relocation. `scripts/sweep.py` and`sc_simulate.py` retain the previous study's measurement helpers; their standalone old sweep entry points are not this study's reproduction interface.
- `plots/bias_and_averaging.png`, `corner_comparison.png`, `SC_corner.png`, plus PDF copies.
- `candidates.json`, `iv_curves.json`, `cmfb_nominal.json`, `signal_range.json`, `corner_screen.json`, `SC_comparison.json` and raw logs preserve the conditions and results. The original verified OTA/SC design was not overwritten or published.
''')
(R/'hashes.json').write_text(json.dumps({str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for f in ['scripts','models','tb'] for p in (R/f).glob('*') if p.is_file()},indent=2))
print(table);print(json.dumps(status,indent=2))
