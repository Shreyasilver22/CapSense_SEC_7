import ctypes as C
from pathlib import Path
r=Path(__file__).resolve().parent
svg=C.CDLL('librsvg-2.so.2');cr=C.CDLL('libcairo.so.2')
svg.rsvg_handle_new_from_file.argtypes=[C.c_char_p,C.c_void_p];svg.rsvg_handle_new_from_file.restype=C.c_void_p
svg.rsvg_handle_render_cairo.argtypes=[C.c_void_p,C.c_void_p];svg.rsvg_handle_render_cairo.restype=C.c_int
cr.cairo_image_surface_create.argtypes=[C.c_int,C.c_int,C.c_int];cr.cairo_image_surface_create.restype=C.c_void_p
cr.cairo_create.argtypes=[C.c_void_p];cr.cairo_create.restype=C.c_void_p
cr.cairo_scale.argtypes=[C.c_void_p,C.c_double,C.c_double];cr.cairo_set_source_rgb.argtypes=[C.c_void_p,C.c_double,C.c_double,C.c_double];cr.cairo_paint.argtypes=[C.c_void_p]
cr.cairo_surface_write_to_png.argtypes=[C.c_void_p,C.c_char_p];cr.cairo_surface_write_to_png.restype=C.c_int
handle=svg.rsvg_handle_new_from_file(str(r/'plots/ota_current.svg').encode(),None);assert handle
surf=cr.cairo_image_surface_create(0,3000,2550);ctx=cr.cairo_create(surf);cr.cairo_scale(ctx,3.,3.); cr.cairo_translate.argtypes=[C.c_void_p,C.c_double,C.c_double]; cr.cairo_translate(ctx,0.,50.);cr.cairo_set_source_rgb(ctx,1.,1.,1.);cr.cairo_paint(ctx);assert svg.rsvg_handle_render_cairo(handle,ctx)
assert cr.cairo_surface_write_to_png(surf,str(r/'plots/ota_current.png').encode())==0
