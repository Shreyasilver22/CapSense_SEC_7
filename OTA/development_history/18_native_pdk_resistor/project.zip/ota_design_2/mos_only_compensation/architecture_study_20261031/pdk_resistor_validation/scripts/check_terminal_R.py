import engine as e
import transient as t
import re,json
R=e.R;p=R/'models/npdk_typ_C.spice';s=p.read_text()
def sub(m):
 k,a,b=m[1],m[2],m[3]
 return f'REXT{k}a {a} rp{k}a 26\nXRZ{k} rp{k}a rp{k}b RPP W=2.4u L=137.143u\nREXT{k}b rp{k}b {b} 26'
s=re.sub(r'XRZ(\d+) (\S+) (\S+) RPP W=2.4u L=137.143u',sub,s);(R/'models/npdk_typ_RC_est.spice').write_text(s)
acs=[e.ac('pdk_typ_RC_est',3.5,cl,v) for cl in [1,5,10] for v in [1.5,2.5,3.5]]
trs=[t.tran('pdk_typ_RC_est',3.5,cl,big) for cl in [5,10] for big in [False,True]]
e.save('terminal_R_AC',acs);e.save('terminal_R_transients',trs);q=next(x for x in acs if x['CL_pF']==5 and x['VC_V']==2.5);q.update(min_PM_deg=min(x['PM_deg'] for x in acs),large_10p_us=next(x['settling_us'] for x in trs if x['CL_pF']==10 and x['step']=='large'),small_10p_us=next(x['settling_us'] for x in trs if x['CL_pF']==10 and x['step']=='small'));(R/'terminal_R_summary.json').write_text(json.dumps(q,indent=2));print(json.dumps(q,indent=2))
