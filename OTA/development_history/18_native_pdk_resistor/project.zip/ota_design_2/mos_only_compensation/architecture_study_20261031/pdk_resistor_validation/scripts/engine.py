from pathlib import Path
import re,json,subprocess,itertools,csv,concurrent.futures
import numpy as np
R=Path(__file__).resolve().parents[1]
src=Path('/home/berson_meshak/final year project/ota/ota_design_2/mos_only_compensation/physical_layout_v3/pex/ota_C_only.spice')
s=src.read_text();(R/'models/baseline.spice').write_text(s)
for n in [6,7,8,9]:
 lines=[];count=0
 for ln in s.splitlines():
  if ln.startswith('M') and 'l=10u' in ln.lower():ln+=f' m={n/9:.12g}';count+=1
  lines.append(ln)
 assert count==9
 (R/f'models/n{n}.spice').write_text('* What-if count scaling: fixed v2 routing capacitances; not re-extracted layout.\n'+'\n'.join(lines)+'\n')
def base(n,i,cl,extra=0):return f'''OTA retuning N={n}, IREF={i}uA CL={cl}pF
.include "/home/berson_meshak/pdk/scl08/ngspice_models49/mos/tntp49_5v"
.include "{R}/models/n{n}.spice"
.temp 27
.options reltol=1e-5 vntol=1e-8 abstol=1e-12 numdgt=12
VDD vdd 0 5
IREF vdd bias {i}u
CL out 0 {cl}p
CSTRESS out 0 {extra}p
XU inp inn out vdd 0 bias ota_design2_mos
'''
def ac(n,i,cl,vc,extra=0):
 d=R/f'results/n{n}_i{i}/ac_cl{cl}_v{vc}_ex{extra}';d.mkdir(parents=True,exist_ok=True)
 text=base(n,i,cl,extra)+f'''VIN inp 0 dc {vc} ac 1
LDC out inn 1e12
CAC inn 0 1e12
.control
set wr_singlescale
set wr_vecnames
op
print v(out) i(vdd)
ac dec 150 1 1G
let gd=db(v(out))
let pd=180/PI*cph(v(out))
wrdata ac.dat gd pd
quit
.endc
.end
''';(d/'ac.cir').write_text(text);p=subprocess.run(['ngspice','-b','-o','ac.log','ac.cir'],cwd=d,capture_output=True,timeout=60);assert p.returncode==0
 a=np.loadtxt(d/'ac.dat',skiprows=1);ix=np.where(a[:-1,1]*a[1:,1]<0)[0];pm=ugf=None
 if len(ix)==1:
  z=ix[0];f=-a[z,1]/(a[z+1,1]-a[z,1]);pm=float(180+a[z,2]+f*(a[z+1,2]-a[z,2]));ugf=float(10**(np.log10(a[z,0])+f*np.log10(a[z+1,0]/a[z,0]))/1e6)
 log=(d/'ac.log').read_text();power=-5e6*float(re.search(r'^i\(vdd\)\s*=\s*([-+\d.eE]+)',log,re.M)[1])
 return dict(N=n,I_uA=i,CL_pF=cl,VC_V=vc,extra_pF=extra,gain_dB=float(a[0,1]),UGF_MHz=ugf,PM_deg=pm,power_uW=power)
def save(name,rows):
 (R/f'{name}.json').write_text(json.dumps(rows,indent=2))
 if rows:
  with (R/f'{name}.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=list(dict.fromkeys(k for row in rows for k in row)));w.writeheader();w.writerows(rows)
