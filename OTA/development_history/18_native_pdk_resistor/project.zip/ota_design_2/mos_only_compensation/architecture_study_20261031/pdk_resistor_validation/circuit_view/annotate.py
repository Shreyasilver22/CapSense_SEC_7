from pathlib import Path
import xml.etree.ElementTree as E
r=Path(__file__).resolve().parent;p=r/'plots/ota_current.svg';tree=E.parse(p);root=tree.getroot();ns='http://www.w3.org/2000/svg';E.register_namespace('',ns);root.set('height','850');root.set('viewBox','0 -50 1000 850')
for n in root.iter():
 if n.tag.endswith('text') and n.attrib.get('transform')=='translate(102.897, 576.81)':n.set('transform','translate(102.897, 601)')
for x,y,size,text in [(18,-22,19,'Current SCL08 OTA: PDK RPP resistor + MOS compensation'),(18,735,13,'VDD = 5 V; IREF = 3.5 uA. Device labels: unit W / L / parallel count (dimensions in um).'),(18,760,12,'Topology view: routing/junction parasitics and the estimated distributed resistor capacitance are omitted.'),(18,780,12,'RPP body = 16.00 kohm; terminal-resistance sensitivity adds about 520 ohm. MOS cap = 6 units.')]:
 n=E.SubElement(root,'{'+ns+'}text',{'x':str(x),'y':str(y),'fill':'#111111','font-size':str(size),'font-family':'sans-serif'});n.text=text
tree.write(p,encoding='unicode')
