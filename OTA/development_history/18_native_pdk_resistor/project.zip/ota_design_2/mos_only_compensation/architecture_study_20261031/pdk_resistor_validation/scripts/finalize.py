from pathlib import Path
import json,hashlib,subprocess,numpy as np,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parents[1];rows=json.loads((R/'summary.json').read_text());extra=json.loads((R/'terminal_R_summary.json').read_text());rows.append(extra)
fig,axs=plt.subplots(1,2,figsize=(12,5))
for key,lab in [('ideal','Ideal 16k'),('pdk_typ','PDK RPP'),('pdk_typ_C','RPP + estimated C'),('pdk_typ_RC_est','RPP + estimated R/C')]:
 d=R/f'results/n{key}_i3.5';a=np.loadtxt(d/'ac_cl5_v2.5_ex0/ac.dat',skiprows=1);t=np.loadtxt(d/'tran_large_cl10_5ns/tran.dat',skiprows=1);axs[0].semilogx(a[:,0],a[:,1],label=lab);axs[1].plot(t[:,0]*1e6,t[:,2],label=lab)
axs[0].set(xlim=(1e4,1e8),xlabel='Frequency (Hz)',ylabel='Gain (dB)');axs[1].set(xlim=(9.5,15),xlabel='Time (us)',ylabel='Output (V)',title='2 V step into 10 pF')
for ax in axs:ax.legend(fontsize=8);ax.grid(alpha=.25)
fig.suptitle('Native SCL08 RPP model; parasitic R/C estimates shown separately');fig.tight_layout();fig.savefig(R/'plots/pdk_resistor_comparison.png',dpi=170);fig.savefig(R/'plots/pdk_resistor_comparison.pdf')
g=json.loads((R/'layout/geometry.json').read_text());lines=['* Local PDK is referenced, not copied.','.include "/home/berson_meshak/pdk/scl08/ngspice_models49/res/typ/ppr"','.subckt scl08_rpp_16k A B']
for k in range(10):lines.append(f'XR{k} '+('A' if k==0 else f'n{k}')+' '+('B' if k==9 else f'n{k+1}')+' RPP W=2.4u L=137.143u')
lines.append('.ends scl08_rpp_16k');(R/'models/scl08_rpp_16k.spice').write_text('\n'.join(lines)+'\n')
for key in ['pdk_typ_C','pdk_typ_RC_est']:
 s=(R/f'results/n{key}_i3.5/tran_large_cl10_5ns/tran.cir').read_text().replace(str(R)+'/models/','../models/').replace('wrdata tran.dat',f'wrdata {key}.dat');(R/f'tb/{key}.cir').write_text(s)
(R/'final_summary.json').write_text(json.dumps({'cases':rows,'resistor_geometry':g,'LVS':'resistor cell MATCH','DRC':'resistor cell 0 markers','noise':json.loads((R/'noise_summary.json').read_text()),'limits':'Actual local PDK RPP subcircuits. Parasitic capacitances and contact/extension R are geometry-derived estimates, not full PEX; full integrated OTA layout not yet updated.'},indent=2))
(R/'input_hashes.json').write_text(json.dumps({str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [R/'layout/rpp_16k.gds',Path('/home/berson_meshak/pdk/scl08/ngspice_models49/res/typ/ppr'),Path('/home/berson_meshak/pdk/scl08/ngspice_models49/res/best/ppr'),Path('/home/berson_meshak/pdk/scl08/ngspice_models49/res/worst/ppr')]},indent=2))
print(json.dumps(extra,indent=2));print('Noise standalone',np.loadtxt(R/'results/resistor_thermal.dat',skiprows=1)[0])
