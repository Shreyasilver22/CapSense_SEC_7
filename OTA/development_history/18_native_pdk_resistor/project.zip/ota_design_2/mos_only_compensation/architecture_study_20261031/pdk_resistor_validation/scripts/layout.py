import pya,json
from pathlib import Path
R=Path(__file__).resolve().parents[1];ly=pya.Layout();ly.dbu=.001;c=ly.create_cell('rpp_16k');W=2.4;L=137.143;pitch=6
polys=[]
def box(n,x1,y1,x2,y2):c.shapes(ly.layer(n,0)).insert(pya.DBox(x1,y1,x2,y2))
def label(x,y,n):c.shapes(ly.layer(8,7)).insert(pya.DText(n,pya.DTrans(pya.DVector(x,y))))
for k in range(10):
 y=k*pitch;box(4,-3.6,y-W/2,L+3.6,y+W/2)
 for n in [5,6]:box(n,-4.3,y-1.9,L+4.3,y+1.9)
 box(44,0,y-W/2,L,y+W/2)
 for x in [-1.8,L+1.8]:
  box(7,x-.6,y-.6,x+.6,y+.6);box(8,x-1.1,y-1.1,x+1.1,y+1.1)
 box(36,-3.6,y-W/2,0,y+W/2);box(36,L,y-W/2,L+3.6,y+W/2)
 if k<9:
  x=L+1.8 if k%2==0 else -1.8;box(8,x-1.1,y-1.1,x+1.1,y+pitch+1.1)
label(-1.8,0,'A');label(-1.8,9*pitch,'B');ly.write(str(R/'layout/rpp_16k.gds'))
# Polygon-geometry estimates using coefficients read from local tech previously documented; NOT full PEX.
poly_area=(L+7.2)*W;poly_perim=2*(L+7.2+W);cp=(93*poly_area+48*poly_perim)*1e-18
m1region=pya.Region(c.begin_shapes_rec(ly.layer(8,0))).merged()
m1area=m1region.area()*ly.dbu**2
cm1=(29*m1area+42*m1region.perimeter()*ly.dbu)*1e-18
(R/'layout/geometry.json').write_text(json.dumps(dict(W_um=W,L_segment_um=L,segments=10,total_typ_R_ohm=28*L/W*10,poly_C_per_segment_F=cp,M1_ground_C_total_F=cm1,method='Unshielded area/perimeter coefficient estimate, not extracted PEX. Ground reference is substrate. Same-node overlap and shielding not resolved.'),indent=2))
ref=['.include \"/home/berson_meshak/pdk/scl08/analog_pdk/Open_Source_SCL_0.8micron_PDK/open_source_scl_cp8d/open_pdks/scl_cp8d/libs.ref/scl_tests/cs_amp/res_model.subckt\"','.subckt rpp_16k A B']
for k in range(10):ref.append(f'R{k} '+('A' if k==0 else f'n{k}')+' '+('B' if k==9 else f'n{k+1}')+f' {28*L/W} RPP')
ref+=['.ends rpp_16k'];(R/'layout/reference.cdl').write_text('\n'.join(ref)+'\n');print('R',28*L/W*10,'Cpoly',cp*10,'Cm1',cm1)
