import engine as e
from transient import tran
s=e.ac('pdk_typ_RC_est',3.5,5,4);f=tran('pdk_typ_RC_est',3.5,10,True,1);e.save('final_stress',[s]);e.save('fine',[f]);print(s);print(f)
