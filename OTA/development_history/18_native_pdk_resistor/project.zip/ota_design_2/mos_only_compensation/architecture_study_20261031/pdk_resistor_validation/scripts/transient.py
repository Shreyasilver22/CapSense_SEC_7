from engine import *
def tran(n,i,cl,large,dt=5):
 lo,hi=(1.5,3.5) if large else (2.5,2.6);tag='large' if large else 'small';d=R/f'results/n{n}_i{i}/tran_{tag}_cl{cl}_{dt}ns';d.mkdir(parents=True,exist_ok=True)
 s=base(n,i,cl)+f'''VIN inp 0 dc {lo} pulse({lo} {hi} 10u 10n 10n 40u 80u)
VFB inn out 0
.control
set wr_singlescale
set wr_vecnames
tran {dt}n 90u
wrdata tran.dat v(inp) v(out)
quit
.endc
.end
''';(d/'tran.cir').write_text(s);p=subprocess.run(['ngspice','-b','-o','tran.log','tran.cir'],cwd=d,capture_output=True,timeout=120);assert p.returncode==0
 a=np.loadtxt(d/'tran.dat',skiprows=1);sett=[];errors=[]
 for start,end,target in [(10e-6,49e-6,hi),(50.01e-6,89e-6,lo)]:
  final=float(np.mean(a[(a[:,0]>end-2e-6)&(a[:,0]<end),2]));mask=(a[:,0]>=start)&(a[:,0]<end);tt=a[mask,0];yy=a[mask,2];bad=np.where(abs(yy-final)>.001*(hi-lo))[0];sett.append(float((tt[bad[-1]+1]-start)*1e6) if len(bad) and bad[-1]+1<len(tt) else (0. if not len(bad) else None));errors.append((final-target)*1000)
 return dict(N=n,I_uA=i,CL_pF=cl,step=tag,dt_ns=dt,settling_us=max(sett) if all(x is not None for x in sett) else None,final_error_mV=max(abs(x) for x in errors))
