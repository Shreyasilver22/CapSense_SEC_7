v {xschem version=3.4.4 file_version=1.2}
G {}
K {}
V {}
S {}
E {}
C {../symbols/scl08_rpp_16k.sym} 300 300 0 0 {name=XR1}
C {devices/lab_pin.sym} 270 300 0 0 {name=l1 lab=A}
C {devices/lab_pin.sym} 330 300 0 1 {name=l2 lab=0}
C {devices/vsource.sym} 200 500 0 0 {name=VTEST value=1}
C {devices/lab_pin.sym} 200 470 0 0 {name=l3 lab=A}
C {devices/lab_pin.sym} 200 530 0 1 {name=l4 lab=0}
C {devices/code_shown.sym} 450 300 0 0 {name=CODE only_toplevel=true value=".include ../models/scl08_rpp_16k.spice
.control
op
print i(vtest)
quit
.endc"}
