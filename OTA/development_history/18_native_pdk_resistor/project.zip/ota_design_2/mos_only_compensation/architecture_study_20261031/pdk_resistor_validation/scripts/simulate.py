import engine as e
from transient import tran
from pathlib import Path
import json,itertools,concurrent.futures
R=e.R;g=json.loads((R/'layout/geometry.json').read_text());src=Path('/home/berson_meshak/final year project/ota/ota_design_2/mos_only_compensation/architecture_study_20261031/models/n6_r16000.spice').read_text()
cases={'ideal':('typ',27,False,False),'pdk_typ':('typ',27,True,False),'pdk_typ_C':('typ',27,True,True),'pdk_best_C':('best',27,True,True),'pdk_worst_C':('worst',27,True,True),'pdk_typ_C_0C':('typ',0,True,True),'pdk_typ_C_85C':('typ',85,True,True)}
for key,(corner,temp,use,cap) in cases.items():
 s=src
 if use:
  body=[]
  for k in range(10):
   a='a_15600_31700#' if k==0 else f'rz{k}';b='gcomp' if k==9 else f'rz{k+1}'
   body.append(f'XRZ{k} {a} {b} RPP W=2.4u L=137.143u')
   if cap:body += [f'CP{k}a {a} VSS {g["poly_C_per_segment_F"]/2:.12g}',f'CP{k}b {b} VSS {g["poly_C_per_segment_F"]/2:.12g}']
  if cap:
   for k,node in enumerate(['a_15600_31700#']+[f'rz{x}' for x in range(1,10)]+['gcomp']):body.append(f'CM{k} {node} VSS {g["M1_ground_C_total_F"]/11:.12g}')
  s=s.replace('RNULL a_15600_31700# gcomp 16000','\n'.join(body));s=f'.include "/home/berson_meshak/pdk/scl08/ngspice_models49/res/{corner}/ppr"\n'+s
 (R/f'models/n{key}.spice').write_text(s)
original=e.base
def base(n,i,cl,extra=0):return original(n,i,cl,extra).replace('.temp 27',f'.temp {cases[n][1]}')
e.base=base
# tran imports base into its own module namespace.
import transient
transient.base=base
jobs=[(k,3.5,cl,v) for k in cases for cl,v in itertools.product([1,5,10],[1.5,2.5,3.5])]
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:acs=list(ex.map(lambda x:e.ac(*x),jobs))
e.save('ac',acs);print('AC done',flush=True)
jobs=[(k,3.5,cl,big) for k in cases for cl,big in itertools.product([5,10],[False,True])]
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:trs=list(ex.map(lambda x:tran(*x),jobs))
e.save('transients',trs);out=[]
for k in cases:
 rr=[x for x in acs if x['N']==k];q=next(x for x in rr if x['CL_pF']==5 and x['VC_V']==2.5);out.append(dict(**q,min_PM_deg=min(x['PM_deg'] if x['PM_deg'] is not None else -999 for x in rr),small_10p_us=next(x['settling_us'] for x in trs if x['N']==k and x['CL_pF']==10 and x['step']=='small'),large_10p_us=next(x['settling_us'] for x in trs if x['N']==k and x['CL_pF']==10 and x['step']=='large')))
e.save('summary',out);print(json.dumps(out,indent=2))
