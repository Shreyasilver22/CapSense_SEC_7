# OTA application check using recalibrated modern capacitor models

| Candidate | UGF (MHz) | PM (deg) | Min checked PM (deg) | 100mV settling (us) | 2V settling (us) |
|---|---:|---:|---:|---:|---:|
| cap2_w20_g2_r3_i0 | 0.7470 | 70.65 | 64.69 | 0.974 | 3.715 |
| cap2_w24_g1p5_r3_i0p5 | 0.7484 | 70.95 | 65.02 | 0.944 | 3.720 |
| cap2_w24_g1p5_r3_i1 | 0.7481 | 70.89 | 64.98 | 0.949 | 3.720 |
| cap2_w24_g1p5_r2_i1 | 0.7482 | 70.92 | 65.01 | 0.949 | 3.720 |
| cap2_w24_g1p5_r2_i0 | 0.7482 | 70.99 | 65.06 | 0.939 | 3.725 |
| cap2_w24_g1p5_r3_i0 | 0.7482 | 70.97 | 65.03 | 0.944 | 3.725 |

Same tuned eight-MOS core, IREF2.5uA, VDD5V,27C, TOP=n2/BOT=out/SUB=vss. Six finalists,54AC cases and36base transients. Min PM spans explicitCL1/5/10pF x follower input1.5/2.5/3.5V. Settling is0.1% around actual final output, not total error to ideal input. Native capacitor models were consistent with raw extraction; transistor ignored-parameter warnings remain. Routing resistance is not included.

The balanced layout improves small-step settling modestly; large-step settling is essentially unchanged and slightly slower in this metric. No overall speedup or final optimum is claimed. Previous old-extractor results must not be mixed into this comparison.
