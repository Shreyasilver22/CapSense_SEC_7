from pathlib import Path
import json,subprocess,numpy as np
R=Path(__file__).resolve().parents[1];C=Path('/home/berson_meshak/final year project/capacitors/layout_optimization_v2');sel=json.loads((C/'results/selection.json').read_text());out=[]
for key in ['baseline','balanced_candidate']:
 name=sel[key]['name']
 for size,lo,hi in [('small',2.5,2.6),('large',1.5,3.5)]:
  d=R/'results/fine'/name/size;d.mkdir(parents=True,exist_ok=True);source=R/'results'/name/f'tran_cl5_{size}'/'tran.cir';(d/'tran.cir').write_text(source.read_text().replace('tran 5n','tran 1n'));p=subprocess.run(['ngspice','-b','-o','tran.log','tran.cir'],cwd=d,capture_output=True,text=True,timeout=60);assert p.returncode==0
  data=np.loadtxt(d/'tran.dat',skiprows=1);times=[]
  for start,end,window in [(10e-6,49e-6,(47e-6,49e-6)),(50.01e-6,89e-6,(87e-6,89e-6))]:
   final=np.mean(data[(data[:,0]>window[0])&(data[:,0]<window[1]),2]);m=(data[:,0]>=start)&(data[:,0]<end);tt=data[m,0];yy=data[m,2];bad=np.where(abs(yy-final)>.001*(hi-lo))[0];times.append(float((tt[bad[-1]+1]-start)*1e6))
  out.append(dict(name=name,step=size,rise_us=times[0],fall_us=times[1],worst_us=max(times)))
(R/'results/fine_timestep_check.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
