from pathlib import Path
import argparse,json,subprocess,itertools,csv,re
import numpy as np
R=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--cap-project',required=True,type=Path);p.add_argument('--mos-model',required=True,type=Path);a=p.parse_args();caproot=a.cap_project.resolve();mos=a.mos_model.resolve();assert mos.is_file()
(R/'models/cap_layouts.lib.spice').write_bytes((caproot/'models/cap_layouts.lib.spice').read_bytes())
(R/'results/cap_catalog.json').write_bytes((caproot/'results/catalog.json').read_bytes())
base=R/'models/ota_base.inc'
if not base.exists():raise SystemExit('Missing models/ota_base.inc')
source=base.read_text();caps=json.loads((caproot/'results/catalog.json').read_text())['capacitors']
def run(d,kind,text):
 d.mkdir(parents=True,exist_ok=True);(d/(kind+'.cir')).write_text(text);p=subprocess.run(['ngspice','-b','-o',kind+'.log',kind+'.cir'],cwd=d,capture_output=True,text=True,timeout=45);assert p.returncode==0,(str(d),p.stdout,p.stderr)
def net(name,cl):return f'''Layout-optimized capacitor test in the unchanged tuned SCL800 OTA: {name}
.include "{mos}"
.include "{R}/models/cap_layouts.lib.spice"
.include "{R}/models/{name}_ota.inc"
.temp 27
.options reltol=1e-5 vntol=1e-8 abstol=1e-12 numdgt=12
VDD vdd 0 5
IREF vdd bias 2.5u
CL out 0 {cl}p
XU inp inn out vdd 0 bias ota_tuned LI=2.4u LM=3.2u LO=3.2u K=4
'''
acs=[];trans=[]
for c in caps:
 name=c['name'];(R/'models'/(name+'_ota.inc')).write_text(source.replace('Cc n2 out {CC}',f'XCC n2 out vss {name}'))
 for cl,vc in itertools.product([1,5,10],[1.5,2.5,3.5]):
  d=R/'results'/name/f'ac_cl{cl}_vc{vc}';text=net(name,cl)+f'''VIN inp 0 dc {vc} ac 1
LDC out inn 1e12
CAC inn 0 1e12
.control
set wr_singlescale
set wr_vecnames
op
print v(out) i(vdd)
ac dec 150 1 1G
let gd=db(v(out))
let pd=180/PI*cph(v(out))
wrdata ac.dat gd pd
quit
.endc
.end
''';run(d,'ac',text);data=np.loadtxt(d/'ac.dat',skiprows=1);cross=np.where(data[:-1,1]*data[1:,1]<0)[0];pm=ugf=float('nan')
  if len(cross)==1:
   z=cross[0];f=-data[z,1]/(data[z+1,1]-data[z,1]);pm=180+data[z,2]+f*(data[z+1,2]-data[z,2]);ugf=10**(np.log10(data[z,0])+f*np.log10(data[z+1,0]/data[z,0]))/1e6
  acs.append(dict(name=name,style=c['style'],token=c['token'],CL_pF=cl,VC_V=vc,gain_dB=data[0,1],UGF_MHz=ugf,PM_deg=pm,crossings=len(cross)))
 for cl,large in itertools.product([1,5,10],[False,True]):
  lo,hi=(1.5,3.5) if large else (2.5,2.6);d=R/'results'/name/f'tran_cl{cl}_{"large" if large else "small"}'
  text=net(name,cl)+f'''VIN inp 0 dc {lo} pulse({lo} {hi} 10u 10n 10n 40u 80u)
VFB inn out 0
.control
set wr_singlescale
set wr_vecnames
tran 5n 90u
wrdata tran.dat v(inp) v(out) i(vdd)
quit
.endc
.end
''';run(d,'tran',text);data=np.loadtxt(d/'tran.dat',skiprows=1);r=dict(name=name,style=c['style'],token=c['token'],CL_pF=cl,large_step=large)
  for label,start,end,window,target in [('rise',10e-6,49e-6,(47e-6,49e-6),hi),('fall',50.01e-6,89e-6,(87e-6,89e-6),lo)]:
   final=float(np.mean(data[(data[:,0]>window[0])&(data[:,0]<window[1]),2]));mask=(data[:,0]>=start)&(data[:,0]<end);tt=data[mask,0];yy=data[mask,2]
   for mode,center in [('dynamic',final),('total',target)]:
    bad=np.where(abs(yy-center)>.001*(hi-lo))[0];r[label+'_'+mode+'_us']=float((tt[bad[-1]+1]-start)*1e6) if len(bad) and bad[-1]+1<len(tt) else (0.0 if not len(bad) else float('nan'))
   r[label+'_static_error_mV']=(final-target)*1e3
  r['worst_dynamic_us']=max(r['rise_dynamic_us'],r['fall_dynamic_us']);trans.append(r)
 print('Compared',name,flush=True)
for name,rows in [('ac_checks.csv',acs),('settling_checks.csv',trans)]:
 with (R/'results'/name).open('w') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
nom=[]
for c in caps:
 name=c['name'];r=next(x for x in acs if x['name']==name and x['CL_pF']==5 and x['VC_V']==2.5);sm=next(x for x in trans if x['name']==name and x['CL_pF']==5 and not x['large_step']);lg=next(x for x in trans if x['name']==name and x['CL_pF']==5 and x['large_step']);nom.append(dict(**r,minimum_PM_deg=min(x['PM_deg'] for x in acs if x['name']==name),small_settling_us=sm['worst_dynamic_us'],large_settling_us=lg['worst_dynamic_us'],static_error_mV=sm['rise_static_error_mV']))
valid=[x for x in nom if x['minimum_PM_deg']>=60];best=min(valid,key=lambda x:x['large_settling_us']) if valid else None
j=dict(ac_runs=len(acs),transient_runs=len(trans),nominal=nom,selected=best,core_geometry='unchanged tuned current-reference OTA',conditions='5V,27C, nominal SCL deck; CL1/5/10pF x follower bias1.5/2.5/3.5V',qualification='Modern native/raw capacitor exports agree; no physical/PVT/statistical qualification; transistor-model warnings remain')
(R/'results/summary.json').write_text(json.dumps(j,indent=2));print(json.dumps(j,indent=2))
