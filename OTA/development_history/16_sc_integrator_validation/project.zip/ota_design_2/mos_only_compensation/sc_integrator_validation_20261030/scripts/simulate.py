from pathlib import Path
import numpy as np,json,subprocess,itertools,concurrent.futures,csv
R=Path(__file__).resolve().parents[1];MODEL='/home/berson_meshak/pdk/scl08/ngspice_models49/mos/tntp49_5v'
def pwl(events,stop):
 events=sorted(events);return 'PWL('+ ' '.join(f'{t:.12g} {v}' for t,v in events+[(stop,events[-1][1])])+')'
def run(switch='ideal',amp='actual',fs=50000,delta=0,load=5,dt_override=None):
 T=1/fs;warm=50e-6;edge=10e-9;stop=warm+8*T;ev={'p1':[(0,0)],'p2':[(0,0)],'rst':[(0,5)]};samples=[]
 def toggle(k,start,end):ev[k]+=[(start,0),(start+edge,5),(end,5),(end+edge,0)]
 # Reset is initially asserted; two integration frames of three cycles, reset between frames.
 ev['rst'] += [(warm-.05*T,5),(warm-.05*T+edge,0)]
 for frame in [0,1]:
  base=warm+frame*4*T
  if frame:ev['rst'] += [(base-T+.02*T,0),(base-T+.02*T+edge,5),(base-.05*T,5),(base-.05*T+edge,0)]
  for k in range(3):
   t=base+k*T;toggle('p1',t+.02*T,t+.45*T);toggle('p2',t+.52*T,t+.95*T);samples.append((frame,k+1,t+.94*T,t+.52*T+edge,t+.95*T))
 name=f'{amp}_{switch}_{fs}_d{delta}_cl{load}'+(f'_dt{dt_override}' if dt_override else '');d=R/'results'/name;d.mkdir(exist_ok=True)
 s=f'''SC integrator exact figure topology: {name}
.include "{MODEL}"
.include "{R}/models/ota_C_only.spice"
.temp 27
.options reltol=1e-5 vntol=1e-8 abstol=1e-12 numdgt=12
VDD vdd 0 5
VREF ref 0 1.5
VP vp 0 0.3
IREF vdd bias 3.5u
CS tx rx {2.5+delta}p
CF sum out 7.5p
CL out 0 {load}p
'''
 if amp=='actual':s+='XOTA ref sum out vdd 0 bias ota_design2_mos\n'
 else:s+='EOTA out 0 ref sum 1e6\n'
 for k in ev:s+=f'V{k} {k} 0 {pwl(ev[k],stop)}\n'
 if switch=='ideal':
  s+='.model SW SW(Ron=100 Roff=1e12 Vt=2.5 Vh=0)\n'
  for a,b,g in [('tx','vp','p1'),('tx','0','p2'),('rx','0','p1'),('rx','sum','p2'),('sum','out','rst')]:s+=f'S{a}_{b} {a} {b} {g} 0 SW\n'
 else:
  for k in ev:s+=f'B{k}b {k}b 0 V=5-v({k})\n'
  for idx,(a,b,g) in enumerate([('tx','vp','p1'),('tx','0','p2'),('rx','0','p1'),('rx','sum','p2'),('sum','out','rst')]):
   s+=f'MN{idx} {a} {g} {b} 0 N W=10u L=0.8u\nMP{idx} {a} {g}b {b} vdd P W=20u L=0.8u\n'
 dt=dt_override or min(10e-9,T/1000)
 s+=f'''.control
set wr_singlescale
set wr_vecnames
tran {dt:.12g} {stop:.12g}
wrdata transient.dat v(out) v(sum) v(rx) v(tx) v(p1) v(p2) v(rst) i(vdd)
quit
.endc
.end
''';(d/'tb.cir').write_text(s);p=subprocess.run(['ngspice','-b','-o','sim.log','tb.cir'],cwd=d,capture_output=True,text=True,timeout=150);assert p.returncode==0,(name,p.stderr)
 a=np.loadtxt(d/'transient.dat',skiprows=1);step=(2.5+delta)/7.5*(1.5+.3);records=[]
 for frame,k,t,start,end in samples:
  out=float(np.interp(t,a[:,0],a[:,1]));summ=float(np.interp(t,a[:,0],a[:,2]));expected=1.5+k*step
  # Tail slope/ripple diagnostics and actual end-of-phase error are distinct from error to ideal transfer.
  last=float(np.interp(end-20e-9,a[:,0],a[:,1]));early=float(np.interp(end-.15*T,a[:,0],a[:,1]))
  records.append(dict(frame=frame,cycle=k,expected_V=expected,out_V=out,error_mV=(out-expected)*1000,sum_error_mV=(summ-1.5)*1000,late_change_mV=abs(last-early)*1000))
 mask=(a[:,0]>=warm)&(a[:,0]<=warm+7*T);power=float(np.trapz(-5*a[mask,8],a[mask,0])/(7*T)*1e6)
 rec=dict(name=name,switch=switch,amp=amp,fs_Hz=fs,delta_pF=delta,load_pF=load,ideal_step_V=step,max_sample_error_mV=max(abs(x['error_mV']) for x in records),max_sum_error_mV=max(abs(x['sum_error_mV']) for x in records),last_out_V=records[-1]['out_V'],min_out_V=float(a[mask,1].min()),max_out_V=float(a[mask,1].max()),avg_VDD_power_uW=power,samples=records)
 (d/'measurements.json').write_text(json.dumps(rec,indent=2));print(name,rec['max_sample_error_mV'],flush=True);return rec
if __name__=='__main__':
 jobs=[(sw,'actual',f,dc,5) for sw,f,dc in itertools.product(['ideal','tg'],[25000,50000,100000,200000],[0,.05,.1])]+[('ideal','ideal',50000,0,5),('tg','ideal',50000,0,5),('ideal','actual',50000,0,10),('tg','actual',50000,0,10)]
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:rows=list(ex.map(lambda j:run(*j),jobs))
 (R/'summary.json').write_text(json.dumps(rows,indent=2))
 with (R/'summary.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=[k for k in rows[0] if k!='samples']);w.writeheader();w.writerows({k:v for k,v in row.items() if k!='samples'} for row in rows)
