from simulate import *
rows=[run(sw,'actual',50000,0,5,2e-9) for sw in ['ideal','tg']]
(R/'timestep.json').write_text(json.dumps(rows,indent=2))
