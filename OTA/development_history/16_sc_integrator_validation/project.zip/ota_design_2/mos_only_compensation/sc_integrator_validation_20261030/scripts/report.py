from pathlib import Path
import json,numpy as np,matplotlib,hashlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parents[1];j=json.loads((R/'summary.json').read_text());fine=json.loads((R/'timestep.json').read_text())
def get(sw='ideal',amp='actual',fs=50000,dc=0,cl=5):return next(x for x in j if (x['switch'],x['amp'],x['fs_Hz'],x['delta_pF'],x['load_pF'])==(sw,amp,fs,dc,cl))
fig,axs=plt.subplots(3,1,figsize=(12,10),sharex=True)
b=get('ideal');a=np.loadtxt(R/'results'/b['name']/'transient.dat',skiprows=1)
for col,lab,off in [(5,'phi1',0),(6,'phi2',6),(7,'reset',12)]:axs[0].plot(a[:,0]*1e6,a[:,col]+off,label=lab)
axs[0].set(ylabel='Clock levels + offsets (V)',title='Exact figure topology; assumed 50 kHz, two 3-cycle integration frames')
for sw in ['ideal','tg']:
 q=get(sw);a=np.loadtxt(R/'results'/q['name']/'transient.dat',skiprows=1);axs[1].plot(a[:,0]*1e6,a[:,1],label=f'OTA + {sw} switches');axs[2].plot(a[:,0]*1e6,(a[:,2]-1.5)*1e3,label=f'Summing error: {sw}')
pts=[(t*1e6,1.5+k*.6) for frame in [0,1] for k,t in [(1,50e-6+frame*80e-6+18.8e-6),(2,50e-6+frame*80e-6+38.8e-6),(3,50e-6+frame*80e-6+58.8e-6)]];axs[1].plot(*zip(*pts),'ko',label='Analytical sample values')
axs[1].set(ylabel='Output (V)');axs[2].set(xlabel='Time (us)',ylabel='Summing node minus Vref (mV)',ylim=(-10,10),xlim=(45,195))
for ax in axs:ax.grid(alpha=.25);ax.legend(fontsize=8)
fig.tight_layout();fig.savefig(R/'plots/sc_waveforms.png',dpi=170);fig.savefig(R/'plots/sc_waveforms.pdf')
fig,axs=plt.subplots(1,2,figsize=(12,5))
for sw in ['ideal','tg']:
 rr=[get(sw,fs=f) for f in [25000,50000,100000,200000]];axs[0].plot([x['fs_Hz']/1000 for x in rr],[x['max_sample_error_mV'] for x in rr],'-o',label=sw)
for dc in [0,.05,.1]:
 q=get('tg',dc=dc);a=np.loadtxt(R/'results'/q['name']/'transient.dat',skiprows=1);axs[1].plot(a[:,0]*1e6,a[:,1],label=f'Cs= {2.5+dc} pF')
axs[0].set(xlabel='Clock rate (kHz)',ylabel='Maximum raw sample error (mV)',title='Raw accuracy is limited by switch effects in this model');axs[1].set(xlim=(65,110),xlabel='Time (us)',ylabel='Output (V)',title='Transistor switches: sensor response')
for ax in axs:ax.grid(alpha=.25);ax.legend()
fig.tight_layout();fig.savefig(R/'plots/sc_accuracy.png',dpi=170);fig.savefig(R/'plots/sc_accuracy.pdf')
text='''# SC charge-integrator validation with OTA physical_layout_v3

The simulated topology follows the supplied figure: phi1 connects TX to VP and RX to ground; phi2 grounds TX and connects RX to the OTA inverting summing node. CF remains between output and summing node. A reset switch shorts CF before each group of three integration cycles. OTA non-inverting input is VREF. Sensor CS represents CS0+delta CS.

## Assumptions, not finalized project specifications

- SCL08 nominal MOS cards, 5 V supply, 27 C.
- Actual OTA: nine PMOS compensation units, ideal Iref=3.5 uA, newly extracted v3 routing-capacitance model with physical finger/junction geometries.
- VREF=1.5 V; VP=0.3 V. This deliberate moderate excitation keeps three integrations within the previously checked OTA bias/output region. VP is a separate assumed driver voltage, not VDD.
- CS0=2.5 pF; delta CS=0/50/100 fF. CF=7.5 pF. These values are role assignments for this experiment, not a confirmed sensor or capacitor specification.
- Explicit output load 5 pF; nominal 50 kHz. Additional clock tests 25/100/200 kHz and nominal 10 pF load checks.
- Non-overlapping phi1/phi2 pulses, each about 43% of one period, with 10 ns edges. Two frames, three integration cycles per frame, one reset period between frames. Fifty-microsecond startup reset.
- Ideal-switch comparison: Ron=100 ohm, Roff=1e12 ohm. Transistor case: all five switches are CMOS transmission gates, NMOS W/L=10/0.8 um, PMOS=20/0.8 um, ideal complementary 0/5 V gate clocks; NMOS bulk=ground, PMOS bulk=VDD.
- CS and CF are ideal linear capacitors. Only the OTA compensation capacitor uses MOS devices. No claim is made that a suitable physical 7.5 pF SC feedback capacitor has been fabricated or verified.

## Analytical check

In phi1 the sensor RX plate charge is -CS*VP. In phi2 its final plate voltage is approximately VREF with TX=0, so the transferred charge is CS*(VP+VREF). Therefore each output increment is

    step = (CS/CF)*(VP+VREF)
    Vout(k) = VREF + k*step

For CS=2.5 pF and CF=7.5 pF, the step is 0.6 V: 2.1, 2.7 and 3.3 V after reset at 1.5 V. This circuit integrates the full baseline capacitance as drawn; it does not intrinsically cancel CS0. More cycles or a larger CS/CF ratio can saturate the OTA. Reversing the assumed 2.5/7.5 pF roles with these voltages would demand 5.4 V per cycle and is unsuitable on a 5 V supply.

## Measured nominal results, sampled late in phi2

| Amplifier / switches | Third-cycle output (V) | Maximum raw sample error (mV) |
|---|---:|---:|
'''
for amp,sw in [('ideal','ideal'),('actual','ideal'),('ideal','tg'),('actual','tg')]:
 q=get(sw,amp);text+=f"| {amp} / {sw} | {q['last_out_V']:.6f} | {q['max_sample_error_mV']:.4f} |\n"
text+='''
The ideal-amplifier model is a zero-delay VCVS with finite gain 1e6, used only as an attribution control. Its output-stage power is not modeled, and the unused 3.5 uA reference branch remains connected; do not compare its supply power with the actual OTA.

With ideal switches the actual OTA's raw error is about 0.245 mV at 50 kHz. With transistor switches it is about 56.94 mV, or 3.16% of the ideal 1.8 V three-cycle excursion. A hypothetical 0.1% full-excursion accuracy budget would be 1.8 mV, so the raw transistor-switch circuit fails it. This budget is illustrative, not a finalized requirement. Summing-node error at sample times is approximately 0.16 mV, and late-phase output drift is only a few microvolts at 50 kHz. Most accumulated raw error persists with an ideal amplifier, identifying switch-related effects as the larger error source in this simulation. Charge injection, clock feedthrough and junction-capacitance effects have not been individually isolated.

## Clock and load checks

| Clock (kHz) | Actual OTA / ideal-switch maximum raw error (mV) | Actual OTA / TG maximum raw error (mV) |
|---|---:|---:|
'''
for f in [25000,50000,100000,200000]:text+=f"| {f/1000:g} | {get('ideal',fs=f)['max_sample_error_mV']:.4f} | {get('tg',fs=f)['max_sample_error_mV']:.4f} |\n"
text+='\nThe tested clock range does not materially change the raw offset; slowing the clock does not remove it. This does not establish a maximum operating clock. At 50 kHz and 10 pF load, raw error is '+f"{get('ideal',cl=10)['max_sample_error_mV']:.4f} mV with ideal switches and {get('tg',cl=10)['max_sample_error_mV']:.4f} mV with transmission gates.\n"
text+='''
## Small sensor-change response

The following is numerical subtraction of the separately simulated nominal baseline at the same conditions, not an implemented on-chip cancellation circuit. It does not validate calibration across drift or mismatch.

| Sensor increase (fF) | Ideal third-cycle increase (mV) | Actual OTA + TG increase (mV) | Relative error of increase (%) |
|---|---:|---:|---:|
'''
base=get('tg')['last_out_V']
for dc in [.05,.1]:
 actual=(get('tg',dc=dc)['last_out_V']-base)*1000;ideal=3*dc/7.5*1.8*1000;text+=f'| {dc*1000:g} | {ideal:.4f} | {actual:.4f} | {(actual-ideal)/ideal*100:.4f} |\n'
text+='''
## Timestep, power and limitations

Nominal maximum timestep is 10 ns. Repeating both actual-OTA nominal switch cases with 2 ns leaves the ideal-switch third-cycle output unchanged at the displayed precision and shifts the TG result by about 0.014 mV, much less than the 56.9 mV raw error. Raw logs and separate timestep measurements are retained.

Actual OTA + TG VDD power averages about 177.8 uW at nominal 50 kHz. This VDD-current metric excludes power delivered by the ideal VREF/VP sources and ideal clock drivers; it is not total readout or ASIC power.

Conclusion: for this assumed three-cycle, moderate-swing test the OTA's nominal speed is adequate over the tested clocks. The complete transistor-switch circuit is not accurate enough without addressing switch-related errors and baseline handling. Next steps are switch sizing/timing optimization, explicit sensor/routing parasitics, reset/baseline cancellation, and the real ADC/noise/timing budget.

The source OTA model uses the documented extraction-only import adaptation. Full-RC substrate errors and missing qualified well/substrate-junction extraction remain unresolved. The local ngspice translation ignores some PDK/HSPICE parameters, so quantitative clock-feedthrough/charge-injection conclusions are provisional. Sensor/package parasitics, switch interconnect extraction, capacitor voltage dependence/matching, thermal/flicker noise, leakage over temperature, PVT/mismatch, real references/drivers, and an attached ADC were not included. No claim of silicon qualification or final ASIC performance is made.

## Files

summary.csv/json: 28 base simulation results including per-cycle samples; timestep.json: two 2 ns checks; plots/sc_waveforms.png/pdf and sc_accuracy.png/pdf: plots; results/: actual decks, logs and time-series data; models/ota_C_only.spice: newly extracted v3 OTA (proprietary model cards referenced locally); scripts/simulate.py, check_timestep.py and report.py: reproduction; tb/: portable relative-model nominal decks. Run nominal decks from tb using ngspice -b. Scripts regenerate full-result benches using the current project location. Existing raw benches reference their staging paths. No PDK sources were altered and no GitHub publication was performed.
'''
(R/'README.md').write_text(text)
for sw in ['ideal','tg']:
 q=get(sw);s=(R/'results'/q['name']/'tb.cir').read_text().replace(str(R)+'/models/','../models/').replace('wrdata transient.dat',f'wrdata nominal_{sw}.dat');(R/'tb'/f'nominal_{sw}.cir').write_text(s)
(R/'model_hash.json').write_text(json.dumps({'ota_C_only_sha256':hashlib.sha256((R/'models/ota_C_only.spice').read_bytes()).hexdigest()},indent=2))
