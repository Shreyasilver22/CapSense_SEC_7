from run import *
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
cs=json.loads((R/'candidates.json').read_text())
passing=[c for c in cs if c['min_PM_deg']>=60]
balanced=min([c for c in passing if c['I_uA']==2.5],key=lambda c:c['N'])
margin=min([c for c in cs if c['I_uA']==2.5 and c['min_PM_deg']>=65],key=lambda c:c['N'])
fast=max(passing,key=lambda c:c['UGF_MHz']);low=min(passing,key=lambda c:(c['power_uW'],c['N']))
choices={ (6,2.5), *((c['N'],c['I_uA']) for c in [balanced,margin,fast,low])}
def tran(n,i,cl,large,dt=5):
 lo,hi=(1.5,3.5) if large else (2.5,2.6);tag='large' if large else 'small';d=R/f'results/n{n}_i{i}/tran_{tag}_cl{cl}_{dt}ns';d.mkdir(parents=True,exist_ok=True)
 s=base(n,i,cl)+f'''VIN inp 0 dc {lo} pulse({lo} {hi} 10u 10n 10n 40u 80u)
VFB inn out 0
.control
set wr_singlescale
set wr_vecnames
tran {dt}n 90u
wrdata tran.dat v(inp) v(out)
quit
.endc
.end
''';(d/'tran.cir').write_text(s);p=subprocess.run(['ngspice','-b','-o','tran.log','tran.cir'],cwd=d,capture_output=True,timeout=120);assert p.returncode==0
 a=np.loadtxt(d/'tran.dat',skiprows=1);sett=[];errors=[]
 for start,end,target in [(10e-6,49e-6,hi),(50.01e-6,89e-6,lo)]:
  final=float(np.mean(a[(a[:,0]>end-2e-6)&(a[:,0]<end),2]));mask=(a[:,0]>=start)&(a[:,0]<end);tt=a[mask,0];yy=a[mask,2];bad=np.where(abs(yy-final)>.001*(hi-lo))[0];sett.append(float((tt[bad[-1]+1]-start)*1e6) if len(bad) and bad[-1]+1<len(tt) else (0. if not len(bad) else None));errors.append((final-target)*1000)
 return dict(N=n,I_uA=i,CL_pF=cl,step=tag,dt_ns=dt,settling_us=max(sett) if all(x is not None for x in sett) else None,final_error_mV=max(abs(x) for x in errors))
jobs=[(n,i,cl,large) for n,i in sorted(choices) for cl,large in itertools.product([1,5,10],[False,True])]
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:trs=list(ex.map(lambda x:tran(*x),jobs))
save('transients',trs)
stress=[]
for c in [balanced,margin,fast,low]:
 stress.append(ac(c['N'],c['I_uA'],5,4))
 for ex in [1,3]:stress.append(ac(c['N'],c['I_uA'],10,2.5,ex))
save('stress',stress)
fine=[tran(margin['N'],margin['I_uA'],10,True,1)];save('timestep_check',fine)
result={'minimum_change':balanced,'margin_candidate':margin,'fastest_UGF_passing':fast,'lowest_power_passing':low,'evaluated_finalists':[list(x) for x in sorted(choices)],'qualification':'What-if sizing with fixed v2 extracted routing C. No updated layout extraction; missing well parasitics and full RC remain unresolved.'}
(R/'selection.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
fig,axs=plt.subplots(1,2,figsize=(12,5))
for i in [1.5,2,2.5,3.5,5]:
 rr=[x for x in cs if x['I_uA']==i];axs[0].plot([x['N'] for x in rr],[x['min_PM_deg'] for x in rr],'-o',label=f'Iref {i} uA')
axs[0].axhline(60,ls='--',color='black');axs[0].axhline(65,ls=':',color='gray');axs[0].set(xlabel='Equivalent MOS capacitor units',ylabel='Worst phase margin (degrees)',title='1/5/10 pF; bias 1.5/2.5/3.5 V')
for n,i in sorted(choices):
 a=np.loadtxt(R/f'results/n{n}_i{i}/tran_large_cl10_5ns/tran.dat',skiprows=1);axs[1].plot(a[:,0]*1e6,a[:,2],label=f'N={n}, I={i} uA')
axs[1].set(xlim=(9.5,18),xlabel='Time (us)',ylabel='Output (V)',title='2 V step into 10 pF')
for ax in axs:ax.grid(alpha=.25);ax.legend(fontsize=8)
fig.tight_layout();fig.savefig(R/'plots/retuning.png',dpi=170);fig.savefig(R/'plots/retuning.pdf')
