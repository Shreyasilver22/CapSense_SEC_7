from pathlib import Path
import re,json
R=Path(__file__).resolve().parents[1];s=(R/'pex/ota_extracted.spice').read_text()
# Contract only extracted wire resistors to independently test transistor topology.
parent={}
def root(a):
 parent.setdefault(a,a)
 if parent[a]!=a:parent[a]=root(parent[a])
 return parent[a]
rs=[x.split() for x in s.splitlines() if x.startswith('R')]
for x in rs:parent[root(x[2])]=root(x[1])
groups={}
for n in list(parent):groups.setdefault(root(n),[]).append(n)
preferred=['INP','INN','OUT','VDD','VSS','IREF']
ren={}
for v in groups.values():
 pick=next((n for n in preferred if n in v),min(v,key=len))
 for n in v:ren[n]=pick
ls=[]
for line in s.splitlines():
 if line.startswith(('R','C')):continue
 if line.startswith('M'):
  a=line.split();a[1:5]=[ren.get(n,n) for n in a[1:5]];line=' '.join(a)
 ls.append(line)
(R/'schematic/rc_contracted_topology.cdl').write_text('\n'.join(ls)+'\n')
# Keep native extracted bulk connections and junction geometry; only model-name casing changes.
for filename in ['ota_extracted.spice','ota_C_only.spice']:
 p=R/'pex'/filename;text=p.read_text();text=re.sub(r'(?m)^(M\S+\s+\S+\s+\S+\s+\S+\s+\S+)\s+([np])\b',lambda m:m[1]+' '+m[2].upper(),text);p.write_text(text)
(R/'pex/device_geometry_only.spice').write_text('\n'.join(x for x in (R/'pex/ota_C_only.spice').read_text().splitlines() if not x.startswith('C'))+'\n')
print('Extracted resistors:',len(rs),'capacitors:',sum(x.startswith('C') for x in s.splitlines()))
