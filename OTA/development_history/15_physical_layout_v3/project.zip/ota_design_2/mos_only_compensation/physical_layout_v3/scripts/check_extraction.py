from pathlib import Path
import subprocess
R=Path(__file__).resolve().parents[1];deck='/home/berson_meshak/pdk/scl08/analog_pdk/Open_Source_SCL_0.8micron_PDK/open_source_scl_cp8d/open_pdks/scl_cp8d/libs.tech/klayout/tech/lvs/lvs_os_scl_cp8d.lvs'
s=(R/'pex/ota_C_only.spice').read_text();(R/'schematic/C_topology.cdl').write_text('\n'.join(x for x in s.splitlines() if not x.startswith('C'))+'\n')
for ref,tag in [('C_topology.cdl','C_topology'),('rc_contracted_topology.cdl','RC_topology')]:
 args=['klayout','-b','-r',deck,'-rd',f'input={R}/layout/ota_design2_mos.gds','-rd',f'schematic1={R}/schematic/{ref}','-rd',f'report={R}/verification/{tag}.lvsdb','-rd',f'target_netlist1={R}/verification/{tag}.cir'];p=subprocess.run(args,capture_output=True,text=True);(R/f'verification/{tag}.log').write_text(p.stdout+p.stderr);assert p.returncode==0 and 'Netlists match.' in p.stdout,(p.stdout,p.stderr)
s=(R/'verification/schematic.spice').read_text();assert 'MCAP out n2 out out P w=20u l=10u m=9' in s
s=(R/'verification/native_tb.spice').read_text();assert 'IREF vdd iref 3.5u' in s
p=subprocess.run(['ngspice','-b','-o','native_tb.log','native_tb.spice'],cwd=R/'verification',capture_output=True,text=True);assert p.returncode==0,p.stderr
print('Extraction topology checks and native xschem simulation PASS')
