from pathlib import Path
import numpy as np,json,hashlib,subprocess
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parents[1];j=json.loads((R/'simulations/summary.json').read_text());out=[]
for name in ['schematic','previous_sizing','new_C_extracted','new_RC_diagnostic']:
 rr=[x for x in j['ac'] if x['variant']==name and x['VC_V']<=3.5];nom=next(x for x in rr if x['CL_pF']==5 and x['VC_V']==2.5);log=(R/f'simulations/{name}/ac_cl5_v2.5.log').read_text();import re
 power=-5e6*float(re.search(r'^i\(vdd\)\s*=\s*([-+\d.eE]+)',log,re.M)[1]);out.append(dict(**nom,min_PM_deg=min(x['PM_deg'] for x in rr),power_uW=power,large_10p_us=next(x['settling_us'] for x in j['transients'] if x['variant']==name and x['step']=='large_cl10'),small_10p_us=next(x['settling_us'] for x in j['transients'] if x['variant']==name and x['step']=='small_cl10')))
a=np.loadtxt(R/'simulations/new_C_extracted/large_cl10_fine.dat',skiprows=1);sett=[]
for start,end in [(10e-6,49e-6),(50.01e-6,89e-6)]:
 final=np.mean(a[(a[:,0]>end-2e-6)&(a[:,0]<end),2]);mask=(a[:,0]>=start)&(a[:,0]<end);t=a[mask,0];v=a[mask,2];bad=np.where(abs(v-final)>.002)[0];sett.append(float((t[bad[-1]+1]-start)*1e6))
report=dict(nominal_and_grid=out,fine_1ns_large_10p_us=max(sett),stress_4V=[x for x in j['ac'] if x['VC_V']==4],layout_extent_um=[462.5,243.9],layout_area_mm2=462.5*243.9/1e6,DRC='0 markers, original SCL local KLayout deck',LVS='MATCH against independent updated reference',schematic='xschem netlisted m=9, IREF=3.5u; native testbench simulated',extraction_topology='C model and resistor-contracted RC model each match verified GDS in KLayout',extraction_limits='Import-filtered exploratory capacitance extraction; RC retains substrate errors; well-junction/substrate network unqualified; no PVT/SC system validation')
(R/'verification/final_summary.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
fig,axs=plt.subplots(1,3,figsize=(15,4.5))
for name,label in [('previous_sizing','Previous sizing estimate'),('new_C_extracted','New C extraction'),('new_RC_diagnostic','New RC: diagnostic')]:
 a=np.loadtxt(R/f'simulations/{name}/ac_cl5_v2.5.dat',skiprows=1);t=np.loadtxt(R/f'simulations/{name}/large_cl10.dat',skiprows=1);axs[0].semilogx(a[:,0],a[:,1],label=label);axs[1].semilogx(a[:,0],a[:,2],label=label);axs[2].plot(t[:,0]*1e6,t[:,2],label=label)
axs[0].set(xlim=(1e3,1e8),xlabel='Frequency (Hz)',ylabel='Gain (dB)');axs[1].set(xlim=(1e4,1e8),xlabel='Frequency (Hz)',ylabel='Phase (degrees)');axs[2].set(xlim=(9.5,16),xlabel='Time (us)',ylabel='Output (V)',title='2 V step into 10 pF')
for ax in axs:ax.grid(alpha=.25);ax.legend(fontsize=7)
fig.suptitle('Nine physical MOS capacitor units; IREF=3.5 uA; 5 V / 27 C');fig.tight_layout();fig.savefig(R/'plots/new_extraction.png',dpi=170);fig.savefig(R/'plots/new_extraction.pdf')
# Portable extracted-C bench alongside the native schematic bench.
s=(R/'simulations/new_C_extracted/large_cl10.cir').read_text().replace(str(R)+'/pex/','../pex/').replace('wrdata large_cl10.dat','wrdata extracted_large_10p.dat');(R/'tb/extracted_large_10p.cir').write_text(s)
files=[R/'layout/ota_design2_mos.gds',R/'schematic/reference.cdl',R/'pex/ota_C_only.spice',R/'pex/ota_extracted.spice'];(R/'verification/hashes.json').write_text(json.dumps({str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},indent=2))
