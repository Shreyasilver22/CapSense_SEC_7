import pya,json
from pathlib import Path
R=Path(__file__).resolve().parents[1];l=pya.Layout();l.read(str(R/'layout/ota_design2_mos.gds'));c=l.top_cell();data=[]
for li in l.layer_indexes():
 info=l.get_info(li)
 if info.datatype!=0:continue
 for sh in c.shapes(li).each():
  if sh.is_box():
   b=sh.box;data.append([info.layer,b.left*l.dbu,b.bottom*l.dbu,b.right*l.dbu,b.top*l.dbu])
(R/'verification/geometry.json').write_text(json.dumps(data))
