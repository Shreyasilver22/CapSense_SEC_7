from pathlib import Path
import subprocess,xml.etree.ElementTree as ET,json
R=Path(__file__).resolve().parents[1];tech=Path('/home/berson_meshak/pdk/scl08/analog_pdk/Open_Source_SCL_0.8micron_PDK/open_source_scl_cp8d/open_pdks/scl_cp8d/libs.tech/klayout/tech')
def run(kind,ref='reference.cdl',tag=''):
 args=['klayout','-b','-r',str(tech/('drc/cp8d_drc.drc' if kind=='drc' else 'lvs/lvs_os_scl_cp8d.lvs')),'-rd',f'input={R}/layout/ota_design2_mos.gds']
 if kind=='drc':args+=['-rd',f'report1={R}/verification/drc.lyrdb']
 else:args+=['-rd',f'schematic1={R}/schematic/{ref}','-rd',f'target_netlist1={R}/verification/extracted{tag}.cir','-rd',f'report={R}/verification/lvs{tag}.lvsdb']
 p=subprocess.run(args,capture_output=True,text=True);(R/f'verification/{kind}{tag}.log').write_text(p.stdout+p.stderr);assert p.returncode==0,p.stderr
 return p.stdout+p.stderr
run('drc');log=run('lvs');assert 'Netlists match.' in log
s=(R/'schematic/reference.cdl').read_text()
(R/'schematic/negative_wrong_gate.cdl').write_text(s.replace('MCAP OUT N2','MCAP OUT VDD'))
(R/'schematic/negative_wrong_size.cdl').write_text(s.replace('W=112u','W=100u'))
for tag in ['wrong_gate','wrong_size']:
 log=run('lvs','negative_'+tag+'.cdl','_negative_'+tag);assert "Netlists don't match" in log,'Negative control unexpectedly passed'
r=ET.parse(R/'verification/drc.lyrdb');items=r.findall('.//items/item')
summary={'drc_markers':len(items),'lvs':'MATCH against independent resolved schematic','negative_gate_control':'MISMATCH as expected','negative_width_control':'MISMATCH as expected','deck':'local SCL CP8D KLayout decks, unmodified','limits':'Local-deck checks; not foundry signoff. No extracted-RC simulation yet.'}
(R/'verification/summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
