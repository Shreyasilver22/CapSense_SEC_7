from pathlib import Path
import json,re,shutil,subprocess
import numpy as np
R=Path(__file__).resolve().parents[1];CAP=Path('/home/berson_meshak/final year project/capacitors/layout_optimization_v1')
old=Path('/home/berson_meshak/final year project/ota/ota_design_1/extracted_capacitor_analysis');j=json.loads((R/'results/summary.json').read_text());sel=j['selected'];name=sel['name'];value=sel['token'];style=sel['style'];cc=next(c for c in json.loads((R/'results/cap_catalog.json').read_text())['capacitors'] if c['name']==name)
for d in ['designs','symbols','tb']:(R/d).mkdir(exist_ok=True)
shutil.copy2(CAP/'symbols/capopt3.sym',R/'symbols/capopt3.sym');shutil.copy2(CAP/'scripts/symbol_helpers.tcl',R/'scripts/symbol_helpers.tcl');shutil.copy2(CAP/'models/catalog.tcl',R/'models/catalog.tcl')
# Freeze current transistor geometry and physically connect all three capacitor terminals.
s=(old/'designs/ota_extracted_cc.sch').read_text();s=s.replace('{scl08_cap3.sym}','{capopt3.sym}').replace('{name=XCC value=8p}',f'{{name=XCC style={style} value={value} hide_texts=true}}')
s=re.sub(r'T \{SCL800[^\n]*\} 0 -20[^\n]*', 'T {SCL800 OTA with layout-optimized compensation} 0 -20 0 0 0.5 0.5 {}',s)
s=s.replace('Cc target=8p; extracted mutual=8.00295 pF, plus substrate parasitics.',f'Cc target={value}; {style} extracted model, including substrate parasitics.')
s+=f'''T {{XCC: {style}, target {value}
Cm = {cc['Cmut_F']*1e12:.5g} pF
Cn2 = {cc['Ctop_sub_F']*1e12:.4g} pF; Cout = {cc['Cbot_sub_F']*1e12:.4g} pF}} 720 535 0 0 0.22 0.22 {{}}
'''
(R/'designs/ota_layout_opt.sch').write_text(s);shutil.copy2(old/'designs/ota_extracted_cc.sym',R/'designs/ota_layout_opt.sym')
rc=(old/'xschemrc').read_text();rc=rc[:rc.index('source [file join $project_root designs catalog.tcl]')];rc=rc.replace('$project_root/designs:$project_root/tb:','$project_root/designs:$project_root/tb:$project_root/symbols:');rc+='\nsource [file join $project_root scripts symbol_helpers.tcl]\n';(R/'xschemrc').write_text(rc)
private='/home/berson_meshak/pdk/scl08/ngspice_models49/mos/tntp49_5v'
(R/'spice/models.inc').write_text('* Local private deck; not bundled.\n.include "'+private+'"\n')
tb=(old/'tb/ota_extracted_cc_tb.sch').read_text().replace('ota_extracted_cc','ota_layout_opt').replace('.include '+private,'.include ../spice/models.inc').replace('../designs/capacitors.lib.spice','../models/cap_layouts.lib.spice').replace('Cc=8p extracted model','Cc=slotted 4p extracted model');(R/'tb/ota_layout_opt_tb.sch').write_text(tb)
def portable(text):return text.replace('"'+private+'"','"../spice/models.inc"').replace(str(R)+'/models/','../models/')
for label,source in [('selected_ac',R/'results'/name/'ac_cl5_vc2.5/ac.cir'),('selected_small',R/'results'/name/'tran_cl5_small/tran.cir'),('selected_large',R/'results'/name/'tran_cl5_large/tran.cir')]:
 text=portable(source.read_text()).replace('wrdata ac.dat',f'wrdata ../results/{label}.dat').replace('wrdata tran.dat',f'wrdata ../results/{label}.dat');(R/'tb'/(label+'.cir')).write_text(text)
def run(cmd,d,log):
 p=subprocess.run(cmd,cwd=d,capture_output=True,text=True,timeout=90);log.write_text(p.stdout+p.stderr);assert p.returncode==0,(cmd,p.stdout,p.stderr)
fine=R/'results/selected_fine';fine.mkdir(exist_ok=True);(fine/'tran.cir').write_text((R/'results'/name/'tran_cl5_large/tran.cir').read_text().replace('tran 5n','tran 1n'));run(['ngspice','-b','-o','tran.log','tran.cir'],fine,fine/'run.log');data=np.loadtxt(fine/'tran.dat',skiprows=1);settle=[]
for start,end,window in [(10e-6,49e-6,(47e-6,49e-6)),(50.01e-6,89e-6,(87e-6,89e-6))]:
 final=np.mean(data[(data[:,0]>window[0])&(data[:,0]<window[1]),2]);mask=(data[:,0]>=start)&(data[:,0]<end);tt=data[mask,0];yy=data[mask,2];bad=np.where(abs(yy-final)>.002)[0];settle.append(float((tt[bad[-1]+1]-start)*1e6))
for source,out in [(R/'designs/ota_layout_opt.sch','extracted.spice'),(R/'tb/ota_layout_opt_tb.sch','ota_layout_opt_tb.spice')]:run(['xschem','-x','-q','-n','-s','--rcfile',str(R/'xschemrc'),'-o',str(R/'results'),'-N',out,str(source)],R,R/'results'/(out+'.netlist.log'))
s=(R/'results/extracted.spice').read_text();assert f'XCC n2 out vss {name}' in s,s
expected={'M1':'n1 inn tail vss N','M2':'n2 inp tail vss N','M3':'n1 n1 vdd vdd P','M4':'n2 n1 vdd vdd P','M5':'tail iref vss vss N','M6':'out n2 vdd vdd P','M7':'out iref vss vss N','M8':'iref iref vss vss N'}
for m,nodes in expected.items():assert next(l for l in s.splitlines() if l.startswith(m+' ')).split()[1:6]==nodes.split()
widths=[7.5,7.5,10,10,20,112,160,20];lengths=[2.4,2.4,3.2,3.2,3.2,3.2,3.2,3.2]
for i in range(8):assert f'w={widths[i]:g}u l={lengths[i]:g}u' in next(l for l in s.splitlines() if l.startswith(f'M{i+1} '))
inc='\n'.join(l.replace('**.subckt','.subckt').replace('**.ends','.ends') for l in s.splitlines() if l!='.end');(R/'models/extracted.inc').write_text(inc)
text=(R/'tb/selected_ac.cir').read_text().replace('../models/'+name+'_ota.inc','../models/extracted.inc');text=re.sub(r'ota_tuned LI=.*?\n','ota_layout_opt\n',text);(R/'tb/extracted_ac.cir').write_text(text)
run(['ngspice','-b','-o','../results/extracted_ac.log','extracted_ac.cir'],R/'tb',R/'results/extracted_ac_run.log');a=np.loadtxt(R/'results/selected_ac.dat',skiprows=1);b=np.loadtxt(R/'results'/name/'ac_cl5_vc2.5/ac.dat',skiprows=1);assert np.allclose(a,b,rtol=1e-6,atol=1e-6)
run(['ngspice','-b','-o','ota_layout_opt_tb.log','ota_layout_opt_tb.spice'],R/'results',R/'results/native_run.log')
for n in ['selected_ac','selected_small','selected_large']:run(['ngspice','-b','-o','../results/'+n+'.log',n+'.cir'],R/'tb',R/'results'/(n+'_run.log'))
j['selected_capacitor']=cc;j['verification']=dict(native_OTA_MOS_connectivity_geometry='PASS: unchanged',compensation_pin_mapping='TOP=n2 BOT=out SUB=vss verified',extracted_AC_matches_parameterized='PASS',native_testbench='netlisted and simulated',selected_portable_benches='PASS',fine_large_step_us=max(settle),fine_timestep_delta_ns=abs(max(settle)-sel['large_settling_us'])*1000)
(R/'results/summary.json').write_text(json.dumps(j,indent=2));print(json.dumps(dict(selected=sel,verification=j['verification']),indent=2))
