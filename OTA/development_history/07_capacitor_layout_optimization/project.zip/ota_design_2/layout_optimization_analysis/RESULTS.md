# OTA comparison with layout-derived capacitor models

| Capacitor | UGF (MHz) | Nominal PM (deg) | Min checked PM (deg) | 100 mV settling (us) | 2 V settling (us) |
|---|---:|---:|---:|---:|---:|
| capopt_baseline_3p | 0.905 | 57.86 | 50.74 | 1.259 | 3.154 |
| capopt_compact_3p | 0.918 | 59.40 | 52.15 | 1.219 | 3.129 |
| capopt_slotted_3p | 0.967 | 66.11 | 58.71 | 0.804 | 2.980 |
| capopt_baseline_4p | 0.700 | 60.85 | 54.68 | 1.569 | 4.094 |
| capopt_compact_4p | 0.711 | 62.44 | 56.18 | 1.504 | 4.054 |
| capopt_slotted_4p | 0.742 | 69.23 | 63.09 | 1.034 | 3.675 |
| capopt_baseline_8p | 0.364 | 65.79 | 61.80 | 2.124 | 7.818 |
| capopt_compact_8p | 0.368 | 67.44 | 63.46 | 2.109 | 7.573 |
| capopt_slotted_8p | 0.380 | 74.13 | 70.56 | 1.914 | 7.509 |

Settling is 0.1% of step amplitude around actual final output, worst polarity, 5 ns max timestep. Static error (~-0.206 mV for the small step) is separate. All cases retain the same transistor geometry, 2.5 uA ideal reference, 5 V, 27 C, TOP=n2/BOT=out/SUB=vss. Min PM spans CL1/5/10 pF x follower bias1.5/2.5/3.5 V. The 81 AC and 54 base transient runs are nominal-deck continuous-time follower checks, not PVT or an SC system simulation. Models omit routing resistance and all unresolved extraction/model limitations remain.
