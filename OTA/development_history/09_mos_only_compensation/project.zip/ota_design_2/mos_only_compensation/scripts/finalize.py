from pathlib import Path
import json,re,shutil,subprocess,math
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parents[1];old=Path('/home/berson_meshak/final year project/ota/ota_design_2/layout_optimization_analysis');j=json.loads((R/'results/summary.json').read_text());n=j['selected']['N']
s=(old/'designs/ota_layout_opt.sch').read_text()
for line in ['C {capopt3.sym} 840 500 3 0 {name=XCC style=slotted value=4p hide_texts=true}\n','N 760 500 780 500 {lab=n2}\n','N 900 500 960 500 {lab=out}\n','N 900 400 900 420 {lab=vss}\n','C {devices/lab_pin.sym} 900 400 0 0 {name=lcsub lab=vss}\n']:
 assert line in s,line;s=s.replace(line,'')
s=s[:s.index('T {XCC: slotted')]
s=s.replace('SCL800 OTA with layout-optimized compensation','SCL800 OTA - MOS-only compensation').replace('Cc target=4p; slotted extracted model, including substrate parasitics.',f'MOS compensation: {n} x PMOS W20/L10 um; no multiplier; well parasitics not yet extracted.')
s+=f'''C {{devices/pmos4.sym}} 840 500 0 0 {{name=MCAP model=P w=20u l=10u m={n} hide_texts=true}}
N 760 500 820 500 {{lab=n2}}
N 860 470 900 470 {{lab=out}}
N 860 500 900 500 {{lab=out}}
N 860 530 900 530 {{lab=out}}
N 900 470 900 500 {{lab=out}}
N 900 500 900 530 {{lab=out}}
N 900 500 960 500 {{lab=out}}
T {{MCAP: {n} parallel PMOS, W20/L10 um
Gate = n2; source/drain/body = out
Intrinsic modeled C = {j['selected']['nominal_gate_C_pF']:.3f} pF at nominal bias
Isolated N-well required; layout/well parasitics omitted}} 690 560 0 0 0.2 0.2 {{}}
''';(R/'designs/ota_mos_only.sch').write_text(s);shutil.copy2(old/'designs/ota_layout_opt.sym',R/'designs/ota_mos_only.sym')
rc=(old/'xschemrc').read_text();rc=rc[:rc.index('source [file join $project_root scripts symbol_helpers.tcl]')];(R/'xschemrc').write_text(rc)
private='/home/berson_meshak/pdk/scl08/ngspice_models49/mos/tntp49_5v'
tb=(old/'tb/ota_layout_opt_tb.sch').read_text().replace('ota_layout_opt','ota_mos_only').replace('.include ../models/cap_layouts.lib.spice\n','').replace('Cc=slotted 4p extracted model',f'MOS Cc: {n} x W20/L10 PMOS, no multiplier');(R/'tb/ota_mos_only_tb.sch').write_text(tb)
for label,source in [('selected_ac',R/'results'/f'n{n}'/'ac_cl5_vc2.5_well0/ac.cir'),('selected_small',R/'results'/f'n{n}'/'tran_cl5_small_well0_5ns/tran.cir'),('selected_large',R/'results'/f'n{n}'/'tran_cl5_large_well0_5ns/tran.cir')]:
 text=source.read_text().replace(str(R)+'/spice/models.inc','../spice/models.inc').replace(str(R)+'/models/','../models/').replace('wrdata ac.dat',f'wrdata ../results/{label}.dat').replace('wrdata tran.dat',f'wrdata ../results/{label}.dat');(R/'tb'/(label+'.cir')).write_text(text)
def run(cmd,d,log):
 p=subprocess.run(cmd,cwd=d,capture_output=True,text=True,timeout=60);log.write_text(p.stdout+p.stderr);assert p.returncode==0,(p.stdout,p.stderr)
for file,out in [(R/'designs/ota_mos_only.sch','extracted.spice'),(R/'tb/ota_mos_only_tb.sch','ota_mos_only_tb.spice')]:run(['xschem','-x','-q','-n','-s','--rcfile',str(R/'xschemrc'),'-o',str(R/'results'),'-N',out,str(file)],R,R/'results'/(out+'.netlist.log'))
s=(R/'results/extracted.spice').read_text();assert f'MCAP out n2 out out P w=20u l=10u m={n}' in s,s;assert 'BMULT' not in s
expected={'M1':'n1 inn tail vss N','M2':'n2 inp tail vss N','M3':'n1 n1 vdd vdd P','M4':'n2 n1 vdd vdd P','M5':'tail iref vss vss N','M6':'out n2 vdd vdd P','M7':'out iref vss vss N','M8':'iref iref vss vss N'}
for name,nodes in expected.items():assert next(x for x in s.splitlines() if x.startswith(name+' ')).split()[1:6]==nodes.split()
widths=[7.5,7.5,10,10,20,112,160,20];lengths=[2.4,2.4,3.2,3.2,3.2,3.2,3.2,3.2]
for i in range(8):assert f'w={widths[i]:g}u l={lengths[i]:g}u' in next(x for x in s.splitlines() if x.startswith(f'M{i+1} '))
inc='\n'.join(l.replace('**.subckt','.subckt').replace('**.ends','.ends') for l in s.splitlines() if l!='.end');(R/'models/extracted.inc').write_text(inc)
text=(R/'tb/selected_ac.cir').read_text().replace('../models/ota_mos.inc','../models/extracted.inc');text=re.sub(r'ota_tuned LI=.*?\n','ota_mos_only\n',text);(R/'tb/extracted_ac.cir').write_text(text);run(['ngspice','-b','-o','../results/extracted_ac.log','extracted_ac.cir'],R/'tb',R/'results/extracted_ac_run.log')
a=np.loadtxt(R/'results/selected_ac.dat',skiprows=1);b=np.loadtxt(R/'results'/f'n{n}'/'ac_cl5_vc2.5_well0/ac.dat',skiprows=1);assert np.allclose(a,b,rtol=1e-6,atol=1e-6)
run(['ngspice','-b','-o','ota_mos_only_tb.log','ota_mos_only_tb.spice'],R/'results',R/'results/native_run.log')
for name in ['selected_ac','selected_small','selected_large']:run(['ngspice','-b','-o','../results/'+name+'.log',name+'.cir'],R/'tb',R/'results'/(name+'_run.log'))
j['verification']=dict(unchanged_core='eight-MOS connectivity/model/geometry checked',MOS_capacitor='MCAP gate=n2 source/drain/body=out, m=6 verified',multiplier='NONE',native_schematic_AC='matches hand netlist',native_testbench='netlisted and simulated',portable_benches='PASS')
def clean(x):
 if isinstance(x,float) and not math.isfinite(x):return None
 if isinstance(x,dict):return {k:clean(v) for k,v in x.items()}
 if isinstance(x,list):return [clean(v) for v in x]
 return x
(R/'results/summary.json').write_text(json.dumps(clean(j),indent=2,allow_nan=False))
fig,axs=plt.subplots(2,2,figsize=(12,8))
for nn in [4,6,10]:
 d=R/'results'/f'n{nn}';a=np.loadtxt(d/'ac_cl5_vc2.5_well0/ac.dat',skiprows=1);t=np.loadtxt(d/'tran_cl5_large_well0_5ns/tran.dat',skiprows=1);axs[0,0].semilogx(a[:,0],a[:,1],label=f'{nn} MOS units');axs[0,1].plot(t[:,0]*1e6,t[:,2],label=f'{nn} MOS units')
axs[0,0].set(xlabel='Frequency (Hz)',ylabel='Gain (dB)',xlim=(1e3,1e8));axs[0,1].set(xlabel='Time (us)',ylabel='Output (V)',xlim=(9,17),title='2 V step; explicit CL=5 pF')
for nn in [4,5,6,8,10]:
 import csv
 rows=list(csv.DictReader((R/'results/ac_checks.csv').open()));pts=sorted([(float(x['CL_pF']),float(x['PM_deg'])) for x in rows if int(x['N'])==nn and float(x['VC_V'])==2.5]);axs[1,0].plot(*zip(*pts),'-o',label=f'N={nn}')
axs[1,0].axhline(60,color='k',ls='--');axs[1,0].set(xlabel='Explicit CL (pF)',ylabel='Phase margin (degrees)',title='At 2.5 V follower bias')
pts=[(x['VC_V'],x['PM_deg']) for x in j['output_bias_stress']]+[(2.5,j['selected']['PM_deg'])];pts.sort();axs[1,1].plot(*zip(*pts),'-o');axs[1,1].axhline(60,color='k',ls='--');axs[1,1].set(xlabel='Follower DC input (V)',ylabel='Phase margin (degrees)',title='Extra bias stress; not qualified rail-to-rail')
for ax in axs.flat:ax.grid(alpha=.25)
for ax in [axs[0,0],axs[0,1],axs[1,0]]:ax.legend(fontsize=8)
fig.tight_layout();fig.savefig(R/'plots/mos_only_comparison.png',dpi=180);fig.savefig(R/'plots/mos_only_comparison.pdf');plt.close(fig)
print(json.dumps(dict(selected=j['selected'],verification=j['verification']),indent=2))
