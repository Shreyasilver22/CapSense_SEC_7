from pathlib import Path
import subprocess,json,csv,itertools,re,math
import numpy as np
R=Path(__file__).resolve().parents[1];model='/home/berson_meshak/pdk/scl08/ngspice_models49/mos/tntp49_5v'
source=Path('/home/berson_meshak/final year project/ota/ota_design_2/mos_cap_multiplier_feasibility/models/ota_base.inc').read_text();(R/'models/ota_base.inc').write_text(source)
(R/'models/ota_mos.inc').write_text(source.replace('CC=20p','CC=20p NM=6').replace('Cc n2 out {CC}','MCAP out n2 out out P W=20u L=10u M={NM}'))
(R/'spice/models.inc').write_text('* Private local model reference; no model cards copied.\n.include "'+model+'"\n')
def common(n,cl,well=0):return f'''SCL800 MOS-only compensation N={n}, CL={cl}p, hypothetical well C={well}p
.include "{R}/spice/models.inc"
.include "{R}/models/ota_mos.inc"
.temp 27
.options reltol=1e-5 vntol=1e-8 abstol=1e-12 numdgt=12
VDD vdd 0 5
IREF vdd bias 2.5u
CL out 0 {cl}p
CWELL out 0 {well}p
XU inp inn out vdd 0 bias ota_tuned LI=2.4u LM=3.2u LO=3.2u K=4 NM={n}
'''
def run(d,name,s):
 d.mkdir(parents=True,exist_ok=True);(d/(name+'.cir')).write_text(s);p=subprocess.run(['ngspice','-b','-o',name+'.log',name+'.cir'],cwd=d,capture_output=True,text=True,timeout=60);assert p.returncode==0,(d,p.stdout,p.stderr)
def ac(n,cl,vc,well=0):
 d=R/'results'/f'n{n}'/f'ac_cl{cl}_vc{vc}_well{well}'
 s=common(n,cl,well)+f'''VIN inp 0 dc {vc} ac 1
LDC out inn 1e12
CAC inn 0 1e12
.control
set wr_singlescale
set wr_vecnames
op
print v(out) v(xu.n2) i(vdd)
ac dec 150 1 1G
let gd=db(v(out))
let pd=180/PI*cph(v(out))
wrdata ac.dat gd pd
quit
.endc
.end
''';run(d,'ac',s);a=np.loadtxt(d/'ac.dat',skiprows=1);cross=np.where(a[:-1,1]*a[1:,1]<0)[0];pm=ugf=float('nan')
 if len(cross)==1:
  z=cross[0];f=-a[z,1]/(a[z+1,1]-a[z,1]);pm=180+a[z,2]+f*(a[z+1,2]-a[z,2]);ugf=10**(np.log10(a[z,0])+f*np.log10(a[z+1,0]/a[z,0]))/1e6
 vals={m[1]:float(m[2]) for m in re.finditer(r'^([^\s=]+)\s*=\s*([-+\d.eE]+)',(d/'ac.log').read_text(),re.M)}
 return dict(N=n,CL_pF=cl,VC_V=vc,well_stress_pF=well,gain_dB=float(a[0,1]),UGF_MHz=ugf,PM_deg=pm,crossings=len(cross),quiescent_power_uW=-5e6*vals['i(vdd)'],gate_body_dc_V=vals['v(xu.n2)']-vals['v(out)'])
def tran(n,cl,large,well=0,dt=5):
 lo,hi=(1.5,3.5) if large else (2.5,2.6);d=R/'results'/f'n{n}'/f'tran_cl{cl}_{"large" if large else "small"}_well{well}_{dt}ns'
 s=common(n,cl,well)+f'''VIN inp 0 dc {lo} pulse({lo} {hi} 10u 10n 10n 40u 80u)
VFB inn out 0
.control
set wr_singlescale
set wr_vecnames
tran {dt}n 90u
wrdata tran.dat v(inp) v(out) v(xu.n2)
quit
.endc
.end
''';run(d,'tran',s);t=np.loadtxt(d/'tran.dat',skiprows=1);r=dict(N=n,CL_pF=cl,large_step=large,well_stress_pF=well,timestep_ns=dt)
 for label,start,end,window,target in [('rise',10e-6,49e-6,(47e-6,49e-6),hi),('fall',50.01e-6,89e-6,(87e-6,89e-6),lo)]:
  final=np.mean(t[(t[:,0]>window[0])&(t[:,0]<window[1]),2]);mask=(t[:,0]>=start)&(t[:,0]<end);tt=t[mask,0];yy=t[mask,2];bad=np.where(abs(yy-final)>.001*(hi-lo))[0];r[label+'_settling_us']=float((tt[bad[-1]+1]-start)*1e6) if len(bad) and bad[-1]+1<len(tt) else (0.0 if not len(bad) else float('nan'));r[label+'_static_error_mV']=float((final-target)*1e3)
 r['worst_settling_us']=max(r['rise_settling_us'],r['fall_settling_us']);r['gate_body_min_V']=float((t[:,3]-t[:,2]).min());r['gate_body_max_V']=float((t[:,3]-t[:,2]).max());r['out_min_V']=float(t[:,2].min());r['out_max_V']=float(t[:,2].max());return r
acs=[];trs=[]
for n in [4,5,6,8,10]:
 for cl,vc in itertools.product([1,5,10],[1.5,2.5,3.5]):acs.append(ac(n,cl,vc))
 for cl,large in itertools.product([1,5,10],[False,True]):trs.append(tran(n,cl,large))
 print('Completed MOS array',n,flush=True)
nom=[]
for n in [4,5,6,8,10]:
 r=next(x for x in acs if x['N']==n and x['CL_pF']==5 and x['VC_V']==2.5);small=next(x for x in trs if x['N']==n and x['CL_pF']==5 and not x['large_step']);large=next(x for x in trs if x['N']==n and x['CL_pF']==5 and x['large_step']);nom.append(dict(**r,minimum_checked_PM_deg=min(x['PM_deg'] for x in acs if x['N']==n),small_settling_us=small['worst_settling_us'],large_settling_us=large['worst_settling_us'],gate_area_um2=200*n,nominal_gate_C_pF=.412549932*n))
valid=[r for r in nom if r['minimum_checked_PM_deg']>=60];selected=min(valid,key=lambda x:x['large_settling_us']);n=selected['N']
stress=[ac(n,5,2.5,well) for well in [1,3,5]];stress_tr=[tran(n,5,True,well) for well in [1,3,5]];high_output=[ac(n,5,v) for v in [.5,4,4.5]];fine=tran(n,5,True,0,1)
for filename,rows in [('ac_checks.csv',acs),('settling_checks.csv',trs),('well_load_stress.csv',stress),('well_load_stress_transients.csv',stress_tr),('output_bias_stress.csv',high_output)]:
 with (R/'results'/filename).open('w') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
j=dict(nominal=nom,selected=selected,well_load_stress=stress,well_load_stress_transients=stress_tr,output_bias_stress=high_output,fine_large_step=fine,actual_well_capacitance='Unknown; stress values are hypothetical additional output loads, not extracted well capacitances',multiplier='None: only a PMOS gate-capacitor array',qualification='Intrinsic MOS pre-layout feasibility; nwell/substrate parasitics, layout, model compatibility and PVT remain open')
(R/'results/summary.json').write_text(json.dumps(j,indent=2));print(json.dumps(j,indent=2))
