from pathlib import Path
import json,hashlib
R=Path(__file__).resolve().parents[1];j=json.loads((R/'selection.json').read_text());cs=json.loads((R/'all_candidates.json').read_text());checks=json.loads((R/'selected_checks.json').read_text());stress=json.loads((R/'stress.json').read_text())
rows=[]
for label,x in [('Existing six-unit baseline',next(x for x in cs if x['N']==6)),('Previous ten-unit margin choice',next(x for x in cs if x['N']==10 and x['I_uA']==2.5)),('Balanced study choice',j['balanced']),('Fastest at >=63 degrees',j['fastest_with_63deg']),('Fastest at >=65 degrees',j['fastest_with_65deg'])]:
 rows.append(f"| {label} | {x['N']} | {x['I_uA']} | {x['power_uW']:.2f} | {x['UGF_MHz']:.3f} | {x['min_PM_deg']:.2f} | {x['small_settling_us']:.3f} | {x['large_settling_us']:.3f} |")
text='''# Current versus MOS compensation optimization — 30 October 2026

This study refines the current/capacitance tradeoff after the previous ten-unit choice slowed settling. It varies equivalent PMOS capacitor count and ideal reference current, preserving transistor sizing in the OTA core and the physical_layout_v2 routing-capacitance model.

The refined grid is N=8/9/10/11 with Iref=3/3.5/4/4.5/5 uA, plus six-unit/2.5 uA, eight-unit/2.5 uA and ten-unit/2.5 uA comparison points. Every pair has nine AC cases: CL=1/5/10 pF and follower DC input=1.5/2.5/3.5 V. Supply=5 V, temperature=27 C, local SCL08 transistor model, ngspice. Each pair has 100 mV and 2 V follower transient tests at 10 pF. Finalists have 2 V transients at 5 pF and a 1 ns timestep repeat at 10 pF, plus separate high-bias and extra-load stress AC checks.

## Selection criteria

All 23 pairs are retained so the user can change the objective. The study labels a candidate passing when its minimum phase margin across the nine checked points is >=63 degrees: a provisional three-degree reserve over the earlier 60-degree target. The balanced choice is the fastest large-step candidate within a provisional 180 uW supply-power ceiling. Neither 63 degrees nor 180 uW is a finalized ASIC requirement. A separate >=65-degree choice is also reported. Bandwidth is measured at the nominal 5 pF, 2.5 V point. Phase margin below is the worst of all nine AC points. Power includes the ideal current-reference branch, excluding a practical reference generator.

| Candidate | MOS units | Iref (uA) | Power (uW) | Nominal UGF (MHz) | Minimum PM (deg) | 100 mV settling at 10 pF (us) | 2 V settling at 10 pF (us) |
|---|---:|---:|---:|---:|---:|---:|---:|
'''+ '\n'.join(rows)+'''

Settling uses a 0.1% band about actual final output for each applied step, worst of rising/falling edges, not total ideal conversion accuracy. Input transitions are 10 ns, transients 90 us, maximum step 5 ns except explicit repeats. Static final errors are recorded in transients_10p.csv. Power and speed must ultimately be assessed with the actual SC feedback factor and settling window.

## Limits and interpretation

This is a what-if sizing simulation using the previous extracted C model. Six capacitor branches are scaled by multiplicity N/6, including their existing junction geometry terms. Fixed extracted routing capacitances are not regenerated for changed array size. Larger arrays require new layout, DRC/LVS and extraction before these numerical advantages can be relied on. The source extraction uses the previously documented marker-import workaround; qualified well-junction capacitance/diode behavior and full RC remain unresolved. Model-translation warnings, PVT, mismatch, complete SC circuit loading, and physical current-reference overhead remain open. No PDK files were modified and no GitHub publication was performed.

Hypothetical extra 1 pF output-load tests are sensitivity checks, not estimates of well capacitance. The 4 V input tests remain outside the main selection grid; consult stress.csv before assuming high-swing operation. Passing a sparse nominal grid does not establish continuous-range or process-corner qualification.

## Files

all_candidates.csv/json: complete tradeoff table; ac_grid.csv/json: all 207 main-grid AC results; transients_10p.csv/json: 46 large/small transient results; selection.json: objective and choices; selected_checks.csv/json: repeat/5 pF settling; stress.csv/json: finalist checks; plots/current_cap_tradeoff.png/pdf: speed/power comparison; results/: native benches, logs and data. models/: sizing-study models without proprietary transistor cards. scripts/engine.py, transient.py and optimize.py reproduce the work against the local SCL08 installation. scripts/document.py builds this report and relative-path finalist benches in tb/. Saved raw benches reference staging paths; rerunning the scripts regenerates those paths from the current project directory.

'''
text+='## Finalist stress measurements\n\n| Units | Iref (uA) | Load (pF) | DC input (V) | Extra hypothetical load (pF) | PM (degrees) |\n|---:|---:|---:|---:|---:|---:|\n'
for x in stress:text+=f"| {x['N']} | {x['I_uA']} | {x['CL_pF']} | {x['VC_V']} | {x['extra_pF']} | {x['PM_deg']:.2f} |\n"
(R/'README.md').write_text(text)
tb=R/'tb';tb.mkdir(exist_ok=True)
for label in ['balanced','fastest_with_63deg','fastest_with_65deg']:
 x=j[label];p=R/f"results/n{x['N']}_i{x['I_uA']}/tran_large_cl10_1ns/tran.cir";s=p.read_text().replace(str(R)+'/models/','../models/');s=s.replace('wrdata tran.dat',f'wrdata {label}.dat');(tb/(label+'.cir')).write_text(s)
(R/'model_hashes.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (R/'models').glob('*')},indent=2))
print('\n'.join(rows))
