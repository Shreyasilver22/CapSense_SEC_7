from engine import *
from transient import tran
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
pairs=list(itertools.product([8,9,10,11],[3,3.5,4,4.5,5]))+[(6,2.5),(8,2.5),(10,2.5)]
jobs=[(n,i,cl,v) for n,i in pairs for cl,v in itertools.product([1,5,10],[1.5,2.5,3.5])]
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:acs=list(ex.map(lambda x:ac(*x),jobs))
save('ac_grid',acs);summary=[]
for n,i in pairs:
 rr=[x for x in acs if x['N']==n and x['I_uA']==i];nom=next(x for x in rr if x['CL_pF']==5 and x['VC_V']==2.5);summary.append(dict(**nom,min_PM_deg=min(x['PM_deg'] if x['PM_deg'] is not None else -999 for x in rr)))
save('ac_candidates',summary);print('AC complete',flush=True)
jobs=[(n,i,10,big) for n,i in pairs for big in [False,True]]
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:trs=list(ex.map(lambda x:tran(*x),jobs))
save('transients_10p',trs)
for row in summary:
 for size in ['small','large']:row[size+'_settling_us']=next(x['settling_us'] for x in trs if x['N']==row['N'] and x['I_uA']==row['I_uA'] and x['step']==size)
valid=[x for x in summary if x['min_PM_deg']>=63 and x['large_settling_us'] is not None]
pareto=[x for x in valid if not any(y['power_uW']<=x['power_uW'] and y['large_settling_us']<=x['large_settling_us'] and (y['power_uW']<x['power_uW'] or y['large_settling_us']<x['large_settling_us']) for y in valid)]
# Balanced choice: fastest candidate under 180 uW with >=63 degrees in the tested grid.
balanced=min([x for x in valid if x['power_uW']<=180],key=lambda x:x['large_settling_us'])
fastest=min(valid,key=lambda x:x['large_settling_us'])
margin=min([x for x in summary if x['min_PM_deg']>=65 and x['large_settling_us'] is not None],key=lambda x:x['large_settling_us'])
selected={ (x['N'],x['I_uA']) for x in [balanced,fastest,margin] }
stress=[ac(n,i,10,2.5,1) for n,i in selected]+[ac(n,i,5,4) for n,i in selected]
extra=[tran(n,i,5,True,2) for n,i in selected]+[tran(n,i,10,True,1) for n,i in selected]
save('stress',stress);save('selected_checks',extra);save('all_candidates',summary)
result=dict(balanced=balanced,fastest_with_63deg=fastest,fastest_with_65deg=margin,pareto=pareto,criteria='63 degrees minimum across nine load/bias points; balanced power ceiling 180 uW is a provisional study choice, not a user specification.',limits='Fixed v2 routing capacitances; new capacitor geometry not re-extracted. Missing qualified well parasitics and full RC, no PVT/mismatch/SC validation.')
(R/'selection.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2),flush=True)
fig,ax=plt.subplots(figsize=(9,6))
for n in [6,8,9,10,11]:
 pts=[x for x in summary if x['N']==n];pts.sort(key=lambda x:x['power_uW']);ax.plot([x['power_uW'] for x in pts],[x['large_settling_us'] for x in pts],'-o',label=f'{n} MOS units')
for x in summary:
 if x['min_PM_deg']<63:ax.plot(x['power_uW'],x['large_settling_us'],'kx',ms=9)
ax.set(xlabel='Nominal supply power (uW)',ylabel='2 V settling at 10 pF (us)',title='Current / MOS-capacitor tradeoff; crosses: minimum PM below 63 degrees');ax.legend();ax.grid(alpha=.25);fig.tight_layout();fig.savefig(R/'plots/current_cap_tradeoff.png',dpi=170);fig.savefig(R/'plots/current_cap_tradeoff.pdf')
