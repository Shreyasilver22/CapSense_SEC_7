crashbackups stop
drc off
gds read ota_design2_mos.gds
load ota_design2_mos
select top cell
save ota_design2_mos
gds write ota_design2_mos_magic_roundtrip.gds
quit -noprompt
