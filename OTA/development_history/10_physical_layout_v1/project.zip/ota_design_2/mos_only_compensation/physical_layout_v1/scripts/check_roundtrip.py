import pya,json
from pathlib import Path
R=Path(__file__).resolve().parents[1];a=pya.Layout();b=pya.Layout();a.read(str(R/'layout/ota_design2_mos.gds'));b.read(str(R/'verification/magic_import_diagnostic/ota_design2_mos_magic_roundtrip.gds'));diff={}
for n in [1,2,3,4,5,6,7,8,9,10]:
 ra=pya.Region(a.top_cell().begin_shapes_rec(a.layer(n,0)));rb=pya.Region(b.top_cell().begin_shapes_rec(b.layer(n,0)))
 rb.transform(pya.ICplxTrans(b.dbu/a.dbu,0,False,0,0));v=ra^rb
 if not v.is_empty():diff[n]=v.area()*a.dbu*a.dbu
(R/'verification/magic_roundtrip.json').write_text(json.dumps({'layer_difference_area_um2':diff},indent=2));print(diff)
