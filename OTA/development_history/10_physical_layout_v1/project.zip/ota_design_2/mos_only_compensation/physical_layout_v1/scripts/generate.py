import pya
from pathlib import Path
R=Path(__file__).resolve().parents[1]; ly=pya.Layout();ly.dbu=.001;c=ly.create_cell('ota_design2_mos')
def box(layer,x1,y1,x2,y2):c.shapes(ly.layer(layer,0)).insert(pya.DBox(x1,y1,x2,y2))
def text(layer,x,y,s):c.shapes(ly.layer(layer,7)).insert(pya.DText(s,pya.DTrans(pya.DVector(x,y))))
def contact(x,y):box(7,x-.6,y-.6,x+.6,y+.6);box(8,x-1.1,y-1.1,x+1.1,y+1.1)
def via(x,y):box(9,x-.75,y-.75,x+.75,y+.75);box(8,x-1.5,y-1.5,x+1.5,y+1.5);box(10,x-1.5,y-1.5,x+1.5,y+1.5)
nets=['INP','INN','OUT','VDD','VSS','IREF','N1','N2','TAIL']; by={n:-i*6 for i,n in enumerate(nets)}
dev=[]
def add(name,d,g,s,b,t,w,l,count=1):
 for k in range(count):dev.append((name+('_'+str(k) if count>1 else ''),d,g,s,b,t,w,l))
add('M1','N1','INN','TAIL','VSS','N',7.5,2.4);add('M2','N2','INP','TAIL','VSS','N',7.5,2.4)
add('M3','N1','N1','VDD','VDD','P',10,3.2);add('M4','N2','N1','VDD','VDD','P',10,3.2)
add('M5','TAIL','IREF','VSS','VSS','N',20,3.2);add('M8','IREF','IREF','VSS','VSS','N',20,3.2)
add('M6','OUT','N2','VDD','VDD','P',14,3.2,8);add('M7','OUT','IREF','VSS','VSS','N',20,3.2,8)
add('MCAP','OUT','N2','OUT','OUT','P',20,10,6)
x=10
for name,d,g,s,b,t,w,l in dev:
 y=70; gx=x+8; sx=gx-3; dx=gx+l+3; bx=gx+l+10
 box(2,gx-4.5,y,gx+l+4.5,y+w)
 box(4,gx,y-1.5,gx+l,y+w+5)
 # poly contact outside active; route gate on M1 above device to its own drop
 gc=gx+l/2; contact(gc,y+w+3.2)
 box(8,x-1.1,y+w+2.1,gc+1.1,y+w+4.3)
 for tx,ty,n in [(x,y+w+3.2,g),(sx,y+w/2,s),(dx,y+w/2,d),(bx,y+3,b)]:
  box(8,tx-1.1,by[n],tx+1.1,ty+1.1);via(tx,by[n])
 contact(sx,y+w/2);contact(dx,y+w/2)
 box(2,bx-1.5,y+1.5,bx+1.5,y+4.5);contact(bx,y+3)
 if t=='P':
  box(1,gx-8,y-5,bx+5,y+w+7)
  box(3,gx-10,y-7,bx+7,y+w+9)
  for la in [5,6]:box(la,gx-5.2,y-.7,gx+l+5.2,y+w+.7)
 else:
  for la in [5,6]:box(la,bx-2.2,y+.8,bx+2.2,y+5.2)
 pass # Internal routing is unlabeled to avoid creating extra cell ports
 x+=l+34
for n in nets:
 box(10,0,by[n]-1.5,x,by[n]+1.5)
 if n in nets[:6]:text(10,2,by[n],n)
ly.write(str(R/'layout/ota_design2_mos.gds'))
lines=['* Exact implemented transistor reference; folded devices remain explicit.','.subckt ota_design2_mos INP INN OUT VDD VSS IREF']
for name,d,g,s,b,t,w,l in dev:lines.append(f'{name} {d} {g} {s} {b} {t} W={w}u L={l}u')
lines+=['.ends ota_design2_mos'];(R/'schematic/ota_design2_mos.cdl').write_text('\n'.join(lines)+'\n')
print('devices',len(dev),'bbox',c.dbbox())
