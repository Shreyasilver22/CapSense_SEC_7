from pathlib import Path
import json,csv,subprocess
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parents[1];j=json.loads((R/'results/summary.json').read_text());rows=j['cases'];cv=list(csv.DictReader((R/'results/mos_cv.csv').open()))
# Validate the ideal current multiplier reproduces the full-size MOS response.
a=np.loadtxt(R/'results/mos_full/ac.dat',skiprows=1);b=np.loadtxt(R/'results/mos_small_ideal_5x/ac.dat',skiprows=1);assert np.allclose(a,b,rtol=1e-6,atol=1e-6)
m=np.loadtxt(R/'results/ideal_matched_4p1255/ac.dat',skiprows=1);assert np.allclose(a,m,rtol=1e-5,atol=1e-5)
# Freeze readable selected testbenches with local private-model configuration.
(R/'spice').mkdir(exist_ok=True);private='/home/berson_meshak/pdk/scl08/ngspice_models49/mos/tntp49_5v';(R/'spice/models.inc').write_text('* Private local SCL deck, not bundled.\n.include "'+private+'"\n')
for name in ['ideal_4p','metal_refined_4p','mos_full','mos_small','mos_small_ideal_5x']:
 for kind in ['ac','small','large']:
  text=(R/'results'/name/(kind+'.cir')).read_text().replace('"'+private+'"','"../spice/models.inc"').replace(str(R)+'/models/','../models/').replace('wrdata ac.dat',f'wrdata ../results/{name}_ac.dat').replace('wrdata '+kind+'.dat',f'wrdata ../results/{name}_{kind}.dat');(R/'tb'/(name+'_'+kind+'.cir')).write_text(text)
# Re-run one delivered behavioral multiplier bench to verify portable includes.
p=subprocess.run(['ngspice','-b','-o','../results/portable_multiplier.log','mos_small_ideal_5x_ac.cir'],cwd=R/'tb',capture_output=True,text=True,timeout=60);assert p.returncode==0,p.stdout+p.stderr
j['verification']={'full_MOS_vs_ideal_5x_AC':'PASS: matches to tolerance','MOS_vs_equal_C_ideal_AC':'PASS: matches in tested accumulation bias','portable_multiplier_bench':'PASS','actual_multiplier_hardware':'NOT implemented','MOS_layout_and_well_substrate_parasitics':'NOT implemented'};(R/'results/summary.json').write_text(json.dumps(j,indent=2))
fig,axs=plt.subplots(2,2,figsize=(12,8))
axs[0,0].plot([float(x['Vgate_body_V']) for x in cv],[float(x['C_1M_pF']) for x in cv]);axs[0,0].axvspan(.1825,2.198,alpha=.15,color='green',label='OTA large-step Vgate-body range');axs[0,0].set(xlabel='Gate minus body voltage (V)',ylabel='Gate C (pF)',title='Full MOS capacitor, 1 MHz small-signal model');axs[0,0].legend(fontsize=7)
for name in ['ideal_4p','metal_refined_4p','mos_full','mos_small','mos_small_ideal_5x']:
 ac=np.loadtxt(R/'results'/name/'ac.dat',skiprows=1);t=np.loadtxt(R/'results'/name/'large.dat',skiprows=1)
 axs[0,1].semilogx(ac[:,0],ac[:,1],label=name);axs[1,0].semilogx(ac[:,0],ac[:,2],label=name);axs[1,1].plot(t[:,0]*1e6,t[:,2],label=name)
axs[0,1].set(xlabel='Frequency (Hz)',ylabel='Gain (dB)',xlim=(1e3,1e8));axs[1,0].set(xlabel='Frequency (Hz)',ylabel='Phase (degrees)',xlim=(1e3,1e8));axs[1,1].set(xlabel='Time (us)',ylabel='Output (V)',xlim=(9,18),title='1.5 to 3.5 V follower step')
for ax in axs.flat:ax.grid(alpha=.25)
for ax in [axs[0,1],axs[1,0],axs[1,1]]:ax.legend(fontsize=7)
fig.tight_layout();fig.savefig(R/'plots/mos_multiplier_comparison.png',dpi=180);fig.savefig(R/'plots/mos_multiplier_comparison.pdf');plt.close(fig)
table='| Case | UGF (MHz) | Phase margin (deg) | 100mV settling (us) | 2V settling (us) |\n|---|---:|---:|---:|---:|\n'
for r in rows:table+=f"| {r['name']} | {r['UGF_MHz']:.3f} | {r['PM_deg']:.2f} | {r['small_settling_us']:.3f} | {r['large_settling_us']:.3f} |\n"
(R/'RESULTS.md').write_text('# Simple MOS-capacitor / ideal-multiplier OTA simulation\n\n'+table+'\nSix AC cases, twelve follower transients, plus41gate-bias AC characterization points. MOS full-size capacitance is about4.1255pF in the tested positive Vgate-body range. Full MOS and small-MOS/ideal5x responses match numerically. This is expected from the behavioral construction; no practical multiplier feasibility, power or noise performance is established.\n\nThe small MOS alone has ~0.8251pF and fails the initial>=60degree phase-margin screen, despite its faster transient response. The full MOS and ideal5x cases have only intrinsic gate-C model loading; real N-well/substrate and layout parasitics are omitted. Metal/MOS differences are therefore not a fair final post-layout comparison.\n')
print('Comparison plotted; behavioral equivalence and portable bench verified')
