from pathlib import Path
import subprocess,json,re,csv
import numpy as np
R=Path(__file__).resolve().parents[1];MOS='/home/berson_meshak/pdk/scl08/ngspice_models49/mos/tntp49_5v'
source=Path('/home/berson_meshak/final year project/ota/ota_design_2/further_capacitor_analysis/models/ota_base.inc').read_text()
metal=Path('/home/berson_meshak/final year project/capacitors/layout_optimization_v2/models/cap_layouts.lib.spice');(R/'models/metal_caps.inc').write_bytes(metal.read_bytes());(R/'models/ota_base.inc').write_text(source)
def run(d,name,net):
 d.mkdir(parents=True,exist_ok=True);(d/(name+'.cir')).write_text(net);p=subprocess.run(['ngspice','-b','-o',name+'.log',name+'.cir'],cwd=d,capture_output=True,text=True,timeout=60)
 assert p.returncode==0,(d,p.stdout,p.stderr)
# PMOS gate is one capacitor terminal; source/drain/body share the other in an isolated N-well.
# No physical N-well/substrate capacitance is included; this is a pre-layout MOS gate-C test.
variants={
 'ideal_4p':'Cc n2 out 4p',
 'ideal_matched_4p1255':'Cc n2 out 4.12549932p',
 'metal_refined_4p':'XCC n2 out vss cap2_w24_g1p5_r3_i0p5',
 'mos_full':'VSENSE n2 gc 0\nMCAP out gc out out P W=20u L=10u M=10',
 'mos_small':'VSENSE n2 gc 0\nMCAP out gc out out P W=20u L=10u M=2',
 'mos_small_ideal_5x':'VSENSE n2 gc 0\nMCAP out gc out out P W=20u L=10u M=2\nBMULT n2 out I={4*i(VSENSE)}'
}
rows=[]
for name,cap in variants.items():
 (R/'models'/(name+'.inc')).write_text(source.replace('Cc n2 out {CC}',cap))
 d=R/'results'/name
 common=f'''Tuned SCL800 OTA: {name}
.include "{MOS}"
.include "{R}/models/metal_caps.inc"
.include "{R}/models/{name}.inc"
.temp 27
.options reltol=1e-5 vntol=1e-8 abstol=1e-12 numdgt=12
VDD vdd 0 5
IREF vdd bias 2.5u
CL out 0 5p
XU inp inn out vdd 0 bias ota_tuned LI=2.4u LM=3.2u LO=3.2u K=4
'''
 ac=common+'''VIN inp 0 dc 2.5 ac 1
LDC out inn 1e12
CAC inn 0 1e12
.control
set wr_singlescale
set wr_vecnames
op
print v(out) v(xu.n2) i(vdd)
ac dec 150 1 1G
let gd=db(v(out))
let pd=180/PI*cph(v(out))
wrdata ac.dat gd pd
quit
.endc
.end
''';run(d,'ac',ac);a=np.loadtxt(d/'ac.dat',skiprows=1);cross=np.where(a[:-1,1]*a[1:,1]<0)[0];pm=ugf=float('nan')
 if len(cross)==1:
  z=cross[0];f=-a[z,1]/(a[z+1,1]-a[z,1]);pm=180+a[z,2]+f*(a[z+1,2]-a[z,2]);ugf=10**(np.log10(a[z,0])+f*np.log10(a[z+1,0]/a[z,0]))/1e6
 log=(d/'ac.log').read_text();vals={m[1]:float(m[2]) for m in re.finditer(r'^([^\s=]+)\s*=\s*([-+\d.eE]+)',log,re.M)}
 row=dict(name=name,gain_dB=float(a[0,1]),UGF_MHz=ugf,PM_deg=pm,crossings=len(cross),quiescent_power_uW=-5e6*vals['i(vdd)'],n2_dc_V=vals['v(xu.n2)'],out_dc_V=vals['v(out)'],gate_area_um2=2000 if name=='mos_full' else (400 if name.startswith('mos_small') else None))
 for label,lo,hi in [('small',2.5,2.6),('large',1.5,3.5)]:
  tr=common+f'''VIN inp 0 dc {lo} pulse({lo} {hi} 10u 10n 10n 40u 80u)
VFB inn out 0
.control
set wr_singlescale
set wr_vecnames
tran 5n 90u
wrdata {label}.dat v(inp) v(out) v(xu.n2)
quit
.endc
.end
''';run(d,label,tr);t=np.loadtxt(d/(label+'.dat'),skiprows=1);settle=[]
  for edge,start,end,window,target in [('rise',10e-6,49e-6,(47e-6,49e-6),hi),('fall',50.01e-6,89e-6,(87e-6,89e-6),lo)]:
   final=np.mean(t[(t[:,0]>window[0])&(t[:,0]<window[1]),2]);mask=(t[:,0]>=start)&(t[:,0]<end);tt=t[mask,0];yy=t[mask,2];bad=np.where(abs(yy-final)>.001*(hi-lo))[0];st=float((tt[bad[-1]+1]-start)*1e6) if len(bad) and bad[-1]+1<len(tt) else (0.0 if not len(bad) else float('nan'));settle.append(st);row[label+'_'+edge+'_static_error_mV']=float((final-target)*1e3)
  row[label+'_settling_us']=max(settle);row[label+'_out_min_V']=float(t[:,2].min());row[label+'_out_max_V']=float(t[:,2].max());row[label+'_gate_body_min_V']=float((t[:,3]-t[:,2]).min());row[label+'_gate_body_max_V']=float((t[:,3]-t[:,2]).max())
 rows.append(row);print(name,'PM',pm,'UGF',ugf,'small/large settling',row['small_settling_us'],row['large_settling_us'],flush=True)
# Full-size MOS C-V at a fixed 2.5V body; AC gate=1V, all intrinsic transistor terminals otherwise fixed.
cv=[]
for vg in np.linspace(0,5,41):
 d=R/'results/cv'/f'{vg:.3f}';net=f'''PMOS gate capacitance test
.include "{MOS}"
.options reltol=1e-6 vntol=1e-9 abstol=1e-13 numdgt=12
VB b 0 2.5
VG g 0 dc {vg} ac 1
MC b g b b P W=20u L=10u M=10
.control
set wr_singlescale
set wr_vecnames
ac dec 3 1k 1meg
let cp=abs(imag(i(VG)))/(2*PI*frequency)
wrdata cv.dat real(cp)
quit
.endc
.end
''';run(d,'cv',net);data=np.loadtxt(d/'cv.dat',skiprows=1);cv.append(dict(Vgate_body_V=float(vg-2.5),C_1k_pF=float(data[0,1]*1e12),C_1M_pF=float(data[-1,1]*1e12)))
for name,data in [('summary.csv',rows),('mos_cv.csv',cv)]:
 with (R/'results'/name).open('w') as f:w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
(R/'results/summary.json').write_text(json.dumps(dict(cases=rows,multiplier='Behavioral ideal current multiplication, M=5. No physical multiplier amplifier, poles, noise, power or saturation modeled.',MOS_configuration='PMOS gate=n2; S/D/body=out; isolated well assumed, well-substrate parasitics omitted.',temperature_C=27,supply_V=5,load_pF=5),indent=2));print(json.dumps(rows,indent=2))
