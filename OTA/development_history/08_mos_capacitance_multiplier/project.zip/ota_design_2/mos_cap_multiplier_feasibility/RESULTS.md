# Simple MOS-capacitor / ideal-multiplier OTA simulation

| Case | UGF (MHz) | Phase margin (deg) | 100mV settling (us) | 2V settling (us) |
|---|---:|---:|---:|---:|
| ideal_4p | 0.763 | 76.58 | 1.094 | 3.871 |
| ideal_matched_4p1255 | 0.741 | 76.86 | 1.144 | 3.991 |
| metal_refined_4p | 0.748 | 70.95 | 0.944 | 3.720 |
| mos_full | 0.741 | 76.86 | 1.144 | 3.991 |
| mos_small | 2.824 | 46.80 | 0.694 | 1.135 |
| mos_small_ideal_5x | 0.741 | 76.86 | 1.144 | 3.991 |

Six AC cases, twelve follower transients, plus41gate-bias AC characterization points. MOS full-size capacitance is about4.1255pF in the tested positive Vgate-body range. Full MOS and small-MOS/ideal5x responses match numerically. This is expected from the behavioral construction; no practical multiplier feasibility, power or noise performance is established.

The small MOS alone has ~0.8251pF and fails the initial>=60degree phase-margin screen, despite its faster transient response. The full MOS and ideal5x cases have only intrinsic gate-C model loading; real N-well/substrate and layout parasitics are omitted. Metal/MOS differences are therefore not a fair final post-layout comparison.
