# Reconstruct summary from completed numeric tables after interrupted report generation.
from pathlib import Path
import csv,json,numpy as np
R=Path(__file__).resolve().parents[1];j=json.loads((R/'results/summary.json').read_text())
a=list(csv.DictReader((R/'results/ac_checks.csv').open()));t=list(csv.DictReader((R/'results/settling_checks.csv').open()))
for x in a:
 for k in ['CL_pF','VC_V','gain_dB','UGF_MHz','PM_deg','crossings','power_uW']:x[k]=float(x[k])
for x in t:
 for k in ['CL_pF','worst_dynamic_us','rise_static_error_mV']:x[k]=float(x[k])
for name in ['metal_6p_top_n2','metal_8p_top_n2','metal_10p_top_n2']:
 aa=next(x for x in a if x['name']==name and x['CL_pF']==5 and x['VC_V']==2.5);s=next(x for x in t if x['name']==name and x['CL_pF']==5 and x['large_step']=='False');l=next(x for x in t if x['name']==name and x['CL_pF']==5 and x['large_step']=='True');j['nominal'].append(dict(**aa,small_worst_dynamic_us=s['worst_dynamic_us'],large_worst_dynamic_us=l['worst_dynamic_us'],small_static_error_mV=s['rise_static_error_mV'],minimum_checked_PM_deg=min(x['PM_deg'] for x in a if x['name']==name)))
j['ac_runs']=len(a);j['transient_runs']=len(t);valid=[x for x in j['nominal'] if x['name'].startswith('metal') and x['minimum_checked_PM_deg']>=60];j['selected']=min(valid,key=lambda x:x['large_worst_dynamic_us'])
v=j['selected'];data=np.loadtxt(R/'results'/v['name']/'cl5_large_1ns/tran.dat',skiprows=1);fine={}
for label,start,end,window in [('rise',10e-6,49e-6,(47e-6,49e-6)),('fall',50.01e-6,89e-6,(87e-6,89e-6))]:
 final=np.mean(data[(data[:,0]>window[0])&(data[:,0]<window[1]),2]);mask=(data[:,0]>=start)&(data[:,0]<end);tt=data[mask,0];yy=data[mask,2];bad=np.where(abs(yy-final)>.002)[0];fine[label+'_dynamic_us']=float((tt[bad[-1]+1]-start)*1e6)
fine['worst_dynamic_us']=max(fine.values());j['selected_fine_large']=fine
(R/'results/summary.json').write_text(json.dumps(j,indent=2));print(json.dumps(j['nominal'][-3:],indent=2));print('SELECTED',v['name'])
