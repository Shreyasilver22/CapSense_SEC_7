from pathlib import Path
import json,re,subprocess,shutil
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parents[1];P=Path('/home/berson_meshak/final year project');old=P/'ota/ota_design_1/current_reference_exploration/stage_tuning';j=json.loads((R/'results/summary.json').read_text());chosen=j['selected'];value=chosen['value']
cats=json.loads((P/'capacitors/scl08_capacitor_library_v2/results/catalog.json').read_text())['capacitors']+json.loads((R/'cap_variants/results/catalog.json').read_text())['capacitors']
selected_cap=next(c for c in cats if c['value']==value);j['selected_capacitor']=selected_cap
# Fixed geometry schematic: replace ideal Cc with the exact three-terminal physical-model symbol.
s=(old/'designs/ota_group_tuned.sch').read_text()
s=re.sub(r'C \{devices/capa.sym\} 840 380 1 0 \{[^\n]+\}\n','',s)
for line in ['N 760 300 760 380 {lab=n2}\n','N 760 380 810 380 {lab=n2}\n','N 870 380 960 380 {lab=out}\n']:assert line in s;s=s.replace(line,'')
s=re.sub(r'T \{Cc = [^}]+\}[^\n]*\n','',s)
s+=f'''C {{scl08_cap3.sym}} 840 500 3 0 {{name=XCC value={value}}}
N 760 300 760 500 {{lab=n2}}
N 760 500 780 500 {{lab=n2}}
N 900 500 960 500 {{lab=out}}
N 900 400 900 420 {{lab=vss}}
C {{devices/lab_pin.sym}} 900 400 0 0 {{name=lcsub lab=vss}}
'''
s=s.replace('Cc=3 pF.',f'Cc target={value}; extracted mutual={selected_cap["Cmut_F"]*1e12:.6g} pF, plus substrate parasitics.').replace('device-group/current tuning candidate','OTA with extracted compensation capacitor')
(R/'designs/ota_extracted_cc.sch').write_text(s);shutil.copy2(old/'designs/ota_group_tuned.sym',R/'designs/ota_extracted_cc.sym');shutil.copy2(P/'capacitors/scl08_capacitor_library_v2/symbols/scl08_cap3.sym',R/'designs/scl08_cap3.sym')
# A local display helper and catalog make the copied symbol self-contained in this OTA experiment.
(R/'designs/catalog.tcl').write_text('array set cap_actual_pf {\n'+'\n'.join('{'+c['value']+'} '+f"{c['Cmut_F']*1e12:.8g}" for c in cats)+'\n}\n')
rc=(old/'xschemrc').read_text()+'''\nsource [file join $project_root designs catalog.tcl]
proc cap_value_text {value} {
 global cap_actual_pf
 if {[info exists cap_actual_pf($value)]} {return "Extracted: $cap_actual_pf($value) pF"}
 return {NOT PREPARED}
}
''';(R/'xschemrc').write_text(rc)
tb=(old/'tb/ota_group_tuned_tb.sch').read_text().replace('ota_group_tuned','ota_extracted_cc').replace('.temp 27','.include ../designs/capacitors.lib.spice\n.temp 27').replace('Cc=3 pF',f'Cc={value} extracted model')
(R/'tb/ota_extracted_cc_tb.sch').write_text(tb)
# Selected portable hand-written testbenches, anchored to this experiment's model copies.
for label,source in [('selected_ac',R/'results'/chosen['name']/'cl5_vc2.5/ac.cir'),('selected_small',R/'results'/chosen['name']/'cl5_small_5ns/tran.cir'),('selected_large',R/'results'/chosen['name']/'cl5_large_5ns/tran.cir')]:
 text=source.read_text().replace(str(R)+'/designs/','../designs/').replace('wrdata ac.dat',f'wrdata ../results/{label}.dat').replace('wrdata tran.dat',f'wrdata ../results/{label}.dat');(R/'tb'/(label+'.cir')).write_text(text)
# Native schematic extraction and simulation checks.
def run(cmd,cwd,log):
 p=subprocess.run(cmd,cwd=cwd,capture_output=True,text=True,timeout=60);log.write_text(p.stdout+p.stderr);assert p.returncode==0,(p.stdout,p.stderr)
for schematic,name in [(R/'designs/ota_extracted_cc.sch','extracted.spice'),(R/'tb/ota_extracted_cc_tb.sch','ota_extracted_cc_tb.spice')]:
 run(['xschem','-x','-q','-n','-s','--rcfile',str(R/'xschemrc'),'-o',str(R/'results'),'-N',name,str(schematic)],R,R/'results'/(name+'.netlist.log'))
s=(R/'results/extracted.spice').read_text();assert 'XCC n2 out vss scl08_cap_'+value in s,s
expected={'M1':'n1 inn tail vss N','M2':'n2 inp tail vss N','M3':'n1 n1 vdd vdd P','M4':'n2 n1 vdd vdd P','M5':'tail iref vss vss N','M6':'out n2 vdd vdd P','M7':'out iref vss vss N','M8':'iref iref vss vss N'}
for name,nodes in expected.items():
 line=next(x for x in s.splitlines() if x.startswith(name+' '));assert line.split()[1:6]==nodes.split(),line
widths=[7.5,7.5,10,10,20,112,160,20];lengths=[2.4,2.4,3.2,3.2,3.2,3.2,3.2,3.2]
for i in range(8):assert f'w={widths[i]:g}u l={lengths[i]:g}u' in next(x for x in s.splitlines() if x.startswith(f'M{i+1} '))
inc='\n'.join(x.replace('**.subckt','.subckt').replace('**.ends','.ends') for x in s.splitlines() if x!='.end');(R/'designs/extracted.inc').write_text(inc)
net=(R/'tb/selected_ac.cir').read_text().replace('../designs/'+chosen['name']+'.inc','../designs/extracted.inc');net=re.sub(r'ota_tuned LI=.*?\n','ota_extracted_cc\n',net);(R/'tb/extracted_ac.cir').write_text(net)
run(['ngspice','-b','-o','../results/extracted_ac.log','extracted_ac.cir'],R/'tb',R/'results/extracted_ac_run.log')
a=np.loadtxt(R/'results/selected_ac.dat',skiprows=1);b=np.loadtxt(R/'results'/chosen['name']/'cl5_vc2.5/ac.dat',skiprows=1);assert np.allclose(a,b,rtol=1e-6,atol=1e-6)
run(['ngspice','-b','-o','ota_extracted_cc_tb.log','ota_extracted_cc_tb.spice'],R/'results',R/'results/native_simulation_run.log')
for name in ['selected_ac','selected_small','selected_large']:run(['ngspice','-b','-o','../results/'+name+'.log',name+'.cir'],R/'tb',R/'results'/(name+'_run.log'))
j['verification']=dict(transistor_geometry_connectivity='PASS: unchanged 8-MOS core',capacitor_pin_mapping='TOP=n2 BOT=out SUB=vss verified in xschem-extracted netlist',extracted_ac_matches_authored='PASS',native_xschem_testbench='netlisted and simulated',selected_portable_benches='PASS',fine_timestep_settling_delta_ns=1000*abs(j['selected_fine_large']['worst_dynamic_us']-chosen['large_worst_dynamic_us']))
(R/'results/summary.json').write_text(json.dumps(j,indent=2))
# Full comparison plots.
show=['ideal_3p','metal_3p_top_n2','metal_3p_top_out',chosen['name']];colors=['C0','C1','C2','C3'];fig,axs=plt.subplots(2,2,figsize=(12,8))
for name,color in zip(show,colors):
 d=R/'results'/name;a=np.loadtxt(d/'cl5_vc2.5/ac.dat',skiprows=1);t=np.loadtxt(d/'cl5_large_5ns/tran.dat',skiprows=1)
 axs[0,0].semilogx(a[:,0],a[:,1],label=name,color=color);axs[0,1].semilogx(a[:,0],a[:,2],label=name,color=color);axs[1,0].plot(t[:,0]*1e6,t[:,2],label=name,color=color)
 import csv
 rows=list(csv.DictReader((R/'results/ac_checks.csv').open()));pts=[(float(r['CL_pF']),float(r['PM_deg'])) for r in rows if r['name']==name and float(r['VC_V'])==2.5];pts.sort();axs[1,1].plot(*zip(*pts),'-o',label=name,color=color)
axs[0,0].set(xlabel='Frequency (Hz)',ylabel='Gain (dB)',xlim=(1,1e8));axs[0,1].set(xlabel='Frequency (Hz)',ylabel='Phase (degrees)',xlim=(1e3,1e8));axs[1,0].set(xlabel='Time (us)',ylabel='Output (V)',xlim=(9,25),title='2 V follower step, CL=5 pF');axs[1,1].set(xlabel='Explicit CL (pF)',ylabel='Phase margin (degrees)',title='2.5 V follower DC point');axs[1,1].axhline(60,color='k',ls='--')
for ax in axs.flat:ax.grid(alpha=.25);ax.legend(fontsize=7)
fig.tight_layout();fig.savefig(R/'plots/compensation_comparison.png',dpi=180);fig.savefig(R/'plots/compensation_comparison.pdf');plt.close(fig)
print(json.dumps(dict(selected=chosen,capacitor=selected_cap,verification=j['verification']),indent=2))
