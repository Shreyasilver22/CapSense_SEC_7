array unset cap_actual_pf
array set cap_actual_pf {
 {6p} 5.99937
 {8p} 8.00295
 {10p} 9.99515
}
set cap_pdk_root {/home/berson_meshak/pdk/scl08/analog_pdk/Open_Source_SCL_0.8micron_PDK/open_source_scl_cp8d/open_pdks/scl_cp8d}
