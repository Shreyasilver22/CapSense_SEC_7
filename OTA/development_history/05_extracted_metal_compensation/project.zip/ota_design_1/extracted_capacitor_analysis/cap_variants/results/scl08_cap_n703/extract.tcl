crashbackups stop
drc off
gds read {/home/berson_meshak/final year project/ota/ota_design_1/extracted_capacitor_analysis/cap_variants/layouts/scl08_cap_n703.gds}
load scl08_cap_n703
select top cell
extract all
ext2spice default
ext2spice format ngspice
ext2spice scale off
ext2spice cthresh 0
ext2spice subcircuits top on
ext2spice -y 6 -o scl08_cap_n703.native.spice
save scl08_cap_n703
quit -noprompt
