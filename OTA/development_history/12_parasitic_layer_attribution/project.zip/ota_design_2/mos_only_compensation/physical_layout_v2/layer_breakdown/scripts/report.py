from pathlib import Path
import json,subprocess,re,csv
import numpy as np,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parents[1];j=json.loads((R/'breakdown.json').read_text());rows=j['rows']
fig,ax=plt.subplots(figsize=(9,5));nodes=['INP','INN','N1','N2','TAIL','IREF','OUT'];bottom=np.zeros(len(nodes));colors=['#e66a61','#5796d2','#d2b742']
for g,c,label in zip(['poly_ground','m1_ground','m2_ground'],colors,['Poly','Metal 1','Metal 2']):
 vals=np.array([next(x[g] for x in rows if x['kind']=='ground_fF' and x['node']==n) for n in nodes]);ax.bar(nodes,vals,bottom=bottom,label=label,color=c);bottom+=vals
ax.set(ylabel='Estimated node-to-ground capacitance (fF)',title='Compact OTA: exploratory layer attribution\nExcludes intrinsic MOS and junction capacitances');ax.legend();ax.grid(axis='y',alpha=.2);fig.tight_layout();fig.savefig(R/'plots/layer_breakdown.png',dpi=180);fig.savefig(R/'plots/layer_breakdown.pdf')
# Geometric upper path and low-frequency distributed gate-R estimates.
rr=[]
for name,w,l,count in [('MCAP',20,10,6),('M6',28,3.2,4),('M1/M2 each',3.75,2.4,2),('M3/M4 each',5,3.2,2)]:
 rr.append(dict(device=name,W_um=w,L_um=l,parallel_units=count,poly_sheet_ohm_sq=22,channel_gate_far_end_path_ohm=22*w/l,uniform_distributed_gate_R_ohm_per_unit=22*w/l/3,parallel_uniform_gate_R_ohm=22*w/l/3/count))
(R/'gate_resistance_estimates.json').write_text(json.dumps({'method':'Rsheet*W/L far-end gate path; distributed R/3 only for uniform gate capacitance driven from one width end. Excludes extension, contact, metal and well resistance; not network PEX.','devices':rr},indent=2))
# Nominal AC sensitivity: subtract individual ground-cap rules from fixed baseline.
base=(R/'runs/all/extracted.spice').read_text();node_map={'N2':'a_15600_31700#','N1':'a_16080_8520#','TAIL':'a_14700_8520#'}
S=R/'sensitivity';S.mkdir(exist_ok=True);out=[]
for group in ['all','poly_ground','m1_ground','m2_ground']:
 ls=[]
 for line in base.splitlines():
  if line.startswith('C') and group!='all':
   a=line.split();cap=float(re.match(r'([\d.eE+-]+)',a[3])[1]);suffix=re.sub(r'^[\d.eE+-]+','',a[3]);v=cap*{'a':1e-18,'f':1e-15,'p':1e-12,'n':1e-9,'u':1e-6,'':1}[suffix]
   if '0' in a[1:3]:
    node=next(n for n in a[1:3] if n!='0');friendly={v:k for k,v in node_map.items()}.get(node,node);r=next((x for x in rows if x['kind']=='ground_fF' and x['node']==friendly),None)
    if r:v-=r[group]*1e-15
   if v<1e-21:continue
   line=' '.join(a[:3])+f' {v:.12g}'
  ls.append(line)
 (S/(group+'.inc')).write_text('\n'.join(ls)+'\n')
 text=f'''Layer sensitivity {group}: exploratory only
.include "/home/berson_meshak/pdk/scl08/ngspice_models49/mos/tntp49_5v"
.include "{group}.inc"
.temp 27
.options reltol=1e-5 vntol=1e-8 abstol=1e-12 numdgt=12
VDD vdd 0 5
IREF vdd bias 2.5u
CL out 0 5p
XU inp inn out vdd 0 bias ota_design2_mos
VIN inp 0 dc 2.5 ac 1
LDC out inn 1e12
CAC inn 0 1e12
.control
set wr_singlescale
set wr_vecnames
ac dec 150 1 1G
let gd=db(v(out))
let pd=180/PI*cph(v(out))
wrdata {group}.dat gd pd
quit
.endc
.end
''';(S/(group+'.cir')).write_text(text);p=subprocess.run(['ngspice','-b','-o',group+'.log',group+'.cir'],cwd=S,capture_output=True,text=True);assert p.returncode==0
 a=np.loadtxt(S/(group+'.dat'),skiprows=1);ix=np.where(a[:-1,1]*a[1:,1]<0)[0];assert len(ix)==1;z=ix[0];f=-a[z,1]/(a[z+1,1]-a[z,1]);out.append(dict(removed_rule='none' if group=='all' else group,UGF_MHz=float(10**(np.log10(a[z,0])+f*np.log10(a[z+1,0]/a[z,0]))/1e6),PM_deg=float(180+a[z,2]+f*(a[z+1,2]-a[z,2]))))
(R/'sensitivity.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
