from pathlib import Path
import re,subprocess,tempfile,shlex,json,csv
R=Path(__file__).resolve().parents[1];source=Path('/home/berson_meshak/final year project/ota/ota_design_2/mos_only_compensation/physical_layout_v2')
t=Path('/home/berson_meshak/pdk/scl08/analog_pdk/Open_Source_SCL_0.8micron_PDK/open_source_scl_cp8d/open_pdks/scl_cp8d/libs.tech/magic/SCL_CP8D.tech');s=t.read_text();start=s.index('cifinput');end=s.index('\nend',start);sec=s[start:end]
for name in ['nwell_rev','boron_rev','boron','CONT']:sec,n=re.subn(r'(?m)^layer '+name+r' .*?(?=^layer |^calma |\Z)','',sec,flags=re.S);assert n==1
s=s[:start]+sec+s[end:]
def category(line):
 a=line.split()
 if not a or not a[0].startswith('default'):return None
 if a[0] in ['defaultareacap','defaultperimeter','defaultsidewall']:
  return {'allpolynonfet':'poly_ground','allm1':'m1_ground','allm2':'m2_ground'}[a[1]]
 return {'allm1_metal1_allactivenonfet':'m1_active','allm1_metal1_allpoly':'m1_poly','allm2_metal2_allactivenonfet':'m2_active','allm2_metal2_allpoly':'m2_poly','allm2_metal2_allm1':'m2_m1'}['_'.join(a[1:4])]
groups=sorted({category(x) for x in s.splitlines() if category(x)})
results={}
for group in ['all']+groups:
 lines=[]
 for line in s.splitlines():
  cat=category(line)
  if cat and group!='all' and cat!=group:line=re.sub(r'\s+[0-9.]+\s*$',' 0',line)
  lines.append(line)
 d=R/'runs'/group;d.mkdir(parents=True,exist_ok=True)
 script=f'''crashbackups stop
drc off
gds read {{{source/'layout/ota_design2_mos.gds'}}}
load ota_design2_mos
select top cell
extract all
ext2spice default
ext2spice format ngspice
ext2spice scale off
ext2spice cthresh 0
ext2spice subcircuits top on
ext2spice -o extracted.spice
quit -noprompt
''';(d/'extract.tcl').write_text(script)
 with tempfile.TemporaryDirectory(prefix='scl_layer_') as tmp:
  p=Path(tmp)/'SCL_CP8D.tech';p.write_text('\n'.join(lines)+'\n');q=subprocess.run(['/tmp/magic_cap_validate/bin/magic','-dnull','-noconsole','-norcfile','-T',str(p),'extract.tcl'],cwd=d,capture_output=True,text=True);(d/'extract.log').write_text(q.stdout+q.stderr);assert q.returncode==0
 nodes={};caps={}
 for line in (d/'ota_design2_mos.ext').read_text().splitlines():
  a=shlex.split(line)
  if a and a[0]=='node':nodes[a[1]]=float(a[3])/1000
  if a and a[0]=='cap':caps['|'.join(sorted(a[1:3]))]=float(a[3])/1000
 results[group]={'ground_fF':nodes,'coupling_fF':caps}
 print(group,flush=True)
rename={'a_15600_31700#':'N2','a_16080_8520#':'N1','a_14700_8520#':'TAIL'}
rows=[];errors=[]
for kind in ['ground_fF','coupling_fF']:
 for node,total in results['all'][kind].items():
  vals={g:results[g][kind].get(node,0) for g in groups};err=sum(vals.values())-total;errors.append(abs(err));assert abs(err)<.015,(kind,node,total,vals,err)
  rows.append(dict(kind=kind,node='|'.join(rename.get(n,n) for n in node.split('|')),total_fF=total,**vals,sum_error_fF=err))
with (R/'breakdown.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
(R/'breakdown.json').write_text(json.dumps({'method':'Coefficient isolation with fixed geometry and import adaptation; linear superposition checked','max_sum_error_fF':max(errors),'rows':rows,'limits':'Exploratory deck capacitance only; no MOS intrinsic gate C, junction C, missing well-junction C, or qualified full RC. No source PDK files changed.'},indent=2))
print(json.dumps([r for r in rows if r['kind']=='ground_fF' and r['node'] in ['N2','OUT']],indent=2))
