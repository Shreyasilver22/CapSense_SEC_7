crashbackups stop
drc off
gds read {/home/berson_meshak/final year project/ota/ota_design_2/mos_only_compensation/physical_layout_v2/layout/ota_design2_mos.gds}
load ota_design2_mos
select top cell
extract all
ext2spice default
ext2spice format ngspice
ext2spice scale off
ext2spice cthresh 0
ext2spice subcircuits top on
ext2spice -o extracted.spice
quit -noprompt
