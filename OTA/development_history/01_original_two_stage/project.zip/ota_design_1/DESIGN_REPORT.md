# SCL08 seven-transistor OTA: first pass

Actually simulated with ngspice 42 using the installed SCL CP8D typical 5 V LEVEL49/BSIM3v3.2 MOS cards. Original project files, PDK files and synced sources were left untouched. This directory contains new work only.

## Files and rerun

Run from tb/ (write logs to ../results/):

```sh
ngspice -b -o reference.log reference.cir
ngspice -b -o open_loop.log open_loop.cir
ngspice -b -o follower.log follower.cir
```

`designs/models.inc` points to the local installed MOS file; change that one include on another machine. PDK contents are not copied. `provenance.json` records its SHA256. The full header library was inspected; only its NOM MOS include is required here. The old `/home/berson_meshak/OTA_Design` schematics reference GF180 and were not reused.

## Design and assumptions

Supply 5 V, temperature 27 C, input common mode 2.5 V, ideal external NMOS bias 0.95 V, load 5 pF, Miller capacitor 5 pF. These are first-pass assumptions, not recovered performance requirements. Seven MOS devices exclude a practical bias generator.

| Devices | Role | W (um) | L (um) |
|---|---|---:|---:|
| M1/M2 | NMOS differential pair | 2.5 | 0.8 |
| M3/M4 | PMOS mirror load | 2.5 | 0.8 |
| M5 | NMOS tail sink | 5 | 0.8 |
| M6 | PMOS second gain stage | 7 | 0.8 |
| M7 | NMOS output sink | 10 | 0.8 |

M1 gate is inn, M2 gate is inp. After the PMOS second-stage inversion, inp is noninverting. Bodies connect to their appropriate rails. External bias sets M5/M7; their currents do not scale exactly with width because these short/narrow-device model cards include geometry effects. M6 was adjusted by actual simulation to avoid biasing the output close to the upper rail.

The reference tables were read alongside transfer and output sweeps. At W=2.5 um, L=0.8 um, NMOS VGS=1 V/VDS=3 V: saved Id=13.2753907 uA, finite-difference gm=60.620011 uS, gds=0.58804 uS. Actual reference run: Id=13.27539 uA, model gm=60.81335 uS. PMOS VSG=2 V/VSD=3 V: saved Id=38.915701 uA, finite-difference gm=48.930106 uS; actual reference run Id=38.91570 uA, model gm=50.97058 uS. The small gm differences are consistent with the tables' coarse numerical derivatives. These are existing model-derived characterization results, not verified silicon measurements. The PMOS data show substantial drain-voltage dependence, so a single constant-lambda square-law fit was not substituted for the PDK.

The input pair retains the reference geometry, the tail starts at twice its width, and the output sink at four times. Reference NMOS current suggests a tens-of-uA input-stage budget; PMOS transfer/output data guide the mirror and second-stage starting sizes. Body effect and actual drain biases require rechecking the full circuit rather than transplanting zero-body-bias gm/Id values.

## Actual nominal results

| Quantity | Result |
|---|---:|
| Open-loop output at equal inputs | 3.2763 V |
| Tail current | 29.3189 uA |
| Input branch current | 14.6594 uA each |
| Open-loop supply current | 111.915 uA |
| Open-loop DC supply power | 0.5596 mW |
| Gain at 1 Hz | 35.56794 dB (about 60 V/V) |
| First unity-gain crossing | 1.554635 MHz |
| Phase there | -118.6105 degrees |
| Estimated phase margin | 61.3895 degrees |
| Follower DC output for 2.5 V input | 2.511864 V |
| Follower output at 59 us (2.6 V input) | 2.610739 V |
| Follower output at 99 us (2.5 V input) | 2.511864 V |
| Follower DC supply current | 108.979 uA |

Phase margin uses 180 + open-loop phase at the 0 dB crossing for the unloaded-input, unity-feedback case. It is an estimate from the differential open-loop response at equal inputs, whose output bias differs from the follower; it is not a dedicated loop-injection measurement at the follower operating point. Both frequency response and the transient must be interpreted with the model limitations below. At the open-loop operating point all seven devices have model-reported |VDS| above |VDSAT|; the smallest margin is M5, approximately 0.929 V. Device values are preserved in `results/open_loop.log`.

The follower tracks a 100 mV step with about 11–12 mV static error. This is a functioning first pass, with limited gain and output centering; it is not an optimized precision CapSense amplifier. `results/ac.dat`, `results/dc.dat` and `results/transient.dat` retain numerical waveforms. DC sweep spans only +/-10 mV differential input and is not an output-swing or common-mode-range qualification.

## Limitations

Ngspice runs completed, but the HSPICE model cards emit compatibility warnings. Ignored parameters include hspver, binflag, nlev, sfvtflag, vfbflag, nds, vnds, php, fc, tt, and PMOS cgs0/cgd0/cgb0 plus a stray minus token. The PMOS capacitance entries may be misspelled relative to ngspice's supported overlap parameters. No model edits were made, and HSPICE equivalence has not been established. Therefore gain/current reproduction is demonstrated at the reference points, while bandwidth, phase margin and transient predictions are provisional.

Source/drain layout areas and perimeters are unspecified (zero instance values), and no extracted interconnect parasitics are present. Only typical corner and 27 C were run. No mismatch/noise/PSRR/CMRR, formal settling/slew-rate extraction, load sweep, PVT, input common-mode range, full output swing or layout validation was performed. The bias is ideal and excludes bias-generator power/startup. No original gain/bandwidth/power/noise targets were recoverable from the conversation, whose assistant messages were unavailable content references.
