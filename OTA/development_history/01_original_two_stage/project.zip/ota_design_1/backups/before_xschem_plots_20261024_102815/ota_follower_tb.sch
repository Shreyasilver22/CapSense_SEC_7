v {xschem version=3.4.4 file_version=1.2}
G {}
K {}
V {}
S {}
E {}
C {ota_scl08.sym} 500 300 0 0 {name=XU}
C {devices/lab_pin.sym} 380 250 0 0 {name=l24 sig_type=std_logic lab=inp}
C {devices/lab_pin.sym} 380 350 0 0 {name=l25 sig_type=std_logic lab=out}
C {devices/lab_pin.sym} 640 300 0 0 {name=l26 sig_type=std_logic lab=out}
C {devices/lab_pin.sym} 500 160 0 0 {name=l27 sig_type=std_logic lab=vdd}
C {devices/lab_pin.sym} 500 440 0 0 {name=l28 sig_type=std_logic lab=0}
C {devices/lab_pin.sym} 460 440 0 0 {name=l29 sig_type=std_logic lab=vbn}
C {devices/vsource.sym} 100 600 0 0 {name=VDD value="5"}
C {devices/lab_pin.sym} 100 570 0 0 {name=l30 sig_type=std_logic lab=vdd}
C {devices/lab_pin.sym} 100 630 0 0 {name=l31 sig_type=std_logic lab=0}
C {devices/vsource.sym} 240 600 0 0 {name=VBN value="0.95"}
C {devices/lab_pin.sym} 240 570 0 0 {name=l32 sig_type=std_logic lab=vbn}
C {devices/lab_pin.sym} 240 630 0 0 {name=l33 sig_type=std_logic lab=0}
C {devices/vsource.sym} 1000 600 0 0 {name=VIN value="dc 2.5 pulse(2.5 2.6 20u 100n 100n 40u 80u)"}
C {devices/lab_pin.sym} 1000 570 0 0 {name=l34 sig_type=std_logic lab=inp}
C {devices/lab_pin.sym} 1000 630 0 0 {name=l35 sig_type=std_logic lab=0}
C {devices/capa.sym} 800 350 0 0 {name=CL value=5p m=1}
C {devices/lab_pin.sym} 800 320 0 0 {name=l36 sig_type=std_logic lab=out}
C {devices/lab_pin.sym} 800 380 0 0 {name=l37 sig_type=std_logic lab=0}
C {devices/code_shown.sym} 100 800 0 0 {name=MODELS only_toplevel=true value=".include /home/berson_meshak/pdk/scl08/ngspice_models49/mos/tntp49_5v
.temp 27"}
C {devices/code_shown.sym} 700 800 0 0 {name=RUN only_toplevel=true value=".control
set noaskquit
op
print v(out) i(VDD)
tran 20n 120u
meas tran output_high find v(out) at=59u
meas tran output_low find v(out) at=99u
write follower_xschem.raw
quit
.endc"}
T {SCL08 OTA - unity-gain follower demonstration} 100 30 0 0 0.5 0.5 {}
T {Use the ota_scl08 symbol in your switched-capacitor circuit.
Connect all six pins; keep the external VBN bias supply.} 100 80 0 0 0.3 0.3 {}
