v {xschem version=3.4.4 file_version=1.2}
G {}
K {}
V {}
S {}
E {}
C {devices/pmos4.sym} 300 180 0 0 {name=M3 model=P w=2.5u l=0.8u m=1}
N 280 180 220 180 {lab=n1}
C {devices/lab_pin.sym} 220 180 0 0 {name=l1 sig_type=std_logic lab=n1}
N 320 180 395 180 {lab=vdd}
C {devices/lab_pin.sym} 395 180 0 0 {name=l2 sig_type=std_logic lab=vdd}
C {devices/pmos4.sym} 600 180 0 0 {name=M4 model=P w=2.5u l=0.8u m=1}
N 580 180 520 180 {lab=n1}
C {devices/lab_pin.sym} 520 180 0 0 {name=l3 sig_type=std_logic lab=n1}
N 620 180 695 180 {lab=vdd}
C {devices/lab_pin.sym} 695 180 0 0 {name=l4 sig_type=std_logic lab=vdd}
C {devices/nmos4.sym} 300 400 0 0 {name=M1 model=N w=2.5u l=0.8u m=1}
N 280 400 220 400 {lab=inn}
C {devices/lab_pin.sym} 220 400 0 0 {name=l5 sig_type=std_logic lab=inn}
N 320 400 395 400 {lab=vss}
C {devices/lab_pin.sym} 395 400 0 0 {name=l6 sig_type=std_logic lab=vss}
C {devices/nmos4.sym} 600 400 0 0 {name=M2 model=N w=2.5u l=0.8u m=1}
N 580 400 520 400 {lab=inp}
C {devices/lab_pin.sym} 520 400 0 0 {name=l7 sig_type=std_logic lab=inp}
N 620 400 695 400 {lab=vss}
C {devices/lab_pin.sym} 695 400 0 0 {name=l8 sig_type=std_logic lab=vss}
N 320 210 320 370 {lab=n1}
C {devices/lab_pin.sym} 320 280 0 0 {name=l9 sig_type=std_logic lab=n1}
N 620 210 620 370 {lab=n2}
C {devices/lab_pin.sym} 620 280 0 0 {name=l10 sig_type=std_logic lab=n2}
N 320 150 320 100 {lab=vdd}
N 320 100 620 100 {lab=vdd}
N 620 100 620 150 {lab=vdd}
C {devices/lab_pin.sym} 470 100 0 0 {name=l11 sig_type=std_logic lab=vdd}
N 320 430 320 510 {lab=tail}
N 320 510 620 510 {lab=tail}
N 620 430 620 510 {lab=tail}
C {devices/nmos4.sym} 450 650 0 0 {name=M5 model=N w=5u l=0.8u m=1}
N 430 650 370 650 {lab=vbn}
C {devices/lab_pin.sym} 370 650 0 0 {name=l12 sig_type=std_logic lab=vbn}
N 470 650 545 650 {lab=vss}
C {devices/lab_pin.sym} 545 650 0 0 {name=l13 sig_type=std_logic lab=vss}
N 470 510 470 620 {lab=tail}
C {devices/lab_pin.sym} 470 550 0 0 {name=ltail sig_type=std_logic lab=tail}
N 470 680 470 740 {lab=vss}
C {devices/lab_pin.sym} 470 740 0 0 {name=l14 sig_type=std_logic lab=vss}
C {devices/pmos4.sym} 1000 180 0 0 {name=M6 model=P w=7u l=0.8u m=1}
N 980 180 920 180 {lab=n2}
C {devices/lab_pin.sym} 920 180 0 0 {name=l15 sig_type=std_logic lab=n2}
N 1020 180 1095 180 {lab=vdd}
C {devices/lab_pin.sym} 1095 180 0 0 {name=l16 sig_type=std_logic lab=vdd}
C {devices/nmos4.sym} 1000 650 0 0 {name=M7 model=N w=10u l=0.8u m=1}
N 980 650 920 650 {lab=vbn}
C {devices/lab_pin.sym} 920 650 0 0 {name=l17 sig_type=std_logic lab=vbn}
N 1020 650 1095 650 {lab=vss}
C {devices/lab_pin.sym} 1095 650 0 0 {name=l18 sig_type=std_logic lab=vss}
N 1020 150 1020 100 {lab=vdd}
C {devices/lab_pin.sym} 1020 100 0 0 {name=l19 sig_type=std_logic lab=vdd}
N 1020 210 1020 450 {lab=out}
N 1020 450 1020 620 {lab=out}
N 1020 680 1020 740 {lab=vss}
C {devices/lab_pin.sym} 1020 740 0 0 {name=l20 sig_type=std_logic lab=vss}
N 1020 450 1150 450 {lab=out}
C {devices/lab_pin.sym} 1150 450 0 0 {name=l21 sig_type=std_logic lab=out}
C {devices/capa.sym} 820 300 1 0 {name=Cc value=5p m=1}
N 790 300 740 300 {lab=n2}
C {devices/lab_pin.sym} 740 300 0 0 {name=l22 sig_type=std_logic lab=n2}
N 850 300 900 300 {lab=out}
C {devices/lab_pin.sym} 900 300 0 0 {name=l23 sig_type=std_logic lab=out}
C {devices/ipin.sym} 100 100 0 0 {name=p1 lab=inp}
C {devices/ipin.sym} 100 180 0 0 {name=p2 lab=inn}
C {devices/opin.sym} 100 260 0 0 {name=p3 lab=out}
C {devices/iopin.sym} 100 340 0 0 {name=p4 lab=vdd}
C {devices/iopin.sym} 100 420 0 0 {name=p5 lab=vss}
C {devices/ipin.sym} 100 500 0 0 {name=p6 lab=vbn}
T {SCL08 seven-transistor two-stage OTA} 280 0 0 0 0.6 0.6 {}
T {W/L in micrometres; all L = 0.8 um. Cc = 5 pF.} 280 40 0 0 0.3 0.3 {}
T {External bias required: vbn = 0.95 V relative to vss.
Nominal tested: vdd = 5 V, common mode = 2.5 V, CL = 5 pF.
inp is noninverting; inn is inverting. Bodies tied to rails.} 280 800 0 0 0.3 0.3 {}
