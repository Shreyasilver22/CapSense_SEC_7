# SCL 800 nm OTA requirements — revision 1

Date: 24 October 2026. Status: working specification, not a claim of achieved performance.

## Confirmed scope

- Process: SCL CP8D 800 nm, confirmed by the user.
- Application: capacitive-sensor readout using a switched-capacitor circuit.
- Previous OCCPSense GF180 repository is architectural/reference material, not binding chip specifications.
- Existing seven-transistor single-ended design remains an unmodified baseline. A fully differential OTA with CMFB is the leading next design candidate, not a demonstrated implementation.

## Working targets and unresolved requirements

| Parameter | Revision 1 position | Status / rationale |
|---|---|---|
| Device models | Local SCL CP8D 5 V nominal MOS cards, model names N/P | Actual available model deck; warnings remain |
| Analog supply | Start design at 5 V; investigate 3.3 V separately if system requires it | Provisional design scenario; 800 nm alone does not mandate 5 V |
| Input/output common-mode | Initially 2.5 V at the 5 V supply | Provisional, independently adjustable; verify actual input range/headroom |
| Interface | Fully differential inputs/outputs, output common-mode reference, power and bias interfaces | Leading candidate for the differential SC path; freeze interface with SC designer |
| Gain | Explore 80–85 dB low-frequency differential gain | Engineering goal; derive final minimum from beta and static error budget, verify versus output level/PVT |
| Signal-loop phase margin | Initial goal >=60 degrees at relevant held-phase operating points | Must also pass settling and gain-margin/multiple-crossing checks |
| CMFB | Closed-loop common-mode regulation, startup and recovery before sampling | Separate common-mode-loop stability and transient verification required |
| Output swing | Determine from C-to-V transfer and ADC full scale | No inherited hard 2.7 V requirement; differential Vpp/per-output extrema must be defined |
| Input common-mode range | Cover summing-node values in all operating/reset phases | Derived requirement; no blanket rail-to-rail target |
| Bandwidth/UGF | Parameterized, not frozen | Derive from usable amplification time, beta and dynamic error allowance |
| Slew rate | Parameterized, both polarities | Derive from max output transition, phase load, internal charging and time budget |
| Load | Determine phase-dependent effective load | Use 1/5/10 pF as exploratory explicit-load scenarios only; sensor capacitance is not automatically load |
| Noise | Sampled input/output noise allocation to be derived | Include CDS, aliasing, circuit and switch noise with validated model support |
| Offset/CMRR/PSRR | Limits to be derived from error budget and expected disturbances | Evaluate with correct excitation; CMFB gain is not CMRR |
| Power | Minimize complete OTA energy/power while meeting sampled error/noise | <10 uW total-channel repo aspiration is not adopted as a hard requirement; no replacement arbitrary limit |
| gm and bias currents | Outputs of sizing/optimization | No inherited fixed 50–100 uS or fixed VBN requirement |
| Resolution | Evaluate 8-bit and 10-bit system scenarios | Reference scenarios, not guaranteed ENOB or confirmed final resolution |
| Geometry | Retain 2.5 um/0.8 um characterization reference; explore longer L | Do not import GF180 400 nm sizing; legal dimensions must follow SCL rules, not just this report |
| Corners/temperature/area | Verify before design acceptance; numerical ranges/budgets pending | Use available qualified corner/statistical decks and actual product range |

## How to close the remaining numbers

For a simple SC amplification phase, beta approximately equals Cf/(Cs+Cf+Cin+Cpar). First-order static finite-gain error is approximately 1/(1+A0*beta). Therefore A0 >= (1/epsilon_static - 1)/beta. These equations are screening approximations; actual topology/signal dependence must be simulated.

Example: 10-bit full-scale accuracy with half an LSB allocated solely to finite-gain error needs about 72.2 dB at beta=0.5 and 80.2 dB at beta=0.2. The 80–85 dB working range is therefore a useful search objective, not proof of 10-bit precision. Additional error allocation can require more gain. At 80 dB and beta=0.2 that particular half-LSB criterion is slightly missed.

For an unslewed one-pole response, fu >= ln(1/epsilon_dynamic)/(2*pi*beta*tlinear_available). Actual usable phase time excludes clock dead time and any required slew/recovery time. Test both static error to the ideal value and dynamic error to the actual settled value; their sum gives total sampled error.

Set swing from the C-to-V sensitivity, sensor change range and ADC input full scale, then select output common mode and verify all device headrooms. Account for CDAC acquisition/kickback where applicable.

Measure energy over complete steady-state conversion cycles and include actual bias, CMFB and reference-generation overhead. Report active, standby, cycle-average and peak-current quantities separately. Duty-cycle savings require verified startup and settling.

## Changes from the repository and initial simulation

- SCL 800 nm replaces GF180 180 nm as the confirmed process.
- 5 V is the main provisional design scenario, replacing inherited 3.3 V as a default assumption, but remains subject to the chip supply plan.
- GF180 minimum-length guidance, fixed gm and the repo's power/swing values are not copied as requirements.
- Initial simulation values CL=Cc=5 pF, VBN=0.95 V and 27 C remain baseline test settings, not frozen design requirements. Do not fix Cc or bias voltages before optimization.
- Fully differential/CMFB is a next architecture candidate; the existing seven-transistor core is single-ended and is not converted by merely adding a CMFB block.

## Acceptance and model limitations

A design must satisfy phase-specific differential and common-mode stability, total sampled error, sampled noise, swing and power across the agreed load/process/supply/temperature range. Include mismatch and extracted layout parasitics when supporting models/layout are available.

Ngspice ignores several HSPICE model parameters, including capacitance entries in the current local deck. Matching reference drain current does not validate dynamic/noise accuracy. Resolve or independently bound this compatibility issue before claiming precise optimized bandwidth, phase margin, settling or noise. The 5 V model filename is not a device reliability specification; confirm operating limits from SCL process documentation.

No transistor sizing, model card, schematic or testbench is changed by this requirements revision.
