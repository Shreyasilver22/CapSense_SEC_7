# Run and plot the OTA in xschem

From the project root:

```sh
xschem --rcfile xschemrc tb/ota_follower_tb.sch
```

Ctrl-left-click the arrow labeled **Run simulation + plot**. It generates the netlist, runs ngspice in batch mode and reloads the waveform data into the two embedded graphs. The upper plot shows input/output voltage, the lower Vout−Vin tracking error. If necessary press F with the pointer outside the graphs to fit the full sheet.

Alternative: Simulation → Netlist, then Simulation → Simulate. After completion Ctrl-left-click **Load / refresh transient plots**. The button positions are to the right/below the testbench. Graph traces appear only after loading data. The native Simulation → Load/Unload ngspice .raw file action also finds ota_follower_tb.raw in results/.

Open **tb/ota_ac_tb.sch** for gain and phase. Use its Run simulation + plot arrow. AC input is 1 V differential, DC common mode 2.5 V, CL=5 pF. Gain is plotted as 20 log10 of the raw output magnitude. This xschem version converts complex raw vectors to magnitudes and phases, so graphing an already signed gain_db vector directly would lose its sign. The unwrapped phase is computed by ngspice; for this baseline it remains negative and the graph plots minus its imported magnitude.

AC log axis bounds 0–9 represent log10(frequency), displaying 1 Hz–1 GHz. Expected gain about 35.57 dB, first 0 dB crossing 1.55 MHz, phase there −118.61° (estimated PM 61.39°). This estimate is at the equal-input open-loop bias, not a full SC loop-injection qualification.

The xschemrc selects batch ngspice for this project only. It applies a guarded process-local fix for xschem 3.4.4's unquoted simulation working-directory command, allowing the project path's spaces. Global/system settings are unchanged. Always open with the project --rcfile; reload/restart xschem after changing this config. Binary raw files and logs are in results/ with names matching the testbench. No additional wave viewer is required.

Native file checks confirmed both raw files load and contain the requested variables. GUI clicking was not tested from this headless agent session. PDK compatibility warnings remain; these are baseline verification plots, not a new optimized OTA.
