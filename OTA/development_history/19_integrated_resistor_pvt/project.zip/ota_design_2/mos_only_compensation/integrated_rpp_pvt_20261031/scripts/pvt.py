from pathlib import Path
import subprocess,json,re,itertools,concurrent.futures,csv,shutil
import numpy as np
R=Path(__file__).resolve().parents[1];PDK=Path('/home/berson_meshak/pdk/scl08/ngspice_models49')
shutil.copy2('/home/berson_meshak/final year project/ota/ota_design_2/mos_only_compensation/physical_layout_v3/pex/ota_C_only.spice',R/'models/baseline9_C.spice')
mos=['tntp49_5v','bnbp49_5v','bnwp49_5v','wnbp49_5v','wnwp49_5v'];configs=[]
for arch in ['baseline9','integrated6R']:
 for m,v,t,rc in itertools.product(mos,[4.5,5,5.5],[0,27,85],['typ'] if arch=='baseline9' else ['best','typ','worst']):configs.append(dict(arch=arch,mos=m,VDD=v,temp=t,res=rc))
def key(c):return f"{c['arch']}_{c['mos']}_{c['VDD']}_{c['temp']}_{c['res']}"
def base(c,cl):
 model={'baseline9':'baseline9_C.spice','integrated6R':'integrated_C.spice','RC_diagnostic':'integrated_RC_diagnostic.spice'}[c['arch']]
 return f'''OTA integrated PVT {key(c)}
.include "{PDK}/mos/{c['mos']}"
.include "{PDK}/res/{c['res']}/ppr"
.include "{R}/models/{model}"
.temp {c['temp']}
.options reltol=1e-5 vntol=1e-8 abstol=1e-12 numdgt=12
VDD vdd 0 {c['VDD']}
IREF vdd bias 3.5u
CL out 0 {cl}p
XU inp inn out vdd 0 bias ota_design2_mos
'''
def run(c,tag,text):
 d=R/'results'/key(c);d.mkdir(exist_ok=True);(d/(tag+'.cir')).write_text(text)
 p=subprocess.run(['ngspice','-b','-o',tag+'.log',tag+'.cir'],cwd=d,capture_output=True,text=True,timeout=120)
 log=(d/(tag+'.log')).read_text();return d,log,p.returncode

def ac(c,cl,vc):
 tag=f'ac_cl{cl}_v{vc}';text=base(c,cl)+f'''VIN inp 0 dc {vc} ac 1
LDC out inn 1e12
CAC inn 0 1e12
.control
set wr_singlescale
set wr_vecnames
op
print v(out) i(vdd)
ac dec 120 1 1G
let gd=db(v(out))
let pd=180/PI*cph(v(out))
wrdata {tag}.dat gd pd
quit
.endc
.end
'''
 rec=dict(**c,CL_pF=cl,VC_V=vc,status='OK')
 try:
  d,log,code=run(c,tag,text);a=np.loadtxt(d/(tag+'.dat'),skiprows=1);assert code==0 and len(a)>100
  cross=np.where(a[:-1,1]*a[1:,1]<0)[0];pm=ugf=None
  if len(cross)==1:
   z=cross[0];f=-a[z,1]/(a[z+1,1]-a[z,1]);pm=float(180+a[z,2]+f*(a[z+1,2]-a[z,2]));ugf=float(10**(np.log10(a[z,0])+f*np.log10(a[z+1,0]/a[z,0]))/1e6)
  op={k:float(v) for k,v in re.findall(r'^(v\(out\)|i\(vdd\))\s*=\s*([-+\d.eE]+)',log,re.M)}
  rec.update(gain_dB=float(a[0,1]),UGF_MHz=ugf,PM_deg=pm,crossings=len(cross),out_dc_V=op['v(out)'],power_uW=-c['VDD']*op['i(vdd)']*1e6)
 except Exception as e:rec.update(status='FAILED',error=str(e))
 return rec

def noise(c):
 text=base(c,5)+'''VIN inp 0 dc 2.5 ac 1
VFB inn out 0
.control
set wr_singlescale
set wr_vecnames
noise v(out) VIN dec 80 1 1Meg
setplot noise1
wrdata noise.dat onoise_spectrum inoise_spectrum
setplot noise2
print onoise_total inoise_total
quit
.endc
.end
''';rec=dict(**c,status='OK')
 try:
  d,log,code=run(c,'noise',text);vals={k:float(v) for k,v in re.findall(r'^(onoise_total|inoise_total)\s*=\s*([-+\d.eE]+)',log,re.M)};assert len(vals)==2 and code==0;rec.update(vals)
 except Exception as e:rec.update(status='FAILED',error=str(e))
 return rec

def tran(c,cl=10,large=True,dt=5):
 lo,hi=(1.5,3.5) if large else (2.5,2.6);tag=f'tran_{"large" if large else "small"}_cl{cl}_{dt}ns';text=base(c,cl)+f'''VIN inp 0 dc {lo} pulse({lo} {hi} 10u 10n 10n 40u 80u)
VFB inn out 0
.control
set wr_singlescale
set wr_vecnames
tran {dt}n 90u
wrdata {tag}.dat v(inp) v(out)
quit
.endc
.end
''';rec=dict(**c,CL_pF=cl,large=large,dt_ns=dt,status='OK')
 try:
  d,log,code=run(c,tag,text);a=np.loadtxt(d/(tag+'.dat'),skiprows=1);assert code==0
  sett=[];err=[]
  for start,end,target in [(10e-6,49e-6,hi),(50.01e-6,89e-6,lo)]:
   final=float(np.mean(a[(a[:,0]>end-2e-6)&(a[:,0]<end),2]));mask=(a[:,0]>=start)&(a[:,0]<end);tt=a[mask,0];yy=a[mask,2];bad=np.where(abs(yy-final)>.001*(hi-lo))[0];sett.append(float((tt[bad[-1]+1]-start)*1e6) if len(bad) and bad[-1]+1<len(tt) else (0.0 if not len(bad) else None));err.append(abs(final-target)*1000)
  rec.update(settling_us=max(sett) if all(x is not None for x in sett) else None,static_error_mV=max(err),out_min_V=float(a[:,2].min()),out_max_V=float(a[:,2].max()))
 except Exception as e:rec.update(status='FAILED',error=str(e))
 return rec

def save(name,rows):
 (R/(name+'.json')).write_text(json.dumps(rows,indent=2))
 if rows:
  with (R/(name+'.csv')).open('w') as f:w=csv.DictWriter(f,fieldnames=list(dict.fromkeys(k for x in rows for k in x)));w.writeheader();w.writerows(rows)
if __name__=='__main__':
 jobs=[(c,cl,vc) for c in configs for cl,vc in [(1,2.5),(5,2.5),(10,2.5),(10,1.5),(10,3.5)]]
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:acs=list(ex.map(lambda x:ac(*x),jobs))
 save('pvt_ac',acs);print('AC completed',len(acs),flush=True)
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:ns=list(ex.map(noise,configs))
 save('pvt_noise',ns);print('Noise completed',len(ns),flush=True)
 selected={}
 for arch in ['baseline9','integrated6R']:
  rr=[x for x in acs if x['arch']==arch and x['status']=='OK' and x['PM_deg'] is not None];nn=[x for x in ns if x['arch']==arch and x['status']=='OK']
  for x in [min(rr,key=lambda x:x['PM_deg']),max(rr,key=lambda x:x['UGF_MHz']),min(rr,key=lambda x:x['gain_dB']),max(nn,key=lambda x:x['inoise_total'])]:
   c={k:x[k] for k in ['arch','mos','VDD','temp','res']};selected[key(c)]=c
  c=dict(arch=arch,mos='tntp49_5v',VDD=5,temp=27,res='typ');selected[key(c)]=c
 jobs=[(c,10,big) for c in selected.values() for big in [False,True]]
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:ts=list(ex.map(lambda x:tran(*x),jobs))
 # Nominal CL=5 pF step and fine repeat; RC is clearly marked diagnostic only.
 for arch in ['baseline9','integrated6R','RC_diagnostic']:
  c=dict(arch=arch,mos='tntp49_5v',VDD=5,temp=27,res='typ');ts.extend([tran(c,5,True),tran(c,10,True,1)])
  if arch=='RC_diagnostic':acs.extend(ac(c,cl,vc) for cl,vc in [(5,2.5),(10,2.5),(10,1.5),(10,3.5)]);ns.append(noise(c))
 save('pvt_ac',acs);save('pvt_noise',ns);save('pvt_transients',ts)
 for arch in ['baseline9','integrated6R']:
  rr=[x for x in acs if x['arch']==arch and x['status']=='OK' and x['PM_deg'] is not None];print(arch,'minPM',min(rr,key=lambda x:x['PM_deg']),'nominal',next(x for x in rr if x['mos']=='tntp49_5v' and x['res']=='typ' and x['VDD']==5 and x['temp']==27 and x['CL_pF']==5 and x['VC_V']==2.5),flush=True)
