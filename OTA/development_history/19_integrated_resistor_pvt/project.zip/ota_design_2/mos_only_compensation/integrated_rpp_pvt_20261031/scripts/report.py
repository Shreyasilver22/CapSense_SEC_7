from pathlib import Path
import json,hashlib,re,subprocess
import numpy as np,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,Patch
R=Path(__file__).resolve().parents[1]
a=json.loads((R/'pvt_ac.json').read_text());n=json.loads((R/'pvt_noise.json').read_text());t=json.loads((R/'pvt_transients.json').read_text());b=json.loads((R/'output_3p3_stress.json').read_text());cm=json.loads((R/'fixed_input_common_mode.json').read_text())
def nominal(x):return x['mos']=='tntp49_5v' and x['VDD']==5 and x['temp']==27 and x['res']=='typ'
summary={}
for arch in ['baseline9','integrated6R','RC_diagnostic']:
 rr=[x for x in a if x['arch']==arch and x['status']=='OK'];nn=[x for x in n if x['arch']==arch and x['status']=='OK'];tt=[x for x in t if x['arch']==arch and nominal(x)]
 summary[arch]=dict(nominal=next(x for x in rr if nominal(x) and x['CL_pF']==5 and x['VC_V']==2.5),nominal_large_10p_1ns=next(x for x in tt if x['large'] and x['CL_pF']==10 and x['dt_ns']==1),nominal_noise=next(x for x in nn if nominal(x)),worst_PM_case=min(rr,key=lambda x:x['PM_deg']),fixed5V_min_PM=min(x['PM_deg'] for x in rr if x['VDD']==5),noise_input_range_Vrms=[min(x['inoise_total'] for x in nn),max(x['inoise_total'] for x in nn)])
 if arch!='RC_diagnostic':summary[arch].update(cases_below60=sum(x['PM_deg']<60 for x in rr),total_main_AC_cases=len(rr),noise_cases=len(nn),follower3p3_worst=min((x for x in b if x['arch']==arch and x['status']=='OK'),key=lambda x:x['PM_deg']),fixed_input_1p5_output3p3_worst=min((x for x in cm if x['arch']==arch and x['status']=='OK' and x['output_target_V']==3.3),key=lambda x:x['PM_deg']))
(R/'comparison_summary.json').write_text(json.dumps(summary,indent=2))
fig,axs=plt.subplots(2,2,figsize=(13,9))
for arch,label in [('baseline9','Baseline: 9 caps'),('integrated6R','Integrated: 6 caps + RPP')]:
 d=R/'results'/f'{arch}_tntp49_5v_5_27_typ';ac=np.loadtxt(d/'ac_cl5_v2.5.dat',skiprows=1);tr=np.loadtxt(d/'tran_large_cl10_1ns.dat',skiprows=1);axs[0,0].semilogx(ac[:,0],ac[:,1],label=label);axs[0,1].plot(tr[:,0]*1e6,tr[:,2],label=label)
 for vc,style in [(2.5,'-o'),(3.5,'--s')]:
  vals=[min(x['PM_deg'] for x in a if x['arch']==arch and x['status']=='OK' and x['VDD']==v and x['VC_V']==vc) for v in [4.5,5,5.5]];axs[1,0].plot([4.5,5,5.5],vals,style,label=f'{label}; bias={vc} V')
 no=np.loadtxt(d/'noise.dat',skiprows=1);axs[1,1].loglog(no[:,0],no[:,2]*1e9,label=label)
axs[0,0].set(xlim=(1e3,1e8),xlabel='Frequency (Hz)',ylabel='Gain (dB)',title='Nominal 5 pF, 2.5 V operating point');axs[0,1].set(xlim=(9.5,16),xlabel='Time (us)',ylabel='Output (V)',title='Nominal 2 V follower step into 10 pF');axs[1,0].axhline(60,color='black',ls=':');axs[1,0].set(xlabel='Supply (V)',ylabel='Worst phase margin (degrees)',title='Process / resistor / temperature sweep; tested bias points');axs[1,1].set(xlabel='Frequency (Hz)',ylabel='Input-referred noise (nV/sqrt(Hz))',title='Raw ngspice noise: transistor model translation unqualified')
for ax in axs.flat:ax.grid(alpha=.25);ax.legend(fontsize=7)
fig.tight_layout();fig.savefig(R/'plots/integrated_pvt_comparison.png',dpi=170);fig.savefig(R/'plots/integrated_pvt_comparison.pdf')
subprocess.run(['klayout','-b','-r',str(R/'scripts/export_geometry.py')],check=True,capture_output=True)
data=json.loads((R/'verification/geometry.json').read_text());colors={1:'#ac87cc',3:'#d7c6e3',2:'#53b966',5:'#ffcda0',6:'#f8b56a',4:'#dc5454',8:'#5599dd',10:'#d3bc40',7:'#272727',9:'#7c512d',44:'#dd8822',36:'#777777'}
fig,ax=plt.subplots(figsize=(9,9))
for layer in [3,1,5,6,2,4,44,36,8,10,7,9]:
 for la,x1,y1,x2,y2 in data:
  if la==layer:ax.add_patch(Rectangle((x1,y1),x2-x1,y2-y1,facecolor=colors[layer],edgecolor=colors[layer],alpha=.65,linewidth=.1))
ax.set(xlim=(-5,380),ylim=(-8,340),xlabel='x (um)',ylabel='y (um)',title='Integrated OTA: 6 MOS compensation units + RPP resistor');ax.set_aspect('equal');ax.text(100,325,'Ten series P-poly resistor sections',fontsize=10);ax.legend(handles=[Patch(color=colors[x],label=l) for x,l in [(1,'N-well'),(4,'Poly'),(44,'RPP body'),(8,'M1'),(10,'M2')]],loc='lower right',fontsize=8);fig.tight_layout();fig.savefig(R/'plots/integrated_layout.png',dpi=170);fig.savefig(R/'plots/integrated_layout.pdf')
# Relative-model nominal benches, including native local PDK model references.
tb=R/'tb';tb.mkdir(exist_ok=True)
for arch in ['baseline9','integrated6R','RC_diagnostic']:
 d=R/'results'/f'{arch}_tntp49_5v_5_27_typ';s=(d/'tran_large_cl10_1ns.cir').read_text().replace(str(R)+'/models/','../models/').replace('wrdata tran_large_cl10_1ns.dat',f'wrdata {arch}.dat');(tb/f'{arch}.cir').write_text(s)
# Record all extraction/parser warnings rather than claiming qualification from success exit codes.
warn=sorted(set(re.findall(r'unrecognized parameter \((.*?)\) - ignored',(R/'results/integrated6R_tntp49_5v_5_27_typ/noise.log').read_text())))
(R/'verification/qualification.json').write_text(json.dumps(dict(integrated_DRC='0 markers',integrated_LVS='MATCH; incorrect gate/size controls fail',C_model_topology='MATCH after documented marker/alias and tee-export adaptations',RC_contracted_topology='MATCH; substrate errors remain, RC diagnostic only',ignored_model_parameters=warn,noise_qualification='NOT qualified: nlev and several model parameters ignored; excess resistor noise absent',PVT_outcome='Fails assumed +/-10% supply high-bias envelope; fixed 5 V cases exceed 60 degrees in tested grid',scope='Nominal MOS geometry; no mismatch Monte Carlo, reliability signoff or SC redesign'),indent=2))
(R/'verification/hashes.json').write_text(json.dumps({str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [R/'layout/ota_design2_mos.gds',R/'models/integrated_C.spice',R/'models/integrated_RC_diagnostic.spice',R/'models/baseline9_C.spice']},indent=2))
print(json.dumps(summary,indent=2))
