import pya,json
from pathlib import Path
R=Path(__file__).resolve().parents[1]; ly=pya.Layout();ly.dbu=.001;c=ly.create_cell('ota_design2_mos')
def box(layer,x1,y1,x2,y2):c.shapes(ly.layer(layer,0)).insert(pya.DBox(x1,y1,x2,y2))
def text(layer,x,y,s):c.shapes(ly.layer(layer,7)).insert(pya.DText(s,pya.DTrans(pya.DVector(x,y))))
def contact(x,y):box(7,x-.6,y-.6,x+.6,y+.6);box(8,x-1.1,y-1.1,x+1.1,y+1.1)
def via(x,y):box(9,x-.75,y-.75,x+.75,y+.75);box(8,x-1.5,y-1.5,x+1.5,y+1.5);box(10,x-1.5,y-1.5,x+1.5,y+1.5)
nets=['INP','INN','OUT','VDD','VSS','IREF','N1','N2','TAIL','GCOMP']; by={n:-i*6 for i,n in enumerate(nets)}
dev=[]
def add(name,d,g,s,b,t,w,l,count=1):
 for k in range(count):dev.append((name+('_'+str(k) if count>1 else ''),d,g,s,b,t,w,l))
# ABBA input and mirror placements, preserving total W/L.
for nm in ['M1','M2','M2','M1']:
 add(nm,'N1' if nm=='M1' else 'N2','INN' if nm=='M1' else 'INP','TAIL','VSS','N',3.75,2.4)
for nm in ['M3','M4','M4','M3']:
 add(nm,'N1' if nm=='M3' else 'N2','N1','VDD','VDD','P',5,3.2)
add('M5','TAIL','IREF','VSS','VSS','N',20,3.2)
add('M8','IREF','IREF','VSS','VSS','N',20,3.2)
add('M6','OUT','N2','VDD','VDD','P',28,3.2,4)
add('MCAP','OUT','GCOMP','OUT','OUT','P',20,10,6)
add('M7','OUT','IREF','VSS','VSS','N',20,3.2,8)
# Unique reference names for split units.
dev=[(f'MU{i}',*d[1:]) for i,d in enumerate(dev)]
rows=[dev[:8],dev[8:14],dev[14:20],dev[20:]]
placements=[]; rowinfo=[]; ybase=0
for row in rows:
 used=[n for n in nets if any(n in d[1:5] for d in row)]
 buses={n:ybase+i*4.8 for i,n in enumerate(used)}
 y=ybase+len(used)*4.8+9
 x=70
 for d in row:
  placements.append((d,x,y,buses));x+=d[-1]+34
 rowinfo.append((buses,x));ybase=y+max(d[-2] for d in row)+14
for (name,d,g,s,b,t,w,l),x,y,by in placements:
 gx=x+8; sx=gx-3; dx=gx+l+3; bx=gx+l+10
 box(2,gx-4.5,y,gx+l+4.5,y+w)
 box(4,gx,y-1.5,gx+l,y+w+5)
 # poly contact outside active; route gate on M1 above device to its own drop
 gc=gx+l/2; contact(gc,y+w+3.2)
 box(8,x-1.1,y+w+2.1,gc+1.1,y+w+4.3)
 for tx,ty,n in [(x,y+w+3.2,g),(sx,y+w/2,s),(dx,y+w/2,d),(bx,y+3,b)]:
  box(8,tx-1.1,by[n],tx+1.1,ty+1.1);via(tx,by[n])
 contact(sx,y+w/2);contact(dx,y+w/2)
 box(2,bx-1.5,y+1.5,bx+1.5,y+4.5);contact(bx,y+3)
 if t=='P':
  box(1,gx-8,y-5,bx+5,y+w+7)
  box(3,gx-10,y-7,bx+7,y+w+9)
  for la in [5,6]:box(la,gx-5.2,y-.7,gx+l+5.2,y+w+.7)
 else:
  for la in [5,6]:box(la,bx-2.2,y+.8,bx+2.2,y+5.2)
 pass # Internal routing is unlabeled to avoid creating extra cell ports
# Connect each row's horizontal M2 buses to separate vertical M1 trunks.
for by,end in rowinfo:
 for n,yy in by.items():
  tx=5+nets.index(n)*5
  box(10,tx-1.5,yy-1.5,end,yy+1.5);via(tx,yy)
for n in nets:
 tx=5+nets.index(n)*5; ys=[by[n] for by,end in rowinfo if n in by]
 box(8,tx-1.1,min(ys)-1.5,tx+1.1,max(ys)+1.5)
 if n in nets[:6]:text(8,tx,min(ys),n)
# Integrated P-poly resistor: ten 1.6k sections above the OTA, connected to N2 / GCOMP.
rx=80; ry=260; rl=137.143; rw=2.4
for k in range(10):
 yy=ry+6*k;box(4,rx-3.6,yy-rw/2,rx+rl+3.6,yy+rw/2)
 for la in [5,6]:box(la,rx-4.3,yy-1.9,rx+rl+4.3,yy+1.9)
 box(44,rx,yy-rw/2,rx+rl,yy+rw/2)
 for xx in [rx-1.8,rx+rl+1.8]:contact(xx,yy)
 box(36,rx-3.6,yy-rw/2,rx,yy+rw/2);box(36,rx+rl,yy-rw/2,rx+rl+3.6,yy+rw/2)
 if k<9:
  xx=rx+rl+1.8 if k%2==0 else rx-1.8;box(8,xx-1.1,yy-1.1,xx+1.1,yy+7.1)
for net,yy in [('N2',ry),('GCOMP',ry+54)]:
 xx=5+nets.index(net)*5;ys=[by[net] for by,end in rowinfo if net in by]
 box(8,xx-1.1,min(ys)-1.5,xx+1.1,yy+1.5);via(xx,yy);via(rx-8,yy);box(8,rx-9.1,yy-1.1,rx-.7,yy+1.1);box(10,xx-1.5,yy-1.5,rx-6.5,yy+1.5)
ly.write(str(R/'layout/ota_design2_mos.gds'))
lines=['* Exact implemented transistor reference; folded devices remain explicit.','.subckt ota_design2_mos INP INN OUT VDD VSS IREF']
for name,d,g,s,b,t,w,l in dev:lines.append(f'{name} {d} {g} {s} {b} {t} W={w}u L={l}u')
lines+=['.ends ota_design2_mos'];(R/'schematic/ota_design2_mos.cdl').write_text('\n'.join(lines)+'\n')
print('devices',len(dev),'bbox',c.dbbox())

(R/'verification/placements.json').write_text(json.dumps([{'device':d[0],'drain':d[1],'gate':d[2],'source':d[3],'bulk':d[4],'type':d[5],'W_um':d[6],'L_um':d[7],'x_um':x,'y_um':y} for d,x,y,b in placements],indent=2))
