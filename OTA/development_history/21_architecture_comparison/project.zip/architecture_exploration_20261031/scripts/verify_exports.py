from pathlib import Path
import subprocess,concurrent.futures,json
import numpy as np
R=Path(__file__).resolve().parents[1]

def check(p):
 result=dict(deck=p.name,status='FAILED')
 try:
  proc=subprocess.run(['ngspice','-b','-o',p.stem+'.log',p.name],cwd=p.parent,capture_output=True,timeout=90)
  arch,mode=p.stem.rsplit('_',1);out=p.parent/(p.stem+'.dat');a=np.loadtxt(out,skiprows=1)
  ref=np.loadtxt(R/'results'/arch/('nominal' if mode=='ac' else 'tran_10')/(mode+'.dat'),skiprows=1)
  assert proc.returncode==0 and a.shape==ref.shape
  assert np.allclose(a,ref,rtol=1e-6,atol=1e-10),float(np.max(abs(a-ref)))
  result.update(status='PASS',rows=len(a))
 except Exception as e:result['error']=str(e)
 return result

if __name__=='__main__':
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:r=list(ex.map(check,sorted((R/'tb').glob('*.cir'))))
 (R/'export_verification.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
