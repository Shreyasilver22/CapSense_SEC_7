import os
os.environ.setdefault('MPLCONFIGDIR','/tmp/ota_arch_mpl')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import study as s, validate as v
import numpy as np
import json,csv,hashlib,re
R=s.R
load=lambda name:json.loads((R/(name+'.json')).read_text())
names={'baseline':'Current OTA (extracted C)','baseline_schematic':'Current OTA (schematic control)','fully_diff':'Basic fully differential','telescopic':'Telescopic + CMFB','folded':'Folded cascode + CMFB','gain_boosted':'Dual-side gain-boosted + CMFB','class_ab':'Class-AB buffered two-stage'}
colors=dict(zip(v.PARS,['#333333','#8c6bb1','#1b9e77','#d95f02','#2878b5','#c43c67']))
ac=load('ac_screen');ts=load('final_transients_and_control');loops=load('loop_checks');stress=load('loop_stress');ranges=load('range_screen')
nom={a:next(x for x in ac if x['arch']==a and x['tag']=='nominal') for a in v.PARS}
summary=[]
for a in v.PARS:
 t=next(x for x in ts if x['arch']==a and x['tag']=='tran_10');rows=[x for x in ac if x['arch']==a];rr=[x for x in ranges if x['arch']==a];ll=[x for x in stress if x['arch']==a]
 summary.append(dict(architecture=a,gain_dB=nom[a].get('gain_dB'),UGF_MHz=nom[a].get('UGF_MHz'),power_uW=nom[a].get('power_uW'),nominal_PM_deg=nom[a].get('PM_deg'),center_CM_min_PM_deg=min(x['PM_deg'] for x in rows if x.get('PM_deg') is not None),range_min_PM_deg=min(x['PM_deg'] for x in rr if x.get('PM_deg') is not None),range_max_DC_error_mV=max(abs(x['out_V']-x['vo'])*1000 for x in rr if x.get('out_V') is not None),cmfb_and_booster_min_PM_deg=min((x['min_PM_deg'] for x in ll if x.get('min_PM_deg') is not None),default=None),settling_10p_us=t.get('settling_us'),static_error_mV=t.get('static_error_mV'),differential_error_mV=t.get('differential_error_mV'),common_mode_error_mV=t.get('common_mode_error_mV')))
s.save('comparison',summary)
plt.rcParams.update({'font.size':10,'axes.grid':True,'grid.alpha':.25})
fig,ax=plt.subplots(2,1,figsize=(11,8),sharex=True)
for a in v.PARS:
 d=np.loadtxt(R/'results'/a/'nominal/ac.dat',skiprows=1);h=d[:,1]+1j*d[:,2]
 ax[0].semilogx(d[:,0],20*np.log10(abs(h)),label=names[a],color=colors[a]);ax[1].semilogx(d[:,0],np.unwrap(np.angle(h))*180/np.pi,color=colors[a])
ax[0].set(ylabel='Open-loop gain (dB)',ylim=(-45,140),title='SCL800 screening: 5 V, 27 C; FD input CM 1.5 V; SE follower / output CM 2.5 V')
ax[0].axhline(0,color='grey',lw=.7);ax[0].legend(fontsize=8,ncol=2)
ax[1].set(xlabel='Frequency (Hz)',ylabel='Phase (degrees)',xlim=(.01,1e8),ylim=(-270,10));ax[1].axhline(-180,color='grey',ls='--')
fig.text(.5,.01,'5 pF per output. New candidates: estimated junction geometry, no routed extraction; baseline: extracted C.',ha='center',fontsize=9)
fig.tight_layout(rect=(0,.03,1,1));fig.savefig(R/'plots/ac_comparison.png',dpi=180);fig.savefig(R/'plots/ac_comparison.pdf');plt.close(fig)
fig,ax=plt.subplots(3,1,figsize=(11,10),sharex=True)
for a in v.PARS:
 d=np.loadtxt(R/'results'/a/'tran_10/tran.dat',skiprows=1);tt=d[:,0]*1e6;fd=a not in ['baseline','class_ab'];target=(d[:,1]/2+2.5) if fd else d[:,1]
 ax[0].plot(tt,d[:,2],color=colors[a],label=names[a]);ax[1].plot(tt,(d[:,2]-target)*1e3,color=colors[a])
 if fd:ax[2].plot(tt,((d[:,2]+d[:,3])/2-2.5)*1e3,color=colors[a])
ax[0].plot(tt,target,'k--',lw=.8,label='Target per output');ax[0].set(ylabel='OUTP / OUT (V)',title='2 V step per output, 10 pF per output; fully differential outputs move in opposite directions');ax[0].legend(ncol=2,fontsize=8)
ax[1].set(ylabel='Raw pin error (mV)',ylim=(-30,30));ax[2].set(xlabel='Time (us)',ylabel='FD output CM error (mV)',xlim=(8,48),ylim=(-30,30))
fig.tight_layout();fig.savefig(R/'plots/transient_comparison.png',dpi=180);fig.savefig(R/'plots/transient_comparison.pdf');plt.close(fig)
fig,ax=plt.subplots(1,2,figsize=(11,4.5))
for a in v.PARS:
 ax[0].scatter(nom[a]['power_uW'],nom[a]['UGF_MHz'],s=80,c=colors[a]);ax[0].annotate(a,(nom[a]['power_uW'],nom[a]['UGF_MHz']),xytext=(5,5),textcoords='offset points',fontsize=8)
 d=np.loadtxt(R/'results'/'class_ab'/'tran_10/tran.dat',skiprows=1)
ax[0].set(xlabel='Nominal modeled VDD power (uW)',ylabel='UGF (MHz)',title='Screening tradeoff; unequal total load and bias allocation')
ax[1].plot(d[:,0]*1e6,d[:,5]*1e6,label='NMOS source current');ax[1].plot(d[:,0]*1e6,d[:,6]*1e6,label='PMOS sink current');ax[1].set(xlabel='Time (us)',ylabel='Output device current (uA)',xlim=(8,48),title='Class-AB output currents, 10 pF');ax[1].legend(fontsize=8)
fig.tight_layout();fig.savefig(R/'plots/power_and_class_ab.png',dpi=180);fig.savefig(R/'plots/power_and_class_ab.pdf');plt.close(fig)

# Export unique reusable subcircuit names and ready-to-run standalone benches.
(R/'tb').mkdir(exist_ok=True)
for a,p in v.PARS.items():
 model=R/'models'/(a+'.spice')
 if a=='baseline':text=(R/'models/baseline_C.spice').read_text()
 else:text=s.make(a,**p).replace('.subckt dut ','.subckt ota_'+a+' ').replace('.ends dut','.ends ota_'+a)
 model.write_text(text)
 for mode in ['ac','tran']:
  text=s.bench(a,model,mode=mode,cl=5 if mode=='ac' else 10)
  text=text.replace(str(model),'../models/'+model.name)
  if a!='baseline':text=text.replace(' bn dut',' bn ota_'+a).replace(' vcm dut',' vcm ota_'+a)
  text=text.replace('wrdata '+mode+'.dat','wrdata '+a+'_'+mode+'.dat')
  (R/'tb'/(a+'_'+mode+'.cir')).write_text(text)

table='| Candidate | Gain (dB) | UGF (MHz) | Power (uW) | 10 pF settling (us) |\n|---|---:|---:|---:|---:|\n'
for x in summary:
 st=f"{x['settling_10p_us']:.3f}" if x['settling_10p_us'] is not None else 'not settled'
 table+=f"| {names[x['architecture']]} | {x['gain_dB']:.1f} | {x['UGF_MHz']:.3f} | {x['power_uW']:.1f} | {st} |\n"
ctrl=next(x for x in ts if x['arch']=='baseline_schematic' and x['mode']=='ac')
findings=[]
for x in summary:
 a=x['architecture'];q=[y for y in stress if y['arch']==a and y.get('min_PM_deg') is not None];r=[y for y in ranges if y['arch']==a]
 findings.append(f"- {names[a]}: center-CM differential PM minimum {x['center_CM_min_PM_deg']:.2f} deg; output-CM/end-point minimum {x['range_min_PM_deg']:.2f} deg; largest DC output-CM tracking error {x['range_max_DC_error_mV']:.2f} mV. "+(f"Additional CMFB/booster loop screening minimum {min(y['min_PM_deg'] for y in q):.2f} deg." if q else ''))
failures=[x for arr in [ac,ts,loops,stress,ranges] for x in arr if x['status']!='OK']
R.joinpath('README.md').write_text(f'''# SCL800 OTA architectural exploration — 31 October 2026

Five new transistor-level alternatives were constructed and actually simulated in ngspice 42 against the current extracted-capacitance OTA. These are first-pass architectural candidates, not new tapeout-qualified designs. The original OTA and SC circuit were not edited. No GitHub publication was performed.

## What was built

- `fully_diff`: simple NMOS differential pair with PMOS current-source loads and continuous-time CMFB. This is a low-gain control, not a two-stage fully differential implementation.
- `telescopic`: NMOS input pair, NMOS and PMOS cascodes, PMOS source loads, continuous-time CMFB.
- `folded`: NMOS input pair, PMOS folding branches, cascoded NMOS sinks, continuous-time CMFB.
- `gain_boosted`: telescopic core with four finite-bandwidth transistor auxiliary amplifiers regulating both NMOS drain nodes and both PMOS source nodes. These are not ideal gain blocks. NMOS targets 1.1 V; PMOS targets VDD minus 1.2 V.
- `class_ab`: two-stage single-ended amplifier followed by diode-level-shifted complementary source followers. Both output devices conduct at rest and transient output current increases during steps. The internal second-stage sink uses four units, the PMOS second stage four units, the output followers eight units each, compensation ten W20/L10 PMOS units and nominal 16 kohm native RPP.
- `baseline`: prior 12-cap/28k/16-finger-PMOS C-extracted design, unchanged.

These are overlapping architectural choices: all three cascode candidates are fully differential and include CMFB. Only the class-AB prototype retains the tested single-ended interface of the current SC circuit. The differential candidates were tested with a differential external feedback interface. They could also be investigated using only one output in the current SC circuit, with the complementary output maintained by CMFB, but that changes gain, loading and loop behavior and has not been verified here. These differential performance numbers must not be applied to that untested connection.

## Nominal measured results

5 V, 27 C, typical native MOS/resistor models, input common mode 1.5 V for differential candidates, output common mode 2.5 V, CL=5 pF **per output** for AC. A fully differential candidate therefore drives two external load capacitors. Settling uses CL=10 pF per output and a 2 V step on each output. Fully differential command steps -2 to +2 V; outputs ideally exchange 1.5 and 3.5 V.

{table}
Gain is measured at 0.001 Hz, UGF interpolated at the downward unity crossing. Settling is the worst of both edges and both output pins, to within 2 mV of each pin's final value (0.1% of its 2 V step). **Static error is separate; a short settling time does not imply accurate absolute output.** See `comparison.csv` for both common-mode and differential final errors.

The class-AB and telescopic 10 pF steps were repeated with a 1 ns maximum step: class-AB 3.419 us versus 3.423 us at 5 ns; telescopic 3.491 us versus 3.491 us. These confirm the nominal timing measurement, not transient PVT qualification. `timestep_check.json` retains exact values.

The extra schematic-only current-OTA control measures gain {ctrl['gain_dB']:.2f} dB, UGF {ctrl['UGF_MHz']:.3f} MHz and power {ctrl['power_uW']:.2f} uW. Its geometry is also estimated; the extracted baseline remains the reliable physical comparison.

## Corner and feedback checks

{len(ac)} main AC cases: each architecture has one nominal case plus 40 combinations of five native MOS files, VDD 4.5/5.5 V, temperature 0/85 C, CL 1/10 pF, centered output CM 2.5 V. These are assumed exploratory ranges, not established chip requirements or reliability limits. Resistor corner is typical in this study.

{len(ranges)} additional output-level checks: the same endpoint MOS/supply/temperature grid, CL10 pF, output setpoint 1.5 or 3.5 V. For differential cores these change **both outputs' common-mode setpoint**, not the individual output endpoints of an opposite-polarity signal. Large-signal transient testing separately checks the latter at nominal conditions. A large DC tracking error invalidates the intended operating point even if a phase margin is returned.

{len(loops)} nominal feedback-loop checks plus {len(stress)} endpoint feedback-loop checks: CMFB return is injected symmetrically at its sensing gates, keeping its compensation network connected. The four gain-booster loops are individually voltage-injected with other loops closed. These are engineering small-signal loop diagnostics, not a formal multi-loop Nyquist/pole-count certification. CMFB loops are measured from 100 Hz to avoid ill-conditioning of the DC-closing fixture; low-frequency gain in those records is gain at 100 Hz.

{chr(10).join(findings)}

Simulation execution failures in these final datasets: {len(failures)}. Completion means that data was generated, not that a design met accuracy, stability or headroom requirements. All unity crossings are retained in JSON; no case is discarded for a poor result.

## CMFB development and remaining cost

An initial two-differential-pair detector lost common-mode control for large differential signals: each pair became fully steered. These rejected results are retained in `uncompensated_*` records. Direct 100k resistive averaging also loaded the high-impedance outputs and destroyed cascode gain. The final prototype buffers each output with a PMOS source follower, averages buffered voltages with two **1 Mohm native RPP** resistors, and compares against an identically shifted reference using a transistor error amplifier.

Its local compensation is four PMOS units to VDD plus eight PMOS Miller units from its control node to each output. It consumes extra current and loads the differential outputs capacitively. Source-follower nonlinearity introduces signal-dependent CM offset; the nominal 2 V pin steps show about 10 mV common-mode error in the cascode prototypes, which must not be mistaken for differential signal error. Two 1 Mohm poly resistors and many MOS compensation units may be expensive in area and parasitics. No compact CMFB layout has been demonstrated here.

## Interpretation and next design choice

The simple fully differential core has insufficient gain for a precision integrator. Telescopic is a useful speed/power candidate **if input common mode is held near 1.5 V**; the saved 2.5 V input-CM check exposes its headroom/gain loss. Folded cascode preserves input-CM flexibility but consumes more current in these initial sizes. Gain boosting raises matched-model low-frequency gain greatly but does not improve the dominant load-limited bandwidth or nominal large-step settling much over telescopic, and adds four loops and ideal bias references. Its very high gain is a simulation result, not a promised fabricated gain.

Class-AB retains the existing single-ended interface and shows useful nominal power/settling improvement, but this source-follower implementation fails the full assumed output/supply screen: inspect `range_screen.json` for low-supply/output endpoint failures and DC swing limitations. Its output loses rail headroom. It needs an output-stage/bias revision before layout. The nominal improvement cannot be extended to all PVT conditions. No architecture is yet selected as the optimum.

For fully differential SC redesign, compare telescopic against folded cascode after compact CMFB/bias optimization and extracted layout. The current single-ended OTA remains the physical reference until a new candidate passes the complete required signal-range, PVT, noise and extraction checks.

## Model and comparison limitations

- Original native SCL08 five LEVEL49/BSIM3 5 V MOS files were included directly, plus native typical `ppr`. No PDK model card was copied into this package. The existing ngspice model-translation/ignored-parameter warnings remain; raw noise is not qualified and no architecture noise ranking is claimed.
- Intentional compensation uses real PMOS devices; resistors use native `RPP`. External test loads and feedback/DC-closing fixtures are ideal testbench elements.
- New MOS instances have **estimated** source/drain areas W*4.5 um and perimeters 2*(W+4.5 um), per unit device. These estimate junction loading; they are not extracted geometry. Defaults with zero junction area were retained only as preliminary results in `pre_junction_estimates/` and are excluded from final comparison.
- New candidates have no routed interconnect/well/substrate extraction, DRC, LVS, matching layout or Monte Carlo verification. The baseline already includes adapted-extractor routing capacitances and previously documented resistor-body capacitance. This difference can favor the new schematics.
- Ideal external 3.5 uA reference, noiseless cascode/reference voltage supplies, ideal CM reference. Power includes modeled VDD core/controller/booster currents but excludes a real reference generator, external reference/clock drivers and their noise. Current allocations and total output loads are not equal across architectures; these results are not a global optimization or an equal-power proof.
- No transient PVT qualification, SAR/SC integration of the new architectures, capacitor matching, noise budget, PSRR/CMRR qualification or physical area claim. The original SC circuit is unchanged.

## Reproduction and files

`models/`: uniquely named exported candidate subcircuits and the original extracted baseline. `tb/`: standalone nominal AC and large-step decks. From `tb`, run `ngspice -b -o folded_ac.log folded_ac.cir` (or another candidate). AC data and log are saved locally. PDK is expected at `/home/berson_meshak/pdk/scl08/ngspice_models49`.

All twelve exported standalone decks (AC and transient for six designs including the baseline) were separately simulated and their data matched the generator-run results. See `export_verification.json`; PASS there means export equivalence, not specification compliance.

`scripts/study.py`: transistor generator and measurement; `validate.py`: main screening and nominal loops; `stress.py`: output-range and loop stress; `report.py`: export/report/plots. Run validate, stress, then report in that order. Raw generation benches in `results/` preserve their original execution paths; regenerate using scripts after relocating. The standalone `tb/` decks use relative local model includes.

Plots: `plots/ac_comparison.png`, `plots/transient_comparison.png`, `plots/power_and_class_ab.png` (PDFs also supplied). `comparison.json/csv` contains compact metrics. Raw simulation logs and data are under `results/`. Exploratory tags such as `initial`, `tune_*`, `buffer_*` and `cm_comp_test` are intermediate trials, not final candidates. The final selected parameters are `validate.PARS` and exported `models/`.

Conceptual background: [Analog Devices, multistage and cascode configurations](https://wiki.analog.com/university/courses/electronics/text/chapter-10), and [C. G. Myers, pipeline ADC thesis (gain boosting and common-mode control)](https://web.engr.oregonstate.edu/~moon/research/files/Charlie_Myers.pdf). Numerical findings above come from this project's saved simulations, not those references.
''')
hashes={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for folder in ['models','tb','scripts'] for p in (R/folder).glob('*') if p.is_file()}
(R/'hashes.json').write_text(json.dumps(hashes,indent=2))
print(json.dumps(summary,indent=2))
