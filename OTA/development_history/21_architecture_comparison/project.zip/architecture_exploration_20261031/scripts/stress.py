import study as s, validate as v
import itertools, concurrent.futures

if __name__=='__main__':
 configs=[dict(mos=m,vdd=d,temp=t) for m,d,t in itertools.product(['tntp49_5v','bnbp49_5v','bnwp49_5v','wnbp49_5v','wnwp49_5v'],[4.5,5.5],[0,85])]
 jobs=[(a,'range_'+str(vo)+'_'+str(i),p,dict(**c,vo=vo,cl=10)) for a,p in v.PARS.items() for i,c in enumerate(configs) for vo in [1.5,3.5]]
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:rows=list(ex.map(lambda j:s.execute(j[0],j[1],j[2],**j[3]),jobs))
 s.save('range_screen',rows);print('Range cases',len(rows),flush=True)
 jobs=[(a,'cmfb',dict(**c,cl=10)) for a in v.PARS if a not in ['baseline','class_ab'] for c in configs]
 jobs += [('gain_boosted',loop,dict(**c,cl=10)) for loop in ['gn1','gn2','gp1','gp2'] for c in configs]
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:rows=list(ex.map(lambda j:v.loops(j[0],j[1],**j[2]),jobs))
 s.save('loop_stress',rows);print('Loop cases',len(rows),flush=True)
 # Refresh nominal transients with metrics on both differential outputs.
 jobs=[(a,'tran_'+str(cl),p,cl) for a,p in v.PARS.items() for cl in [5,10]]
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:rows=list(ex.map(lambda j:s.execute(j[0],j[1],j[2],mode='tran',cl=j[3]),jobs))
 rows += [s.execute('baseline_schematic','nominal'),s.execute('baseline_schematic','tran_10',mode='tran',cl=10)]
 s.save('final_transients_and_control',rows);print('Transient/control',len(rows),flush=True)
