from pathlib import Path
import subprocess, json, re, itertools, concurrent.futures, csv, shutil
import numpy as np
R=Path(__file__).resolve().parents[1]
PDK=Path('/home/berson_meshak/pdk/scl08/ngspice_models49')
OLD=Path('/home/berson_meshak/final year project/ota/ota_design_2/mos_only_compensation/stability_recovery_20261031/integrated_revision/models/integrated_C.spice')

def cmfb():
 return '''* Buffered resistive common-mode sensing; reference has matched level shift.
MSP 0 op sp vdd P W=40u L=1.6u
MSM 0 om sm vdd P W=40u L=1.6u
MSR 0 vcm sr vdd P W=40u L=1.6u
MSIP sp cb vdd vdd P W=40u L=3.2u
MSIM sm cb vdd vdd P W=40u L=3.2u
MSIR sr cb vdd vdd P W=40u L=3.2u
XSP sp sense RPP W=2.4u L=85714.285714u
XSM sm sense RPP W=2.4u L=85714.285714u
MCS ca sense ct 0 N W=10u L=2.4u
MCR pc sr ct 0 N W=10u L=2.4u
MCBI cb cb vdd vdd P W=20u L=3.2u
MCBN cb bn 0 0 N W=11.428571u L=3.2u
MCT ct bn 0 0 N W=11.428571u L=3.2u
MCP1 ca ca vdd vdd P W=20u L=3.2u
MCP2 pc ca vdd vdd P W=20u L=3.2u
MCC vdd pc vdd vdd P W=20u L=10u M=4
* Symmetric MOS Miller compensation of the common-mode loop.
MCM1 op pc op op P W=20u L=10u M=8
MCM2 om pc om om P W=20u L=10u M=8
'''

def auxiliary(out,sense,idx):
 return f'''* Inverting NMOS drain regulator {idx}; finite-bandwidth transistor amplifier.
MAN{idx} {out} {sense} at{idx} 0 N W=10u L=1.6u
MAR{idx} am{idx} vr at{idx} 0 N W=10u L=1.6u
MAT{idx} at{idx} bn 0 0 N W=11.428571u L=3.2u
MAP{idx} am{idx} am{idx} vdd vdd P W=20u L=1.6u
MAO{idx} {out} am{idx} vdd vdd P W=20u L=1.6u
'''

def pauxiliary(out,sense,idx):
 return f'''MPAN{idx} {out} {sense} pat{idx} vdd P W=20u L=1.6u
MPAR{idx} pam{idx} vrp pat{idx} vdd P W=20u L=1.6u
MPAT{idx} pat{idx} bpa vdd vdd P W=11.428571u L=3.2u
MPAP{idx} pam{idx} pam{idx} 0 0 N W=10u L=1.6u
MPAO{idx} {out} pam{idx} 0 0 N W=10u L=1.6u
'''

def make_core(arch,nb=2.4,pb=2.8,cap=4,kbuf=4):
 if arch=='baseline': return '.include "'+str(R/'models/baseline_C.spice')+'"\n'
 if arch=='baseline_schematic':
  text=make('class_ab',cap=12).split('* Matched diode')[0]
  text=re.sub(r'\by\b','op',text).replace('L=3.2u M=4','L=3.2u M=16',1)
  text=text.replace('MN7 op bn 0 0 N W=20u L=3.2u M=4','MN7 op bn 0 0 N W=20u L=3.2u M=8').replace('L=1371.428571u','L=2400u')
  return text+'.ends dut\n'
 if arch=='class_ab':
  return f'''* Two-stage OTA plus diode-level-shifted complementary source-follower output.
.subckt dut ip im op vdd bn
MN1 n1 im tail 0 N W=3.75u L=2.4u M=2
MN2 n2 ip tail 0 N W=3.75u L=2.4u M=2
MP1 n1 n1 vdd vdd P W=5u L=3.2u M=2
MP2 n2 n1 vdd vdd P W=5u L=3.2u M=2
MT tail bn 0 0 N W=20u L=3.2u
MP6 y n2 vdd vdd P W=28u L=3.2u M=4
MN7 y bn 0 0 N W=20u L=3.2u M=4
XRC n2 gc RPP W=2.4u L=1371.428571u
MCOMP y gc y y P W=20u L=10u M={cap}
* Matched diode / output source followers; mirrors provide level-shifter bias.
MIBP bp bp vdd vdd P W=20u L=3.2u
MINB bp bn 0 0 N W=5.714286u L=3.2u
MIUP ng bp vdd vdd P W=20u L=3.2u
MIDN pg bn 0 0 N W=5.714286u L=3.2u
MND ng ng y 0 N W=20u L=1.6u
MPD pg pg y vdd P W=40u L=1.6u
MNOUT vdd ng op 0 N W=20u L=1.6u M={kbuf}
MPOUT 0 pg op vdd P W=40u L=1.6u M={kbuf}
.ends dut
'''
 text='''.subckt dut ip im op om vdd bn vcm
'''+cmfb()
 tail=28 if arch=='fully_diff' else 14
 text+=f'MTAIL tail bn 0 0 N W={20*tail/3.5}u L=3.2u\n'
 if arch=='fully_diff':
  text+='''MN1 om ip tail 0 N W=15u L=2.4u
MN2 op im tail 0 N W=15u L=2.4u
MP1 om pc vdd vdd P W=80u L=3.2u
MP2 op pc vdd vdd P W=80u L=3.2u
'''
 elif arch in ['telescopic','gain_boosted']:
  text+=f'''VN nb 0 {nb}
VP pb vdd {pb-5}
MN1 nx1 ip tail 0 N W=15u L=2.4u
MN2 nx2 im tail 0 N W=15u L=2.4u
MNC1 om {'gn1' if arch=='gain_boosted' else 'nb'} nx1 0 N W=30u L=2.4u
MNC2 op {'gn2' if arch=='gain_boosted' else 'nb'} nx2 0 N W=30u L=2.4u
MPC1 om {'gp1' if arch=='gain_boosted' else 'pb'} px1 vdd P W=60u L=2.4u
MPC2 op {'gp2' if arch=='gain_boosted' else 'pb'} px2 vdd P W=60u L=2.4u
MP1 px1 pc vdd vdd P W=40u L=3.2u
MP2 px2 pc vdd vdd P W=40u L=3.2u
'''
  if arch=='gain_boosted':
   text+=f'VR vr 0 {nb}\nVRP vrp vdd {pb-5}\n'+auxiliary('gn1','nx1',1)+auxiliary('gn2','nx2',2)
   text+='MPAB bpa bpa vdd vdd P W=20u L=3.2u\nMNAB bpa bn 0 0 N W=20u L=3.2u\n'
   text+=pauxiliary('gp1','px1',1)+pauxiliary('gp2','px2',2)
 else:
  text+=f'''VN nb 0 {nb}
VP pb vdd {pb-5}
MN1 fx1 ip tail 0 N W=15u L=2.4u
MN2 fx2 im tail 0 N W=15u L=2.4u
MP1 fx1 pc vdd vdd P W=80u L=3.2u
MP2 fx2 pc vdd vdd P W=80u L=3.2u
MPC1 om pb fx1 vdd P W=60u L=2.4u
MPC2 op pb fx2 vdd P W=60u L=2.4u
MNLOW1 ln1 bn 0 0 N W=40u L=3.2u
MNLOW2 ln2 bn 0 0 N W=40u L=3.2u
MNC1 om nb ln1 0 N W=30u L=2.4u
MNC2 op nb ln2 0 N W=30u L=2.4u
'''
 return text+'.ends dut\n'

def make(arch,**kw):
 text=make_core(arch,**kw);lines=[]
 for line in text.splitlines():
  if line.startswith('M') and ' ad=' not in line.lower():
   match=re.search(r'\bW=([\d.]+)u',line,re.I)
   if match:
    w=float(match.group(1))
    # First-pass geometric estimate; NOT a layout extraction. Per unit device.
    line+=f' AD={w*4.5:g}p AS={w*4.5:g}p PD={2*(w+4.5):g}u PS={2*(w+4.5):g}u'
  lines.append(line)
 return '\n'.join(lines)+'\n'

def bench(arch,model,cl=5,vin=1.5,vo=2.5,vdd=5,temp=27,mos='tntp49_5v',mode='ac',dt_ns=5):
 fd=arch not in ['baseline','baseline_schematic','class_ab']
 text=f'''SCL800 architecture screening {arch}; schematic unless baseline
.include "{PDK}/mos/{mos}"
.include "{PDK}/res/typ/ppr"
.include "{model}"
.temp {temp}
.options reltol=1e-5 vntol=1e-8 abstol=1e-12
VDD vdd 0 {vdd}
IREF vdd bn 3.5u
'''
 if arch!='baseline':text+='MREF bn bn 0 0 N W=20u L=3.2u\n'
 if fd:
  text+=f'''VCM vcm 0 {vo}
XU ip im op om vdd bn vcm dut
CLP op 0 {cl}p
CLM om 0 {cl}p
EOD od 0 op om 1
EIP ip 0 value={{{vin}+(v(cmd)-v(fb))/2}}
EIM im 0 value={{{vin}-(v(cmd)-v(fb))/2}}
'''
 else:
  text+=f'''XU ip im op vdd {'0 bn ota_design2_mos' if arch=='baseline' else 'bn dut'}
CLP op 0 {cl}p
EOD od 0 op 0 1
EIP ip 0 cmd 0 1
EIM im 0 fb 0 1
'''
 if mode=='ac':
  text+=f'''VCMD cmd 0 dc {0 if fd else vo} ac 1
LDC od fb 1e12
CAC fb 0 1e12
'''
  control='''op
print v(op) i(vdd)
ac dec 100 0.001 1G
let gr=real(v(od))
let gi=imag(v(od))
wrdata ac.dat gr gi
'''
 elif mode=='tran':
  text+=f'''VCMD cmd 0 pulse({'-2 2' if fd else '1.5 3.5'} 10u 10n 10n 30u 60u)
VFB fb od 0
'''
  control=f'tran {dt_ns}n 75u\nwrdata tran.dat v(cmd) v(op) '+('v(om)' if fd else 'v(op)')+' i(vdd)\n'
 elif mode=='cm':
  text+='VCMD cmd 0 0\nVFB fb od 0\nICM 0 op pulse(0 1u 10u 10n 10n 10u 30u)\nICM2 0 om pulse(0 1u 10u 10n 10n 10u 30u)\n'
  control='tran 5n 50u\nwrdata cm.dat v(op) v(om)\n'
 elif mode=='dc':
  text+='VCMD cmd 0 0\nVFB fb od 0\n' if fd else 'VCMD cmd 0 2.5\nVFB fb od 0\n'
  control='dc VCMD -3 3 0.1\nwrdata dc.dat v(op) v(om)\n' if fd else 'dc VCMD 0.5 4.5 0.1\nwrdata dc.dat v(op)\n'
 if arch=='class_ab' and mode=='tran':
  control='save all @m.xu.mnout[id] @m.xu.mpout[id]\n'+control.replace('i(vdd)\n','i(vdd) @m.xu.mnout[id] @m.xu.mpout[id]\n')
 text+='.control\nset wr_singlescale\nset wr_vecnames\n'+control+'quit\n.endc\n.end\n'
 return text

def execute(arch,tag,pars=None,mode='ac',**kw):
 d=R/'results'/arch/tag;d.mkdir(parents=True,exist_ok=True)
 m=d/'dut.spice';m.write_text(make(arch,**(pars or {})))
 (d/'tb.cir').write_text(bench(arch,m,mode=mode,**kw))
 rec=dict(arch=arch,tag=tag,mode=mode,**kw,pars=pars or {},status='FAILED')
 try:
  p=subprocess.run(['ngspice','-b','-o','sim.log','tb.cir'],cwd=d,capture_output=True,timeout=90)
  a=np.loadtxt(d/(mode+'.dat'),skiprows=1);assert p.returncode==0 and len(a)>10
  rec['status']='OK'
  if mode=='ac':
   h=a[:,1]+1j*a[:,2];g=20*np.log10(abs(h));ph=np.unwrap(np.angle(h))*180/np.pi
   crossings=[]
   for i in np.where(g[:-1]*g[1:]<0)[0]:
    t=-g[i]/(g[i+1]-g[i]);crossings.append(dict(f_MHz=float(10**(np.log10(a[i,0])+t*np.log10(a[i+1,0]/a[i,0]))/1e6),pm=float(180+ph[i]+t*(ph[i+1]-ph[i])),direction='down' if g[i]>0 else 'up'))
   log=(d/'sim.log').read_text();op={k:float(v) for k,v in re.findall(r'^(v\(op\)|i\(vdd\))\s*=\s*([-+\d.eE]+)',log,re.M)}
   rec.update(gain_dB=float(g[0]),dc_phase_deg=float(ph[0]),crossings=crossings,PM_deg=min((x['pm'] for x in crossings),default=None),UGF_MHz=max((x['f_MHz'] for x in crossings if x['direction']=='down'),default=None),out_V=op.get('v(op)'),power_uW=-kw.get('vdd',5)*op['i(vdd)']*1e6)
  if mode=='tran':
   fd=arch not in ['baseline','baseline_schematic','class_ab'];edges=[(10e-6,39e-6,3.5),(40.01e-6,69e-6,1.5)];sett=[];err=[];cmerr=[];differr=[]
   for start,end,target in edges:
    final=float(np.mean(a[(a[:,0]>end-2e-6)&(a[:,0]<end),2]));mask=(a[:,0]>=start)&(a[:,0]<end);tt=a[mask,0];yy=a[mask,2];bad=np.where(abs(yy-final)>.002)[0];sett.append(float((tt[bad[-1]+1]-start)*1e6) if len(bad) and bad[-1]+1<len(tt) else (0 if not len(bad) else None));err.append(abs(final-target)*1000)
    if fd:
     finalm=float(np.mean(a[(a[:,0]>end-2e-6)&(a[:,0]<end),3]));yy=a[mask,3];bad=np.where(abs(yy-finalm)>.002)[0];sett.append(float((tt[bad[-1]+1]-start)*1e6) if len(bad) and bad[-1]+1<len(tt) else (0 if not len(bad) else None));err.append(abs(finalm-(5-target))*1000);cmerr.append(abs((final+finalm)/2-2.5)*1000);differr.append(abs(final-finalm-(2 if target==3.5 else -2))*1000)
   rec.update(settling_us=max(sett) if all(x is not None for x in sett) else None,static_error_mV=max(err),peak_supply_uA=float(-a[:,4].min()*1e6))
   if fd:rec.update(common_mode_error_mV=max(cmerr),differential_error_mV=max(differr))
 except Exception as e:rec['error']=str(e)
 return rec

def save(name,rows):
 (R/(name+'.json')).write_text(json.dumps(rows,indent=2))
 with (R/(name+'.csv')).open('w') as f:
  w=csv.DictWriter(f,fieldnames=list(dict.fromkeys(k for row in rows for k in row)));w.writeheader();w.writerows(rows)

if __name__=='__main__':
 shutil.copy2(OLD,R/'models/baseline_C.spice')
 jobs=[]
 for arch in ['baseline','fully_diff','telescopic','folded','gain_boosted','class_ab']:
  pars=({'nb':1.4} if arch=='folded' else {'nb':1.1} if arch=='gain_boosted' else {})
  jobs.append((arch,'initial',pars))
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:rows=list(ex.map(lambda j:execute(*j),jobs))
 save('initial',rows)
 for x in rows:print(x,flush=True)
