import study as s
from pathlib import Path
import concurrent.futures, itertools,json,subprocess
import numpy as np
R=s.R
PARS={'baseline':{},'fully_diff':{},'telescopic':{'nb':2.4,'pb':2.8},'folded':{'nb':1.4,'pb':2.8},'gain_boosted':{'nb':1.1,'pb':3.8},'class_ab':{'cap':10,'kbuf':8}}

def loops(arch,kind,**kw):
 tag='loop_'+kind+('_'+'_'.join(str(v) for v in kw.values()) if kw else '')
 d=R/'results'/arch/tag;d.mkdir(parents=True,exist_ok=True)
 text=s.make(arch,**PARS[arch])
 if kind=='cmfb':
  text=text.replace('MSP 0 op','MSP 0 sop').replace('MSM 0 om','MSM 0 som')
  text=text.replace('.ends dut','LCMP op sop 1e12\nLCMM om som 1e12\nCCMP sop inject 1u\nCCMM som inject 1u\nVINJECT inject 0 dc 0 ac 1\n.ends dut')
  output='(v(op)+v(om))/2';gate=None
 else:
  output=kind;gate='testgate'
  # Only cascode gate changes; auxiliary amplifier output stays at its original node.
  text=text.replace('om '+kind+' nx1','om testgate nx1').replace('op '+kind+' nx2','op testgate nx2').replace('om '+kind+' px1','om testgate px1').replace('op '+kind+' px2','op testgate px2')
 if gate:
  assert gate in text
  text=text.replace('.ends dut',f'LLOOP {output} {gate} 1e12\nCLOOP {gate} inject 1e12\nVINJECT inject 0 dc 0 ac 1\n.ends dut')
 model=d/'dut.spice';model.write_text(text)
 tb=s.bench(arch,model,**kw).replace('dc 0 ac 1','dc 0 ac 0')
 tb=tb.replace('ac dec 100 0.001 1G','ac dec 100 100 1G')
 # VCM and differential commands remain fixed; injection source is inside the DUT.
 expression=output if kind=='cmfb' else 'v(xu.'+output+')'
 tb=tb.replace('let gr=real(v(od))','let gr=-real('+expression+')').replace('let gi=imag(v(od))','let gi=-imag('+expression+')')
 (d/'tb.cir').write_text(tb)
 rec=dict(arch=arch,loop=kind,**kw,status='FAILED')
 try:
  p=subprocess.run(['ngspice','-b','-o','sim.log','tb.cir'],cwd=d,capture_output=True,timeout=90)
  a=np.loadtxt(d/'ac.dat',skiprows=1);assert p.returncode==0
  h=a[:,1]+1j*a[:,2];g=20*np.log10(abs(h));ph=np.unwrap(np.angle(h))*180/np.pi;cross=[]
  for i in np.where(g[:-1]*g[1:]<0)[0]:
   f=-g[i]/(g[i+1]-g[i]);cross.append(dict(f_MHz=float(10**(np.log10(a[i,0])+f*np.log10(a[i+1,0]/a[i,0]))/1e6),PM_deg=float(180+ph[i]+f*(ph[i+1]-ph[i]))))
  rec.update(status='OK',gain_dB=float(g[0]),crossings=cross,min_PM_deg=min((x['PM_deg'] for x in cross),default=None))
 except Exception as e:rec['error']=str(e)
 return rec

if __name__=='__main__':
 jobs=[]
 # Five native MOS corners, supply/temperature endpoints, and load endpoints.
 for arch,pars in PARS.items():
  for mos,vdd,temp,cl in itertools.product(['tntp49_5v','bnbp49_5v','bnwp49_5v','wnbp49_5v','wnwp49_5v'],[4.5,5.5],[0,85],[1,10]):
   kw=dict(mos=mos,vdd=vdd,temp=temp,cl=cl)
   jobs.append((arch,f"pvt_{mos}_{vdd}_{temp}_{cl}",pars,kw))
  jobs.append((arch,'nominal',pars,dict(cl=5)))
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
  rows=list(ex.map(lambda j:s.execute(j[0],j[1],j[2],**j[3]),jobs))
 s.save('ac_screen',rows);print('AC completed',len(rows),flush=True)
 jobs=[]
 for arch,pars in PARS.items():
  for cl in [5,10]:jobs.append((arch,'tran_'+str(cl),pars,'tran',dict(cl=cl)))
  for vo in [1.5,3.5]:jobs.append((arch,'out_'+str(vo),pars,'ac',dict(vo=vo,cl=10)))
  if arch not in ['baseline','class_ab']:
   jobs.append((arch,'cm_disturbance',pars,'cm',{}));jobs.append((arch,'dc_swing',pars,'dc',{}))
   jobs.append((arch,'inputcm_2p5',pars,'ac',dict(vin=2.5)))
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:extra=list(ex.map(lambda j:s.execute(j[0],j[1],j[2],mode=j[3],**j[4]),jobs))
 s.save('extra_checks',extra);print('Extras completed',len(extra),flush=True)
 jobs=[(arch,'cmfb') for arch in PARS if arch not in ['baseline','class_ab']]+[('gain_boosted',x) for x in ['gn1','gn2','gp1','gp2']]
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:l=list(ex.map(lambda j:loops(*j),jobs))
 s.save('loop_checks',l);print('Loops',l,flush=True)
 for arch in PARS:
  rr=[x for x in rows if x['arch']==arch];nom=next(x for x in rr if x['tag']=='nominal');ok=[x for x in rr if x['status']=='OK' and x['PM_deg'] is not None]
  print(arch,'nominal',nom,'minPM',min((x['PM_deg'] for x in ok),default=None),'failures',len(rr)-len(ok),flush=True)
