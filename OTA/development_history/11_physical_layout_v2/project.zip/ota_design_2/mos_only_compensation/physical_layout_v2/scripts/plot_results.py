from pathlib import Path
import json,numpy as np,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parents[1];fig,axs=plt.subplots(2,2,figsize=(12,8))
for variant,label,style in [('schematic','Schematic','-'),('C_extracted','Compact layout + extracted C','-'),('RC_diagnostic','Compact RC: diagnostic','--'),('old_layout_RC_diagnostic','Original RC: diagnostic',':')]:
 a=np.loadtxt(R/'simulations'/variant/'ac_cl5_v2.5.dat',skiprows=1);t=np.loadtxt(R/'simulations'/variant/'large.dat',skiprows=1)
 axs[0,0].semilogx(a[:,0],a[:,1],style,label=label);axs[0,1].semilogx(a[:,0],a[:,2],style,label=label);axs[1,0].plot(t[:,0]*1e6,t[:,2],style,label=label)
v=json.loads((R/'pex/capacitance_comparison.json').read_text());x=np.arange(2)
for k,r in enumerate(v):axs[1,1].bar(x+(k-.5)*.35,[r['N2_ground_fF'],r['OUT_ground_fF']],width=.35,label=r['layout'])
axs[1,1].set_xticks(x,['N2','OUT']);axs[1,1].set(ylabel='Extracted ground C (fF)',title='Import-adjusted extraction; well-junction C omitted')
axs[0,0].set(xlim=(1e3,1e8),xlabel='Frequency (Hz)',ylabel='Gain (dB)');axs[0,1].set(xlim=(1e4,1e8),xlabel='Frequency (Hz)',ylabel='Phase (degrees)');axs[1,0].set(xlim=(9.5,15),xlabel='Time (us)',ylabel='Output (V)',title='2 V follower step; explicit load 5 pF')
for ax in axs.flat:ax.grid(alpha=.25);ax.legend(fontsize=7)
fig.suptitle('Exploratory extracted-layout simulations: 5 V, 27 C; not qualified full RC');fig.tight_layout();fig.savefig(R/'plots/extracted_comparison.png',dpi=180);fig.savefig(R/'plots/extracted_comparison.pdf')
