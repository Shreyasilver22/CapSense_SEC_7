from pathlib import Path
import json,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle,Patch
R=Path(__file__).resolve().parents[1];data=json.loads((R/'verification/geometry.json').read_text())
colors={1:'#ac87cc',3:'#d7c6e3',2:'#53b966',5:'#ffcda0',6:'#f8b56a',4:'#dc5454',8:'#5599dd',10:'#d3bc40',7:'#272727',9:'#7c512d'}
fig,axs=plt.subplots(3,1,figsize=(16,10),gridspec_kw={'height_ratios':[1.5,2,2]})
for ax in axs:
 for la in [3,1,5,6,2,4,8,10,7,9]:
  for layer,x1,y1,x2,y2 in data:
   if layer==la:ax.add_patch(Rectangle((x1,y1),x2-x1,y2-y1,facecolor=colors[la],alpha=.65 if la not in [7,9] else 1,linewidth=.15,edgecolor=colors[la]))
 ax.set_aspect('equal');ax.set_xlabel('x (um)');ax.set_ylabel('y (um)')
axs[0].set_xlim(-5,380);axs[0].set_ylim(-8,255);axs[0].set_title('OTA design_2: compact MOS-compensated layout')
axs[1].set_xlim(65,375);axs[1].set_ylim(34,90);axs[1].set_title('ABBA input pair (left) and PMOS mirror (right)')
axs[2].set_xlim(65,340);axs[2].set_ylim(145,202);axs[2].set_title('Six isolated-well PMOS capacitor units; all bodies tied to OUT')
fig.legend(handles=[Patch(color=colors[l],label=n) for l,n in [(1,'N-well'),(2,'Active'),(4,'Poly'),(8,'Metal 1'),(10,'Metal 2'),(7,'Contact'),(9,'Via')]],loc='lower center',ncol=7)
fig.tight_layout(rect=[0,.04,1,1]);fig.savefig(R/'plots/layout_preview.png',dpi=170);fig.savefig(R/'plots/layout_preview.pdf')
