from pathlib import Path
import subprocess,re,json,csv
import numpy as np
R=Path(__file__).resolve().parents[1];D=R/'simulations';D.mkdir(exist_ok=True)
files={'schematic':R/'schematic/reference.cdl','drawn_devices':R/'pex/device_geometry_only.spice','C_extracted':R/'pex/ota_C_only.spice','RC_diagnostic':R/'pex/ota_extracted.spice','old_layout_RC_diagnostic':R/'baseline_v1/pex/ota_extracted.spice'}
model='/home/berson_meshak/pdk/scl08/ngspice_models49/mos/tntp49_5v'
def common(name,cl):return f'''OTA layout comparison: {name}
.include "{model}"
.include "{files[name]}"
.temp 27
.options reltol=1e-5 vntol=1e-8 abstol=1e-12 numdgt=12
VDD vdd 0 5
IREF vdd bias 2.5u
CL out 0 {cl}p
XU inp inn out vdd 0 bias ota_design2_mos
'''
def run(name,tag,s):
 d=D/name;d.mkdir(exist_ok=True);(d/(tag+'.cir')).write_text(s);p=subprocess.run(['ngspice','-b','-o',tag+'.log',tag+'.cir'],cwd=d,capture_output=True,text=True,timeout=90);assert p.returncode==0,(name,tag,p.stderr)
 return np.loadtxt(d/(tag+'.dat'),skiprows=1)
acs=[];trs=[]
for name in files:
 for cl,vc in [(5,2.5),(1,2.5),(10,2.5),(5,1.5),(5,3.5),(5,4)]:
  tag=f'ac_cl{cl}_v{vc}'
  s=common(name,cl)+f'''VIN inp 0 dc {vc} ac 1
LDC out inn 1e12
CAC inn 0 1e12
.control
set wr_singlescale
set wr_vecnames
op
print v(out) i(vdd)
ac dec 150 1 1G
let gd=db(v(out))
let pd=180/PI*cph(v(out))
wrdata {tag}.dat gd pd
quit
.endc
.end
'''
  a=run(name,tag,s);ix=np.where(a[:-1,1]*a[1:,1]<0)[0];pm=ugf=None
  if len(ix)==1:
   z=ix[0];f=-a[z,1]/(a[z+1,1]-a[z,1]);pm=float(180+a[z,2]+f*(a[z+1,2]-a[z,2]));ugf=float(10**(np.log10(a[z,0])+f*np.log10(a[z+1,0]/a[z,0]))/1e6)
  acs.append(dict(variant=name,CL_pF=cl,VC_V=vc,gain_dB=float(a[0,1]),UGF_MHz=ugf,PM_deg=pm,crossings=len(ix)))
 for lo,hi,tag in [(1.5,3.5,'large'),(2.5,2.6,'small')]:
  s=common(name,5)+f'''VIN inp 0 dc {lo} pulse({lo} {hi} 10u 10n 10n 40u 80u)
VFB inn out 0
.control
set wr_singlescale
set wr_vecnames
tran 2n 90u
wrdata {tag}.dat v(inp) v(out)
quit
.endc
.end
'''
  a=run(name,tag,s);sett=[]
  for start,end in [(10e-6,49e-6),(50.01e-6,89e-6)]:
   final=float(np.mean(a[(a[:,0]>end-2e-6)&(a[:,0]<end),2]));mask=(a[:,0]>=start)&(a[:,0]<end);tt=a[mask,0];yy=a[mask,2];bad=np.where(abs(yy-final)>.001*(hi-lo))[0];sett.append(float((tt[bad[-1]+1]-start)*1e6) if len(bad) and bad[-1]+1<len(tt) else None)
  trs.append(dict(variant=name,step=tag,settling_us=max(sett) if all(x is not None for x in sett) else None))
 print(name,acs[-6],trs[-2:],flush=True)
for n,rows in [('ac.csv',acs),('settling.csv',trs)]:
 with (D/n).open('w') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
(D/'summary.json').write_text(json.dumps({'ac':acs,'transients':trs,'RC_status':'Diagnostic only: Magic substrate resistance extraction reports errors. Neither C nor RC model includes qualified well-substrate junction extraction.'},indent=2))
