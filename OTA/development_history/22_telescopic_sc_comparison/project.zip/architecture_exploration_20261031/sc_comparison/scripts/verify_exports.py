from pathlib import Path
import subprocess,concurrent.futures,json
import numpy as np
R=Path(__file__).resolve().parents[1]
rows=json.loads((R/'nominal.json').read_text())
def verify(p):
 rec=dict(deck=p.name,status='FAILED')
 try:
  proc=subprocess.run(['ngspice','-b','-o',p.stem+'.log',p.name],cwd=p.parent,capture_output=True,timeout=180)
  arch,sw=p.stem.rsplit('_',1);row=next(x for x in rows if x['arch']==arch and x['switch']==sw and x['fs_Hz']==50000)
  a=np.loadtxt(p.parent/(p.stem+'.dat'),skiprows=1);b=np.loadtxt(R/'results'/row['name']/'transient.dat',skiprows=1)
  assert proc.returncode==0 and a.shape==b.shape
  assert np.allclose(a,b,rtol=1e-6,atol=1e-10)
  rec.update(status='PASS',rows=len(a))
 except Exception as e:rec['error']=str(e)
 return rec
if __name__=='__main__':
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:r=list(ex.map(verify,sorted((R/'tb').glob('*.cir'))))
 (R/'export_verification.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
