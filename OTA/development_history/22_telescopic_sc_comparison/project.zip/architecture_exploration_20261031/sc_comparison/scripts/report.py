import os
os.environ.setdefault('MPLCONFIGDIR','/tmp/sc_arch_mpl')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from pathlib import Path
import numpy as np,json,csv,hashlib
import simulate as s
R=s.R
nom=json.loads((R/'nominal.json').read_text());checks=json.loads((R/'checks.json').read_text());allrows=nom+checks
colors={'baseline':'#444444','telescopic':'#138868','gain_boosted':'#2470b8'}
labels={'baseline':'Current two-stage OTA','telescopic':'Telescopic + CMFB','gain_boosted':'Gain-boosted telescopic + CMFB'}
def select(rows=nom,**kw):return next(x for x in rows if all(x[k]==v for k,v in kw.items()))
def data(row):return np.loadtxt(R/'results'/row['name']/'transient.dat',skiprows=1)
def last_error(row):return (row['last_out_V']-3.3)*1000
nomrows=[]
for x in nom:
 nomrows.append({k:x[k] for k in ['arch','switch','fs_Hz','last_out_V','avg_VDD_power_uW','max_sample_error_mV','max_sum_error_mV','max_CM_error_mV','max_late_change_mV']}|dict(third_sample_error_mV=last_error(x)))
s.save('comparison',nomrows)
sens=[]
for x in checks:
 if x['delta_pF']<=0 or x['status']!='OK' or x['dt_ns']!=10:continue
 base=select(arch=x['arch'],switch=x['switch'],fs_Hz=x['fs_Hz']);expected=3*x['delta_pF']/7.5*1.8;actual=x['last_out_V']-base['last_out_V']
 sens.append(dict(arch=x['arch'],switch=x['switch'],fs_Hz=x['fs_Hz'],delta_pF=x['delta_pF'],expected_change_mV=expected*1000,measured_change_mV=actual*1000,change_error_uV=(actual-expected)*1e6,gain_error_percent=(actual/expected-1)*100))
s.save('sensor_sensitivity',sens)
fine=[]
for x in checks:
 if x['dt_ns']!=2 or x['status']!='OK' or x['delta_pF']!=0:continue
 base=select(arch=x['arch'],switch=x['switch'],fs_Hz=x['fs_Hz']);fine.append(dict(arch=x['arch'],switch=x['switch'],fs_Hz=x['fs_Hz'],third_sample_2ns_V=x['last_out_V'],third_sample_10ns_V=base['last_out_V'],change_uV=(x['last_out_V']-base['last_out_V'])*1e6,max_sample_error_2ns_mV=x['max_sample_error_mV']))
s.save('timestep_comparison',fine)
fine_sens=[]
for x in checks:
 if x['dt_ns']!=2 or x['delta_pF']!=.05:continue
 base=select(rows=checks,arch=x['arch'],switch=x['switch'],fs_Hz=x['fs_Hz'],dt_ns=2,delta_pF=0)
 coarse=next(y for y in sens if y['arch']==x['arch'] and y['switch']==x['switch'] and y['fs_Hz']==x['fs_Hz'] and y['delta_pF']==.05)
 actual=x['last_out_V']-base['last_out_V'];fine_sens.append(dict(arch=x['arch'],switch=x['switch'],fs_Hz=x['fs_Hz'],expected_change_mV=36,measured_change_2ns_mV=actual*1000,change_error_2ns_uV=(actual-.036)*1e6,change_error_10ns_uV=coarse['change_error_uV'],numerical_change_uV=(actual*1000-coarse['measured_change_mV'])*1000))
s.save('sensitivity_timestep_check',fine_sens)
plt.rcParams.update({'font.size':10,'axes.grid':True,'grid.alpha':.25})
fig,ax=plt.subplots(3,1,figsize=(11,10),sharex=True)
for a in colors:
 x=select(arch=a,switch='tg',fs_Hz=50000);d=data(x);tt=d[:,0]*1e6
 ax[0].plot(tt,d[:,1],color=colors[a],label=labels[a])
 ax[1].plot(tt,(d[:,2]-1.5)*1000,color=colors[a])
 if a!='baseline':ax[2].plot(tt,((d[:,1]+d[:,3])/2-2.5)*1000,color=colors[a])
expected=np.full(len(tt),1.5)
for frame in [0,1]:
 if frame:expected[tt>=(50+60+.4)]=1.5
 for k in range(3):expected[tt>=(50+frame*80+k*20+10.4)]=1.5+(k+1)*.6
ax[0].plot(tt,expected,'k--',lw=.9,label='Ideal settled staircase')
ax[0].set(ylabel='SC output (V)',title='Unchanged SC circuit, transistor switches, 50 kHz: nominal SCL800 models');ax[0].legend(ncol=2,fontsize=8)
ax[1].set(ylabel='Summing-node error (mV), zoom +/-100',ylim=(-100,100));ax[2].set(ylabel='Output CM error (mV), zoom +/-30',xlabel='Time (us)',xlim=(45,205),ylim=(-30,30))
fig.tight_layout();fig.savefig(R/'plots/sc_waveforms.png',dpi=170);fig.savefig(R/'plots/sc_waveforms.pdf');plt.close(fig)
fig,ax=plt.subplots(1,2,figsize=(11,4.7),sharex=True)
for a in colors:
 for j,sw in enumerate(['ideal','tg']):
  rows=sorted([x for x in nom if x['arch']==a and x['switch']==sw],key=lambda x:x['fs_Hz'])
  ax[j].plot([x['fs_Hz']/1000 for x in rows],[last_error(x) for x in rows],'o-',color=colors[a],label=labels[a])
for j,sw in enumerate(['Ideal switches','Transistor transmission gates']):ax[j].set(xlabel='Clock (kHz)',ylabel='Third sample error to 3.3 V (mV)',title=sw,xticks=[50,100,200]);ax[j].axhline(0,color='grey',lw=.7)
ax[0].legend(fontsize=8);fig.suptitle('Gain boosting reduces finite-gain error; switch-related error and high-clock settling remain')
fig.tight_layout();fig.savefig(R/'plots/clock_accuracy.png',dpi=170);fig.savefig(R/'plots/clock_accuracy.pdf');plt.close(fig)
fig,ax=plt.subplots(1,2,figsize=(11,4.7))
for a in ['telescopic','gain_boosted']:
 x=select(arch=a,switch='tg',fs_Hz=50000);d=data(x);ax[0].plot(d[:,0]*1e6,d[:,1],color=colors[a],label=labels[a]);ax[0].plot(d[:,0]*1e6,d[:,3],color=colors[a],ls='--')
for a in colors:
 x=select(arch=a,switch='tg',fs_Hz=50000);ax[1].bar(labels[a],x['avg_VDD_power_uW'],color=colors[a])
ax[0].set(xlabel='Time (us)',ylabel='Voltage (V)',title='Solid: SC output; dashed: complementary output',xlim=(48,113));ax[0].legend(fontsize=8)
ax[1].set(ylabel='Average modeled VDD power (uW)',title='50 kHz SC operation, excluding external drivers');ax[1].tick_params(axis='x',labelrotation=15,labelsize=8)
fig.tight_layout();fig.savefig(R/'plots/complement_and_power.png',dpi=170);fig.savefig(R/'plots/complement_and_power.pdf');plt.close(fig)

# Export portable nominal decks with unique data names; never modify simulated raw decks.
for a in ['baseline','telescopic','gain_boosted']:
 for sw in ['ideal','tg']:
  x=select(arch=a,switch=sw,fs_Hz=50000)
  text=(R/'results'/x['name']/'tb.cir').read_text().replace(str(R/'models'/f'{a}.spice'),f'../models/{a}.spice').replace('wrdata transient.dat',f'wrdata {a}_{sw}.dat')
  (R/'tb'/f'{a}_{sw}.cir').write_text(text)

def table(rows,columns,formats):
 text='| '+' | '.join(columns)+' |\n| '+' | '.join(['---']*len(columns))+' |\n'
 for row in rows:text+='| '+' | '.join(f(row) for f in formats)+' |\n'
 return text
nomtable=table([select(arch=a,switch=sw,fs_Hz=50000) for a in colors for sw in ['ideal','tg']],['OTA','Switches','Third sample (V)','Error (mV)','VDD power (uW)'],[lambda x:labels[x['arch']],lambda x:x['switch'],lambda x:f"{x['last_out_V']:.9f}",lambda x:f"{last_error(x):+.6f}",lambda x:f"{x['avg_VDD_power_uW']:.2f}"])
sens50=table([x for x in sens if x['fs_Hz']==50000 and x['delta_pF']==.05],['OTA','Switches','Expected change (mV)','Measured change (mV)','Gain error (%)'],[lambda x:labels[x['arch']],lambda x:x['switch'],lambda x:f"{x['expected_change_mV']:.3f}",lambda x:f"{x['measured_change_mV']:.6f}",lambda x:f"{x['gain_error_percent']:+.5f}"])
stress=[x for x in checks if x['mos']!='tntp49_5v']
stresstable=table(stress,['OTA','MOS file','VDD / temp / clock','Switches','Third sample error (mV)','Sampled CM error (mV)'],[lambda x:labels[x['arch']],lambda x:x['mos'],lambda x:f"{x['VDD']} V / {x['temp']} C / {x['fs_Hz']/1000:g} kHz",lambda x:x['switch'],lambda x:f"{last_error(x):+.4f}" if x['status']=='OK' else 'FAILED',lambda x:f"{x['max_CM_error_mV']:.3f}" if x.get('max_CM_error_mV') is not None else '-'])
fine_table=table(fine,['OTA','Switches','Clock (kHz)','2ns vs 10ns change (uV)'],[lambda x:labels[x['arch']],lambda x:x['switch'],lambda x:f"{x['fs_Hz']/1000:g}",lambda x:f"{x['change_uV']:+.4f}"])
failed=[x for x in allrows if x['status']!='OK']
R.joinpath('README.md').write_text(f'''# Same SC circuit: telescopic versus gain-boosted telescopic — 31 October 2026

Both exported OTA transistor models were actually run in ngspice 42 in the supplied single-ended switched-capacitor integrator. One output drives the original circuit; the other output remains internal to the OTA test setup and is controlled by its unchanged continuous-time CMFB. **A fully differential SC redesign was not required to perform this test.** The preceding differential-benchmark figures alone did not establish this connection's performance; these new tests do.

The original SC topology, switch dimensions, capacitor values, references and clock sequence were preserved. The current extracted-capacitance two-stage OTA was added as a reference. Neither OTA candidate was resized or retuned here.

## Assumptions and wiring

- SCL800 native MOS models; nominal `tntp49_5v`, VDD5 V,27 C, native typical RPP, ideal current reference3.5 uA.
- CS=2.5 pF plus sensor change; CF=7.5 pF; VREF=1.5 V; VP=0.3 V; active output load5 pF.
- Candidate noninverting input=VREF, inverting input=summing node, OUTP=SC output. OUTM is **not grounded or shorted to OUTP**; it receives an assumed5 pF load, and the existing CMFB targets `(OUTP+OUTM)/2=VDD/2`. Other-load0.1/10 pF and active-output10 pF tests were also run.
- NMOS W20/L3.2 reference diode supplies the candidates' bias mirror from the same3.5 uA source; this diode is included in VDD power.
- Phi1: TX->VP and RX->ground. Phi2: TX->ground and RX->summing node. CF remains between summing node and SC output; reset shorts CF.
- Same10 ns clock edges,43% phase duty, nonoverlap;50 us startup reset; two frames, three integration cycles per frame, reset between frames.
- Ideal-switch control: Ron100 ohm, Roff1e12. Actual-switch test: complementary N W10/L0.8 and P W20/L0.8 transmission gates, bodies0/VDD, ideal complementary clock generators. As in the prior SC deck, switch junction areas are left at their existing defaults; no switch/layout redesign or new extracted switch parasitics were introduced.

Expected ideal step is `CS/CF*(VP+VREF)=0.6 V`, so each frame should read1.5->2.1->2.7->3.3 V. The circuit integrates the full sensor capacitance; it does not intrinsically cancel its nominal baseline.

## Nominal50 kHz measured results

Third sample in the second frame; signed error is relative to3.3 V. This is raw output error, not baseline-subtracted sensor sensitivity.

{nomtable}
Gain boosting improves ideal-switch finite-gain behavior, but the transistor-switch raw errors remain close to57 mV for both. Thus extra OTA gain alone does not correct the dominant switch-related system error in this test. The two amplifiers need not have identical switch error because input capacitance, transient input error and clock coupling differ.

## Sensor response after offline baseline subtraction

For +50 fF, expected third-sample change is36 mV. These values subtract each design's own CS=2.5 pF result from its CS=2.55 pF result at the same clock and switch configuration. This is **offline calibration**, not an implemented cancellation circuit.

{sens50}
`sensor_sensitivity.csv` also retains +100 fF at50 kHz and +50 fF at100/200 kHz. Raw offset, calibrated sensor slope and dynamic settling are separate quantities. A large raw offset can coexist with an accurate calibrated slope. No ADC resolution or noise-limited sensitivity follows from these deterministic numbers.

## Clock and settling behavior

Clocks50/100/200 kHz were tested for all three OTAs with both switch models. At200 kHz, both cascode candidates acquire millivolt-scale ideal-switch sample errors and large remaining late-phase changes. Gain boosting does not remove the speed limit. A smaller raw transistor-switch error at200 kHz can reflect cancellation between offset and settling error, not improved operation.

`comparison.csv` gives all18 nominal tests. `samples` in the JSON records give each of the six samples, summing-node error, common-mode error and late-phase change. `tail_settling_us` is settling to within0.1% of the ideal single step (0.6 mV nominal) **of the simulated phase-end value**, not convergence to the ideal transfer. Late-phase change compares the last20 ns before phase end against0.15 period before phase end. These diagnostics do not constitute an asymptotic or PVT-qualified settling specification.

## Selected corner tests

VREF and VP stay1.5/0.3 V; CMFB reference followsVDD/2 and clock levels followVDD. Native MOS file names are retained rather than assuming modern corner labels. Temperature/supply endpoints are exploratory assumptions. Native resistor corner remains typical.

{stresstable}
At the low-supply/hot selected corner, the gain-boosted candidate has worse ideal-switch sample error than the ordinary telescopic candidate at50/100 kHz. Both show large common-mode error, around0.09 V with ideal switches and0.11 V with transistor switches. These observations require headroom/CMFB/bias investigation before layout; high nominal DC gain does not establish better corner accuracy. Additional25 kHz ideal-switch runs help distinguish clock-dependent error from a persistent operating-point limitation.

These are selected transient stress tests, not full PVT qualification, mismatch Monte Carlo or comprehensive feedback-loop certification. A completed simulation can still have unacceptable error, common-mode shift, saturation or insufficient settling. Inspect the table and traces before assigning a pass criterion; final ASIC accuracy requirements have not been fixed.

## Numerical checks

Main runs use10 ns maximum timestep. Selected cases were repeated at2 ns:

{fine_table}
The +50 fF transistor-switch sensitivity was also repeated at2 ns for both OTAs, subtracting a matching2 ns zero-change run. See`sensitivity_timestep_check.csv`. Differences of a few or tens of microvolts in calibrated slope must be judged against this numerical sensitivity; they do not establish a fabricated accuracy ranking.

The microvolt-scale ideal-switch results should be interpreted together with timestep changes and model limitations, not as fabricated microvolt accuracy.

Total saved simulations: {len(allrows)}; execution failures: {len(failed)}. Model hashes in`model_hashes.json` match the previously exported OTA circuits. Each run has its own deck, log, ASCII waveform and measurements JSON under`results/`.

## Design implication

The simple telescopic candidate is the stronger starting point for this SC interface: it already sharply reduces ideal-switch error relative to the current two-stage OTA, while gain boosting adds about46 uW and does not materially improve nominal speed or remove the transistor-switch error. Keep the gain-boosted version as a higher-gain option if a later accuracy budget establishes a need for it.

Before layout, verify the chosen operating range and selected corner behavior, improve the switching/readout error mechanism and check whether stable offset calibration is appropriate. CMFB sensing area and signal-dependent common-mode error also remain design work. This study does not select a tapeout-ready OTA or authorize changing the SC topology.

## Limits

- New cascode candidates are schematic-level with estimated MOS junction geometry and no routed RC/well/substrate extraction; baseline includes prior extracted routing capacitances. Bias/reference voltages are ideal. Matching, noise, PSRR, reference-generator/clock-driver power and noise are excluded. Existing SCL-HSPICE-to-ngspice ignored-parameter/noise qualification issues remain.
- The CMFB prototype uses two large1 Mohm poly resistors, source-follower sensing and MOS compensation; compact physical realization has not been demonstrated.
- CS and CF are ideal linear capacitors; this does not validate MOS caps as precision SC/SAR capacitors. Intentional internal OTA compensation remains the existing PMOS devices.
- The active load and unused-output load are assumed, and real sensor/package/ADC loading is not known. No new DRC/LVS, PEX, mismatch or noise verification was performed for these architectures.
- Power is averaged fromVDD over seven post-startup clock periods; excludes external VP/VREF/CM-reference and clock-driver power and a real current-reference generator.

## Files and reproduction

- `models/`: identical exported telescope/gain-boost circuits plus current-OTA extracted baseline; no PDK model cards redistributed.
- `tb/`: six portable nominal50 kHz decks, with relative local-model includes. From this folder run`ngspice -b -o telescopic_tg.log telescopic_tg.cir` or`gain_boosted_tg.cir`. PDK expected at`/home/berson_meshak/pdk/scl08/ngspice_models49`.
- All six exported decks were separately simulated and matched their original run data; see`export_verification.json`. PASS here confirms reproducibility of the export, not qualification against ASIC requirements.
- `scripts/simulate.py`, `checks.py`, `report.py`: regenerate the run grid and report. Raw generated decks preserve the original execution paths; regenerate them after relocating. Portable decks use relative model paths.
- `plots/sc_waveforms.png`, `clock_accuracy.png`, `complement_and_power.png`; PDF copies included.
- `nominal.json`, `checks.json`, `comparison.csv`, `sensor_sensitivity.csv`, `timestep_comparison.csv` preserve numerical results and conditions.
''')
(R/'hashes.json').write_text(json.dumps({str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for folder in ['models','scripts','tb'] for p in (R/folder).glob('*') if p.is_file()},indent=2))
print(nomtable);print(sens50);print('Simulation failures:',failed)
