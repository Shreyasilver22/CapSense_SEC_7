import simulate as s
import itertools,concurrent.futures
if __name__=='__main__':
 jobs=[]
 for a,sw,f in itertools.product(['telescopic','gain_boosted'],['ideal','tg'],[50000,100000,200000]):jobs.append(dict(arch=a,switch=sw,fs=f,delta=.05))
 for a,sw in itertools.product(['telescopic','gain_boosted'],['ideal','tg']):jobs.append(dict(arch=a,switch=sw,delta=.1))
 for a,other in itertools.product(['telescopic','gain_boosted'],[.1,10]):jobs.append(dict(arch=a,switch='tg',other_load=other))
 for a,sw in itertools.product(['telescopic','gain_boosted'],['ideal','tg']):jobs.append(dict(arch=a,switch=sw,dt=2))
 for a in ['telescopic','gain_boosted']:jobs.append(dict(arch=a,switch='tg',fs=200000,dt=2))
 for a,sw in itertools.product(['telescopic','gain_boosted','baseline'],['ideal','tg']):
  jobs.append(dict(arch=a,switch=sw,mos='wnwp49_5v',vdd=4.5,temp=85))
  jobs.append(dict(arch=a,switch=sw,mos='bnbp49_5v',vdd=5.5,temp=0))
 for a,sw in itertools.product(['telescopic','gain_boosted'],['ideal','tg']):jobs.append(dict(arch=a,switch=sw,fs=100000,mos='wnwp49_5v',vdd=4.5,temp=85))
 for a in ['telescopic','gain_boosted']:jobs.append(dict(arch=a,switch='tg',load=10))
 for a in ['telescopic','gain_boosted']:
  jobs.append(dict(arch=a,switch='tg',delta=.05,dt=2))
  jobs.append(dict(arch=a,switch='ideal',fs=25000,mos='wnwp49_5v',vdd=4.5,temp=85))
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:r=list(ex.map(lambda j:s.run(**j),jobs))
 s.save('checks',r)
