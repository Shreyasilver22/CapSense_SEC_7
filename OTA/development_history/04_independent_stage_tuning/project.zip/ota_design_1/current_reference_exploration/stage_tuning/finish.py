from pathlib import Path
import json,csv,subprocess,hashlib,shutil,re
import numpy as np
import tune
R=tune.R
j=json.loads((R/'results/summary.json').read_text())
rows=list(csv.DictReader((R/'results/transient_shortlist.csv').open()))
for r in rows:
 for k in r:r[k]=float(r[k])
checks=[]
for n,r in enumerate(rows):
 r['run']=int(r['run']);d=R/'results/runs'/f"{r['run']:04d}"
 for cl,vc in [(1,2.5),(10,2.5),(5,1.5),(5,3.5)]:
  dd=d/f'load{cl}_vc{vc}';dd.mkdir(exist_ok=True);tune.simulate(dd,'ac',tune.acnet(r,cl,vc));m=tune.acmetrics(dd);m['dc_error_mV']+=(2.5-vc)*1e3;checks.append(dict(run=r['run'],CL_pF=cl,VC_V=vc,**m))
 these=[c for c in checks if c['run']==r['run']]
 r['checked_all_single_crossing']=all(c['crossings']==1 and np.isfinite(c['PM_deg']) for c in these)
 r['checked_min_PM_deg']=min([r['PM_deg']]+[c['PM_deg'] for c in these]);r['checked_min_gain_dB']=min([r['gain_dB']]+[c['gain_dB'] for c in these]);r['checked_min_saturation_V']=min([r['minimum_saturation_margin_V']]+[c['minimum_saturation_margin_V'] for c in these])
 print(f'Load/output checks {n+1}/{len(rows)}',flush=True)
tune.writecsv(R/'results/load_output_checks.csv',checks);tune.writecsv(R/'results/validated_shortlist.csv',rows)
valid=[r for r in rows if r['checked_all_single_crossing'] and r['checked_min_PM_deg']>=60 and r['checked_min_gain_dB']>=80 and r['checked_min_saturation_V']>0 and np.isfinite(r['large_worst_dynamic_us'])]
# Record Pareto set; neither timing nor power has been frozen.
pareto=[r for r in valid if not any(q['power_uW']<=r['power_uW'] and q['large_worst_dynamic_us']<=r['large_worst_dynamic_us'] and (q['power_uW']<r['power_uW'] or q['large_worst_dynamic_us']<r['large_worst_dynamic_us']) for q in valid)]
# No assertion that an incompletely specified system has a single optimum.
nominal=[r for r in rows if r['gain_dB']>=80 and r['PM_deg']>=60 and r['minimum_saturation_margin_V']>0]
choices=valid or nominal
samepower=[r for r in choices if r['power_uW']<=j['control']['power_uW']]
highgain=[r for r in choices if r['gain_dB']>=85]
selected=min(highgain or choices,key=lambda r:r['large_worst_dynamic_us'])
fast=min(choices,key=lambda r:r['large_worst_dynamic_us']);low=min(choices,key=lambda r:r['power_uW'])
j.update(validated_candidates=rows,checked_pass_count=len(valid),pareto=pareto,selected=selected,fastest_checked=fast,lowest_power_checked=low,selection_note='Fastest large-step dynamic settling among checked-screen candidates with nominal gain>=85 dB, if any; otherwise fastest checked-screen candidate. Checked screen is gain>=80dB, PM>=60deg and positive saturation margins at the specified load/output points; fallback to nominal screen if none pass.',model_sha256=hashlib.sha256(Path(tune.MODEL).read_bytes()).hexdigest())
# Tight-step repeat for selected point to bound settling extraction accuracy.
d=R/'results/selected_fine';d.mkdir(exist_ok=True);j['selected_fine_large']=tune.transient(selected,d,True,1)
# Frozen, readable netlist and schematic for the selected point.
li,lm,lo,k,cc=[selected[x] for x in ['LI_um','LM_um','LO_um','K','Cc_pF']]
widths={1:3.125*li,2:3.125*li,3:3.125*lm,4:3.125*lm,5:20,6:8.75*lo*k,7:12.5*lo*k,8:20}
lengths={1:li,2:li,3:lm,4:lm,5:3.2,6:lo,7:lo,8:3.2}
base=Path('/home/berson_meshak/final year project/ota/ota_design_1/current_reference_exploration/designs/ota_current_ref.sch').read_text()
for name in range(1,9):base=re.sub(r'(name=M'+str(name)+r' model=[NP] w=)[\d.]+u l=[\d.]+u',lambda m:m[1]+f'{widths[name]:g}u l={lengths[name]:g}u',base)
base=base.replace('value=20p',f'value={cc:g}p').replace('Cc = 20 pF',f'Cc = {cc:g} pF')
base=base[:base.index('T {SCL800 current-reference OTA')]+base[base.index('C {devices/nmos4.sym} 100 650'):]
base+=f'''T {{SCL800 OTA: device-group/current tuning candidate}} 0 -20 0 0 0.5 0.5 {{}}
T {{LI={li:g} um; LM={lm:g} um; LO={lo:g} um; bias L=3.2 um.
IREF={selected['IREF_uA']:g} uA; output stage width multiplier K={k:g}; Cc={cc:g} pF.
Exploratory single-ended candidate; ideal external current reference.}} 0 850 0 0 0.28 0.28 {{}}
'''
(R/'designs/ota_group_tuned.sch').write_text(base)
sym=Path('/home/berson_meshak/final year project/ota/ota_design_1/current_reference_exploration/designs/ota_current_ref.sym').read_text();(R/'designs/ota_group_tuned.sym').write_text(sym)
# Local xschem config, graph testbench retained for usability.
P=Path('/home/berson_meshak/final year project/ota/ota_design_1/current_reference_exploration')
(R/'xschemrc').write_text((P/'xschemrc').read_text())
s=(P/'tb/ota_current_ref_tb.sch').read_text().replace('ota_current_ref','ota_group_tuned').replace('value="5u"',f'value="{selected["IREF_uA"]:g}u"').replace('IREF = 5 uA; L = 3.2 um; Cc = 20 pF.',f'IREF={selected["IREF_uA"]:g} uA; LI/LM/LO={li:g}/{lm:g}/{lo:g} um; Cc={cc:g} pF; K={k:g}.')
(R/'tb/ota_group_tuned_tb.sch').write_text(s)
for kind,sub in [('ac',''),('small','small'),('large','large')]:
 source=R/'results/runs'/f'{selected["run"]:04d}'/sub/('ac.cir' if kind=='ac' else 'tran.cir');net=source.read_text().replace(str(R)+'/designs/ota_tuned.inc','../designs/ota_tuned.inc').replace('wrdata ac.dat','wrdata ../results/selected_ac.dat').replace('wrdata tran.dat',f'wrdata ../results/selected_{kind}.dat');(R/'tb'/f'selected_{kind}.cir').write_text(net)
(R/'results/summary.json').write_text(json.dumps(j,indent=2))
# Plots comparing the same precision/timing definitions.
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
fig,axs=plt.subplots(2,2,figsize=(12,8))
allrows=list(csv.DictReader((R/'results/ac_sweep.csv').open()));good=[r for r in allrows if float(r['gain_dB'])>=80 and float(r['PM_deg'])>=60]
axs[0,0].scatter([float(r['power_uW']) for r in good],[float(r['UGF_MHz']) for r in good],s=14,alpha=.5);axs[0,0].set(xlabel='Supply power (uW)',ylabel='UGF (MHz)',title='Nominal gain >=80 dB, PM >=60 deg')
for r,label in [(j['control'],'Previous all-long-channel'),(selected,'Selected group tuning'),(fast,'Fastest checked')]:
 dd=R/'results/runs'/f'{int(r["run"]):04d}';a=np.loadtxt(dd/'ac.dat',skiprows=1);t=np.loadtxt(dd/'large/tran.dat',skiprows=1)
 axs[0,1].semilogx(a[:,0],a[:,1],label=label);axs[1,0].plot(t[:,0]*1e6,t[:,2],label=label)
 axs[1,1].scatter(r['power_uW'],r['large_worst_dynamic_us'],s=70,label=label)
axs[0,1].set(xlabel='Frequency (Hz)',ylabel='Gain (dB)',xlim=(1,1e8));axs[1,0].set(xlabel='Time (us)',ylabel='Output (V)',xlim=(9,25));axs[1,1].set(xlabel='Supply power (uW)',ylabel='Worst 2 V step settling (us)',title='0.1% relative to final output')
for ax in axs.flat:ax.grid(alpha=.25)
for ax in [axs[0,1],axs[1,0],axs[1,1]]:ax.legend(fontsize=8)
fig.tight_layout();fig.savefig(R/'plots/comparison.png',dpi=180);fig.savefig(R/'plots/comparison.pdf');plt.close(fig)
print(json.dumps({x:j[x] for x in ['checked_pass_count','selected','fastest_checked','lowest_power_checked','selected_fine_large']},indent=2))
