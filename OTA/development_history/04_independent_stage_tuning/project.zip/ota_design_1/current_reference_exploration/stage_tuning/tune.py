from pathlib import Path
import itertools,subprocess,re,csv,json,os
import numpy as np
R=Path(__file__).resolve().parent
for p in ['designs','tb','results/runs','plots']: (R/p).mkdir(parents=True,exist_ok=True)
MODEL='/home/berson_meshak/pdk/scl08/ngspice_models49/mos/tntp49_5v'
CORE='''* Device-group sizing; W/L fixed within each length group.
* K scales BOTH M6 and M7 W/L, preserving approximate second-stage DC balance.
* Nominal output/tail current ratio = 2*K; measured ratios are reported.
.subckt ota_tuned inp inn out vdd vss iref params: LI=3.2u LM=3.2u LO=3.2u K=1 CC=20p
M1 n1 inn tail vss N W={3.125*LI} L={LI}
M2 n2 inp tail vss N W={3.125*LI} L={LI}
M3 n1 n1 vdd vdd P W={3.125*LM} L={LM}
M4 n2 n1 vdd vdd P W={3.125*LM} L={LM}
M5 tail iref vss vss N W=20u L=3.2u
M6 out n2 vdd vdd P W={8.75*LO*K} L={LO}
M7 out iref vss vss N W={12.5*LO*K} L={LO}
M8 iref iref vss vss N W=20u L=3.2u
Cc n2 out {CC}
.ends ota_tuned
'''
(R/'designs/ota_tuned.inc').write_text(CORE)
def simulate(d,name,net):
 (d/f'{name}.cir').write_text(net)
 p=subprocess.run(['ngspice','-b','-o',f'{name}.log',f'{name}.cir'],cwd=d,capture_output=True,text=True,timeout=40)
 if p.returncode or not (d/f'{name}.dat').exists():raise RuntimeError(str(d)+' '+name+' '+p.stdout+p.stderr)
def common(r,cl=5):
 return f'''SCL800 grouped sizing run {r['run']}
.include "{MODEL}"
.include "{R}/designs/ota_tuned.inc"
.temp 27
.options reltol=1e-5 vntol=1e-8 abstol=1e-12 numdgt=12
VDD vdd 0 5
IREF vdd bias {r['IREF_uA']}u
CL out 0 {cl}p
XU inp inn out vdd 0 bias ota_tuned LI={r['LI_um']}u LM={r['LM_um']}u LO={r['LO_um']}u K={r['K']} CC={r['Cc_pF']}p
'''
def acnet(r,cl=5,vc=2.5):
 return common(r,cl)+f'''VIN inp 0 dc {vc} ac 1
LDC out inn 1e12
CAC inn 0 1e12
.control
set wr_singlescale
set wr_vecnames
op
print v(out) v(bias) i(vdd)
'''+''.join(f'print @m.xu.m{i}[vds] @m.xu.m{i}[vdsat] @m.xu.m{i}[id]\n' for i in range(1,9))+'''ac dec 100 1 1G
let gain_db=db(v(out))
let phase_deg=180/PI*cph(v(out))
wrdata ac.dat gain_db phase_deg
quit
.endc
.end
'''
def acmetrics(d):
 a=np.loadtxt(d/'ac.dat',skiprows=1);cross=np.where(a[:-1,1]*a[1:,1]<0)[0];pm=ugf=float('nan')
 if len(cross)==1 and a[cross[0],1]>0:
  z=cross[0];f=-a[z,1]/(a[z+1,1]-a[z,1]);pm=180+a[z,2]+f*(a[z+1,2]-a[z,2]);ugf=10**(np.log10(a[z,0])+f*np.log10(a[z+1,0]/a[z,0]))/1e6
 log=(d/'ac.log').read_text();vals={m[1]:float(m[2]) for m in re.finditer(r'^([^\s=]+)\s*=\s*([-+\d.eE]+)',log,re.M)}
 margins=[abs(vals.get(f'@m.xu.m{i}[vds]',float('nan')))-abs(vals.get(f'@m.xu.m{i}[vdsat]',float('nan'))) for i in range(1,9)]
 return dict(gain_dB=float(a[0,1]),UGF_MHz=ugf,PM_deg=pm,crossings=len(cross),power_uW=-5e6*vals['i(vdd)'],minimum_saturation_margin_V=min(margins),bias_V=vals['v(bias)'],dc_error_mV=(vals['v(out)']-2.5)*1e3,actual_output_tail_ratio=vals['@m.xu.m7[id]']/vals['@m.xu.m5[id]'])
def transient(r,d,large=False,step_ns=5):
 lo,hi=(1.5,3.5) if large else (2.5,2.6)
 net=common(r)+f'''VIN inp 0 dc {lo} pulse({lo} {hi} 10u 10n 10n 40u 80u)
VFB inn out 0
.control
set wr_singlescale
set wr_vecnames
tran {step_ns}n 90u
wrdata tran.dat v(inp) v(out) i(vdd)
quit
.endc
.end
'''
 simulate(d,'tran',net);t=np.loadtxt(d/'tran.dat',skiprows=1)
 vals={}
 for label,start,end,window,target in [('rise',10e-6,49e-6,(47e-6,49e-6),hi),('fall',50.01e-6,89e-6,(87e-6,89e-6),lo)]:
  vfinal=float(np.mean(t[(t[:,0]>window[0])&(t[:,0]<window[1]),2]));mask=(t[:,0]>=start)&(t[:,0]<end);tt=t[mask,0];yy=t[mask,2]
  for name,center in [('dynamic',vfinal),('total',target)]:
   bad=np.where(abs(yy-center)>.001*(hi-lo))[0];settle=float((tt[bad[-1]+1]-start)*1e6) if len(bad) and bad[-1]+1<len(tt) else (0.0 if not len(bad) else float('nan'));vals[label+'_'+name+'_us']=settle
  vals[label+'_static_error_mV']=(vfinal-target)*1e3
 vals['worst_dynamic_us']=max(vals['rise_dynamic_us'],vals['fall_dynamic_us'])
 return vals

def writecsv(path,rows):
 keys=list(dict.fromkeys(k for r in rows for k in r))
 with path.open('w') as f:w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rows)
if __name__=='__main__':
 rows=[]
 grid=itertools.product([1.6,2.4,3.2],[1.6,2.4,3.2],[1.6,2.4,3.2],[1,2,4,8],[2.5,5],[2.5,5,10,20])
 for k,(li,lm,lo,scale,ib,cc) in enumerate(grid):
  r=dict(run=k,LI_um=li,LM_um=lm,LO_um=lo,K=scale,IREF_uA=ib,Cc_pF=cc,gate_area_um2=6.25*(li*li+lm*lm)+21.25*lo*lo*scale+128)
  d=R/'results/runs'/f'{k:04d}';d.mkdir(exist_ok=True)
  simulate(d,'ac',acnet(r));r.update(acmetrics(d));rows.append(r)
  if (k+1)%100==0:print(f'AC sweep {k+1}/864',flush=True)
 writecsv(R/'results/ac_sweep.csv',rows)
 valid=[r for r in rows if r['gain_dB']>=80 and r['PM_deg']>=60 and r['crossings']==1 and r['minimum_saturation_margin_V']>0]
 # Transient shortlist spread across speed/power, including previous 85dB control.
 picks=[]
 for ordering in [sorted(valid,key=lambda r:-r['UGF_MHz']),sorted(valid,key=lambda r:r['power_uW']),sorted(valid,key=lambda r:r['power_uW']/r['UGF_MHz'])]:
  for r in ordering[:10]:
   if r not in picks:picks.append(r)
 control=next(r for r in rows if all(r[x]==v for x,v in dict(LI_um=3.2,LM_um=3.2,LO_um=3.2,K=1,IREF_uA=5,Cc_pF=20).items()))
 if control not in picks:picks.append(control)
 for n,r in enumerate(picks):
  d=R/'results/runs'/f"{r['run']:04d}"
  for large in [False,True]:
   dd=d/('large' if large else 'small');dd.mkdir(exist_ok=True);s=transient(r,dd,large);r.update({('large_' if large else 'small_')+k:v for k,v in s.items()})
  print(f'Transients {n+1}/{len(picks)}',flush=True)
 writecsv(R/'results/transient_shortlist.csv',picks)
 (R/'results/summary.json').write_text(json.dumps(dict(ac_runs=len(rows),screen_pass=len(valid),transient_runs=len(picks),control=control,fastest=sorted(picks,key=lambda r:r['large_worst_dynamic_us'])[:5],lowest_power=sorted(picks,key=lambda r:r['power_uW'])[:5]),indent=2))
 print((R/'results/summary.json').read_text(),flush=True)
