#!/usr/bin/env bash
set -euo pipefail
project_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$project_dir"
xschem -x -q -n -s --rcfile "$project_dir/xschemrc" -o "$project_dir/results" -N extracted.spice "$project_dir/designs/ota_group_tuned.sch"
xschem -x -q -n -s --rcfile "$project_dir/xschemrc" -o "$project_dir/results" -N ota_group_tuned_tb.spice "$project_dir/tb/ota_group_tuned_tb.sch"
cd "$project_dir/results"
ngspice -b -o ota_group_tuned_tb.log ota_group_tuned_tb.spice
cd "$project_dir"
python3 verify.py
python3 report.py
