from pathlib import Path
import json,re,subprocess,math
import numpy as np
import tune
R=tune.R;j=json.loads((R/'results/summary.json').read_text());r=j['selected']
s=(R/'results/extracted.spice').read_text()
expected={'M1':'n1 inn tail vss N','M2':'n2 inp tail vss N','M3':'n1 n1 vdd vdd P','M4':'n2 n1 vdd vdd P','M5':'tail iref vss vss N','M6':'out n2 vdd vdd P','M7':'out iref vss vss N','M8':'iref iref vss vss N'}
li,lm,lo,k=[r[x] for x in ['LI_um','LM_um','LO_um','K']]
widths=[3.125*li,3.125*li,3.125*lm,3.125*lm,20,8.75*lo*k,12.5*lo*k,20];lengths=[li,li,lm,lm,3.2,lo,lo,3.2]
for idx,(name,nodes) in enumerate(expected.items()):
 line=next(l for l in s.splitlines() if l.startswith(name+' '));assert line.split()[1:6]==nodes.split(),line
 assert f'w={widths[idx]:g}u l={lengths[idx]:g}u' in line,line
assert f'Cc out n2 {r["Cc_pF"]:g}p' in s
inc='\n'.join(line.replace('**.subckt','.subckt').replace('**.ends','.ends') for line in s.splitlines() if line!='.end');(R/'designs/selected_extracted.inc').write_text(inc)
net=tune.acnet(r).replace(str(R)+'/designs/ota_tuned.inc',str(R)+'/designs/selected_extracted.inc');net=re.sub(r'ota_tuned LI=.*?\n','ota_group_tuned\n',net)
d=R/'results/extracted_verification';d.mkdir(exist_ok=True);tune.simulate(d,'ac',net)
a=np.loadtxt(d/'ac.dat',skiprows=1);ref=np.loadtxt(R/'results/runs'/f'{r["run"]:04d}'/'ac.dat',skiprows=1);assert np.allclose(a,ref,rtol=1e-6,atol=1e-6)
log=(R/'results/ota_group_tuned_tb.log').read_text();assert 'No. of Data Rows' in log and 'Error' not in log
native=(R/'results/ota_group_tuned_tb.spice').read_text();assert f'IREF vdd iref {r["IREF_uA"]:g}u' in native
# Re-run selected portable benches to check file paths as delivered.
for kind in ['ac','small','large']:
 p=subprocess.run(['ngspice','-b','-o',f'../results/selected_{kind}.log',f'selected_{kind}.cir'],cwd=R/'tb',capture_output=True,text=True,timeout=40);assert p.returncode==0,p.stdout+p.stderr
# Strict JSON null means a settling band was never retained over the observation window.
def clean(x):
 if isinstance(x,float) and not math.isfinite(x):return None
 if isinstance(x,dict):return {k:clean(v) for k,v in x.items()}
 if isinstance(x,list):return [clean(v) for v in x]
 return x
j['verification']={'schematic_connectivity_geometry':'PASS: 8 MOS and Cc','extracted_ac_matches_parameterized_core':True,'native_follower_simulation':'PASS','portable_selected_testbenches':'PASS','fine_timestep_large_settling_delta_us':abs(j['selected_fine_large']['worst_dynamic_us']-r['large_worst_dynamic_us'])}
(R/'results/summary.json').write_text(json.dumps(clean(j),indent=2,allow_nan=False))
print(json.dumps(j['verification'],indent=2))
