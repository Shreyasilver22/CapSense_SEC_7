import json,csv,math,shutil
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parent;j=json.loads((R/'results/summary.json').read_text());s=j['selected'];f=j['fastest_checked'];l=j['lowest_power_checked'];b=j['control']
# Share readable netlists for alternative designs too.
for label,r in [('fastest',f),('lowest_power',l)]:
 for kind,sub in [('ac',''),('small','small'),('large','large')]:
  p=R/'results/runs'/f'{int(r["run"]):04d}'/sub/('ac.cir' if kind=='ac' else 'tran.cir');net=p.read_text().replace(str(R)+'/designs/ota_tuned.inc','../designs/ota_tuned.inc').replace('wrdata ac.dat',f'wrdata ../results/{label}_ac.dat').replace('wrdata tran.dat',f'wrdata ../results/{label}_{kind}.dat');(R/'tb'/f'{label}_{kind}.cir').write_text(net)
fig,axs=plt.subplots(2,2,figsize=(11,8));dd=R/'results/runs'/f'{int(s["run"]):04d}'
a=np.loadtxt(dd/'ac.dat',skiprows=1);axs[0,0].semilogx(a[:,0],a[:,2]);axs[0,0].set(xlabel='Frequency (Hz)',ylabel='Unwrapped phase (degrees)',title='Selected candidate, CL=5 pF, Vin=2.5 V')
checks=list(csv.DictReader((R/'results/load_output_checks.csv').open()));checks=[r for r in checks if int(r['run'])==int(s['run'])]
loads=[(1,next(float(r['PM_deg']) for r in checks if float(r['CL_pF'])==1)),(5,s['PM_deg']),(10,next(float(r['PM_deg']) for r in checks if float(r['CL_pF'])==10))]
axs[0,1].plot(*zip(*loads),'-o');axs[0,1].axhline(60,ls='--',color='k');axs[0,1].set(xlabel='CL (pF)',ylabel='Phase margin (degrees)',title='Load checks at 2.5 V')
t=np.loadtxt(dd/'small/tran.dat',skiprows=1);axs[1,0].plot(t[:,0]*1e6,t[:,2]);axs[1,0].plot(t[:,0]*1e6,t[:,1],ls='--');axs[1,0].set(xlabel='Time (us)',ylabel='Voltage (V)',xlim=(9.8,12),title='100 mV step; input dashed')
axs[1,1].plot(t[:,0]*1e6,(t[:,2]-t[:,1])*1e3);axs[1,1].axhline(.1,ls='--',color='k');axs[1,1].axhline(-.1,ls='--',color='k');axs[1,1].set(xlabel='Time (us)',ylabel='Output minus input (mV)',xlim=(11,15),ylim=(-.4,.2),title='Static error prevents +/-100 uV total accuracy')
for ax in axs.flat:ax.grid(alpha=.25)
fig.tight_layout();fig.savefig(R/'plots/verification.png',dpi=180);fig.savefig(R/'plots/verification.pdf');plt.close(fig)
text='''# Design 1: independent device-group and stage-current tuning

28 October 2026. Nominal SCL CP8D 800 nm exploration. Earlier baseline and current-reference results remain unchanged. No GitHub push performed.

## Outcome

The selected compromise has higher gain, faster settling and more nominal stability margin than the previous all-long-channel candidate, at increased supply power and transistor area. A faster, lower-gain option and a slower, lower-power option remain available. No system-level optimum is claimed because final timing, feedback factor, noise, swing and power requirements remain open.

| Candidate | Gain at 1 Hz (dB) | UGF (MHz) | PM at 5 pF (deg) | Supply power (uW) | Worst 2 V step settling (us) |
|---|---:|---:|---:|---:|---:|
'''
for name,r in [('Previous all-long-channel control',b),('Selected high-gain compromise',s),('Fastest checked alternative',f),('Lowest-power checked alternative',l)]:
 text+=f"| {name} | {r['gain_dB']:.2f} | {r['UGF_MHz']:.3f} | {r['PM_deg']:.2f} | {r['power_uW']:.2f} | {r['large_worst_dynamic_us']:.3f} |\n"
text+=f'''
Settling above is to +/-0.1% of the step amplitude around the actual final output (2 mV band for a 2 V step), worst of rising/falling edges. Time starts at the beginning of each 10 ns input edge. The previous control was rerun under these definitions: small differences from the preceding report reflect timing reference, data precision and waveform sampling. Selected large-step total-error settling to the ideal input is {s['large_rise_total_us']:.3f}/{s['large_fall_total_us']:.3f} us. Selected 100 mV dynamic settling is {s['small_rise_dynamic_us']:.3f}/{s['small_fall_dynamic_us']:.3f} us. Its static follower error is approximately {s['small_rise_static_error_mV']:.3f} mV at 2.6 V and {s['small_fall_static_error_mV']:.3f} mV at 2.5 V; it therefore does NOT meet a +/-100 uV total-error band for the 100 mV test. High gain does not eliminate systematic offset. No offset calibration was added.

## Selected circuit and geometry

Seven-MOS single-ended core plus diode-connected M8. IREF={s['IREF_uA']:g} uA is sourced from VDD into M8; ideal reference branch included in supply power. L_input={s['LI_um']:g} um, L_mirror={s['LM_um']:g} um, L_output={s['LO_um']:g} um. Tail/reference devices retain 3.2 um length. Cc={s['Cc_pF']:g} pF, external CL=5 pF. K={s['K']:g} multiplies both M6 and M7 widths, preserving their approximate DC balance while increasing output drive. This is a mirror geometry multiplier, not a guaranteed current ratio. Measured output/tail current ratio is {s['actual_output_tail_ratio']:.2f}, versus nominal geometry ratio 2*K={2*s['K']:g}.

| Devices | W (um) | L (um) |
|---|---:|---:|
| M1, M2 input pair | 7.5 | 2.4 |
| M3, M4 PMOS mirror | 10 | 3.2 |
| M5 tail, M8 reference | 20 | 3.2 |
| M6 PMOS output | 112 | 3.2 |
| M7 NMOS output sink | 160 | 3.2 |

Gate-area proxy sum(W*L)={s['gate_area_um2']:.1f} um^2, compared with {b['gate_area_um2']:.1f} um^2 for the control. Cc falls from 20 to 3 pF. Total layout area cannot be inferred without capacitor density, contacts, device folding and routing. Legal geometry/model qualification must still be checked with process documentation.

## Search and validation

- Initial grid: 864 AC points. LI/LM/LO independently 1.6,2.4,3.2 um; K=1,2,4,8; IREF=2.5,5 uA; Cc=2.5,5,10,20 pF. Within each group widths track length to maintain base W/L before K is applied. M5/M8 stay fixed.
- Refinement: 72 additional AC points. LI/LM=2.4,3.2 um; LO=3.2 um; K=2,4,6; IREF=2.5,5 uA; Cc=3,4,6 pF. Total 936 sizing/compensation points.
- 49 shortlisted points received both 100 mV and 2 V follower transients. Shortlist spans fastest UGF, low power, power/bandwidth tradeoff, high-gain refinement and the prior control; it is not exhaustive transient evaluation of all points.
- All 49 shortlisted points received extra AC checks at CL=1 and 10 pF at Vin=2.5 V, plus Vin=1.5 and 3.5 V at CL=5 pF. These are five separate conditions including nominal, not a full Cartesian product of load and bias. They are not PVT corners or full swing qualification.
- {j['checked_pass_count']} shortlisted points passed gain>=80 dB, PM>=60 degrees, a single unity crossing and positive model-reported saturation margins across those conditions. Selected candidate is the fastest in large-step dynamic settling among these checked points with nominal gain>=85 dB. Faster and lower-power alternatives are retained. This is a documented screening preference, not a frozen system specification.
- Selected minimum checked phase margin={s['checked_min_PM_deg']:.2f} degrees; minimum checked gain={s['checked_min_gain_dB']:.2f} dB; minimum checked saturation margin={s['checked_min_saturation_V']:.3f} V.
- Selected large-step test repeated with 1 ns maximum timestep versus 5 ns: worst settling changes by {j['verification']['fine_timestep_large_settling_delta_us']*1000:.3f} ns. This supports numerical repeatability, not physical model accuracy.
- xschem extraction verified all eight MOS terminal connections, N/P models, W/L values and Cc value/endpoints. Extracted AC data agree with the parameterized core within tolerance. Native xschem follower testbench and delivered SPICE testbenches were netlisted/simulated successfully. GUI plotting was not tested in this headless environment.

AC uses a 1e12 H DC-feedback inductor and 1e12 F AC-ground capacitor, biasing at a follower operating point and opening AC feedback over the measured range. It is an estimate of follower return ratio, not a phase-specific switched-capacitor loop-injection measurement. All sign changes through unity are counted. Settings: nominal model deck, 5 V, 27 C; reltol=1e-5, vntol=1e-8, abstol=1e-12, numdgt=12; AC 100 points/decade from 1 Hz to 1 GHz. Transient observations span 90 us with 40 us input plateaus. Plateau means near their end establish the settled value. CSV NaN / JSON null means the error band was not retained within the observation window.

## Open in xschem / run

From this stage_tuning folder:

```bash
xschem --rcfile xschemrc tb/ota_group_tuned_tb.sch
```

Ctrl-click Run simulation + plot. This demonstration uses the inherited 100 ns input rise/fall time; quantitative sweep testbenches use 10 ns. Open designs/ota_group_tuned.sch to inspect the selected transistor arrangement. The six pins are inp, inn, out, vdd, vss, iref. Source IREF into iref; do not apply the old fixed VBN source there.

Selected, fastest and lowest-power plain SPICE testbenches are in tb/. Run them from tb, for example `ngspice -b -o ../results/selected_large.log selected_large.cir`. The private foundry model is referenced at its existing local location; no model cards are redistributed.

## Reproduce and files

1. `python3 tune.py` runs the initial grid and shortlist transients.
2. `python3 refine.py` adds refinement points and selected transients.
3. `python3 finish.py` performs load/output checks, selects candidates, creates schematic/testbenches and plots.
4. Netlist designs/ota_group_tuned.sch into results/extracted.spice, and tb/ota_group_tuned_tb.sch into results/ota_group_tuned_tb.spice with xschem using the local xschemrc; simulate the native testbench from results/.
5. `python3 verify.py` checks extraction, reruns selected benches and records numerical validation. `python3 report.py` creates this report, alternative testbenches and verification plots.

NumPy, Matplotlib, ngspice and xschem are required. Full run inputs/logs/data are under results/runs/. Main tables: ac_sweep.csv, refinement_ac.csv, transient_shortlist.csv, load_output_checks.csv, validated_shortlist.csv. summary.json records selection, alternatives, Pareto subset among checked shortlisted points, provenance hash and verification. plots/comparison.png/.pdf compares performance; verification.png/.pdf shows selected phase, load margins and total error. Keep initial and refinement sweeps for evidence; this is a bounded search, not a proof of a global optimum.

## Limitations and next decision

Existing ngspice warnings include ignored HSPICE parameters and PMOS capacitance entries. All dynamic results remain provisional pending a compatible, qualified SCL model flow. No noise, mismatch, extracted parasitics, PVT, reference-generator startup/drift/noise, PSRR, CMRR, actual SC sampled-error test, ADC kickback or common-mode-feedback design is included. Power includes the ideal reference branch but excludes overhead of a practical reference generator. Single-point DC saturation checks do not prove transient saturation throughout a swing. The circuit remains single-ended.

The selected 2 V settling time is still longer than the illustrative 2.45 us amplification window in the behavioral model; that window is not a confirmed requirement. The faster candidate offers a different power/gain tradeoff. Next compare both in an explicit SC feedback configuration with the actual feedback factor and sampling schedule, then evaluate offset/noise and model compatibility before choosing the architecture.
'''
(R/'README.md').write_text(text)
print('Report and plots written')
