import tune,itertools,json,numpy as np
R=tune.R
j=json.loads((R/'results/summary.json').read_text())
rows=[]
for idx,(li,lm,lo,k,ib,cc) in enumerate(itertools.product([2.4,3.2],[2.4,3.2],[3.2],[2,4,6],[2.5,5],[3,4,6])):
 r=dict(run=1000+idx,LI_um=li,LM_um=lm,LO_um=lo,K=k,IREF_uA=ib,Cc_pF=cc,gate_area_um2=6.25*(li*li+lm*lm)+21.25*lo*lo*k+128)
 d=R/'results/runs'/f"{r['run']:04d}";d.mkdir(exist_ok=True);tune.simulate(d,'ac',tune.acnet(r));r.update(tune.acmetrics(d));rows.append(r)
 if (idx+1)%36==0:print('Refinement AC',idx+1,flush=True)
tune.writecsv(R/'results/refinement_ac.csv',rows)
valid=[r for r in rows if r['gain_dB']>=80 and r['PM_deg']>=65 and r['minimum_saturation_margin_V']>0]
picks=[]
for cand in [sorted(valid,key=lambda r:-r['UGF_MHz'])[:8], sorted([r for r in valid if r['gain_dB']>=85],key=lambda r:-r['UGF_MHz'])[:6],sorted(valid,key=lambda r:r['power_uW']/r['UGF_MHz'])[:6]]:
 for r in cand:
  if r not in picks:picks.append(r)
for n,r in enumerate(picks):
 d=R/'results/runs'/f"{r['run']:04d}"
 for large in [False,True]:
  dd=d/('large' if large else 'small');dd.mkdir(exist_ok=True);r.update({('large_' if large else 'small_')+key:v for key,v in tune.transient(r,dd,large).items()})
 print('Refinement transient',n+1,len(picks),flush=True)
# Extend the reproducible shortlist before final evaluation.
import csv
old=list(csv.DictReader((R/'results/transient_shortlist.csv').open()))
for r in old:
 for key in r:r[key]=float(r[key])
tune.writecsv(R/'results/transient_shortlist.csv',[r for r in old if r['run']<1000]+picks)
j['refinement_ac_runs']=len(rows);j['refinement_transient_runs']=len(picks);(R/'results/summary.json').write_text(json.dumps(j,indent=2))
