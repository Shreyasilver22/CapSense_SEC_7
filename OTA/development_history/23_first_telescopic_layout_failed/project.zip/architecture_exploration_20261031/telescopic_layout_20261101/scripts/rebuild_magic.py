"""Rebuild the pinned headless extraction tool locally; no system package install."""
from pathlib import Path
import tempfile,subprocess,tarfile,hashlib,json
R=Path(__file__).resolve().parents[1]
archive=R/'tools/build_inputs/magic_ota_688.tar.gz'
assert hashlib.sha256(archive.read_bytes()).hexdigest()=='c78de4c83adc05467368d8dcbc5749bdc20ef1c3381ec4cbb70da8704a5cbae6'
prefix=Path('/tmp/magic_ota_tool')
with tempfile.TemporaryDirectory(prefix='ota_magic_build_') as tmp:
 tmp=Path(tmp);build=tmp/'source';headers=tmp/'headers';build.mkdir()
 with tarfile.open(archive) as tar:
  tar.extractall(build,filter='data')
 build=next(build.iterdir())
 subprocess.run(['dpkg-deb','-x',str(R/'tools/build_inputs/tk8.6-dev_8.6.14-1build1_amd64.deb'),str(headers)],check=True)
 log=R/'tools/rebuild.log'
 with log.open('w') as out:
  subprocess.run(['./configure','--prefix='+str(prefix),'--with-interpreter=tcl','--without-tk','--without-opengl','--without-cairo','--without-x','--disable-readline'],cwd=build,stdout=out,stderr=subprocess.STDOUT,check=True)
  defs=build/'defs.mak';text=defs.read_text().replace('CPPFLAGS               =','CPPFLAGS               = -I'+str(headers/'usr/include/tcl8.6')+' ');defs.write_text(text+'\nLIBS += -ltk8.6\n')
  for cmd in [['make','-j4'],['make','install']]:subprocess.run(cmd,cwd=build,stdout=out,stderr=subprocess.STDOUT,check=True)
print(subprocess.check_output([str(prefix/'bin/magic'),'--version'],text=True))
