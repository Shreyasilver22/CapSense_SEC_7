from pathlib import Path
import os,json,hashlib,subprocess
os.environ.setdefault('MPLCONFIGDIR','/tmp/telescopic_layout_mpl')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from matplotlib.collections import PatchCollection
import numpy as np
import sc_simulate as s
R=s.R
load=lambda p:json.loads((R/p).read_text())
nom=load('sc_nominal.json');diag=load('sc_diagnostics.json');loops=load('cmfb_comparison.json');geo=load('verification/geometry_summary.json');export=load('verification/model_export.json');verify=load('verification/summary.json');rc=load('verification/RC_setup.json')
allrows=nom+diag
def row(arch,switch,rows=nom):return next(x for x in rows if x['arch']==arch and x['switch']==switch)
def data(x):return np.loadtxt(R/'results'/x['name']/'transient.dat',skiprows=1)
cols={'schematic':'#17865c','layout_C':'#c33d45','diagnostic_no_res_body_C':'#d48a10'}
labels={'schematic':'Schematic reference','layout_C':'Layout C model','diagnostic_no_res_body_C':'Diagnostic: resistor ground C removed'}
summary=[]
for x in nom+[x for x in diag if x['arch']=='diagnostic_no_res_body_C']:
 summary.append(dict(model=x['arch'],switch=x['switch'],last_out_V=x['last_out_V'],third_sample_error_mV=(x['last_out_V']-3.3)*1000,max_sample_error_mV=x['max_sample_error_mV'],max_CM_error_mV=x['max_CM_error_mV'],out_max_V=x['max_out_V'],other_min_V=x['other_min_V'],other_max_V=x['other_max_V'],VDD_power_uW=x['avg_VDD_power_uW']))
s.save('comparison',summary)
plt.rcParams.update({'font.size':10,'axes.grid':True,'grid.alpha':.22})
fig,ax=plt.subplots(2,2,figsize=(12,8),sharex=True)
for j,sw in enumerate(['ideal','tg']):
 for model in ['schematic','layout_C']:
  d=data(row(model,sw));tt=d[:,0]*1e6;ax[0,j].plot(tt,d[:,1],c=cols[model],label=labels[model]);ax[1,j].plot(tt,((d[:,1]+d[:,3])/2-2.5)*1000,c=cols[model])
 expected=np.full(len(tt),1.5)
 for f in [0,1]:
  if f:expected[tt>=110.4]=1.5
  for k in range(3):expected[tt>=(50+f*80+k*20+10.4)]=1.5+(k+1)*.6
 ax[0,j].plot(tt,expected,'k--',lw=.8,label='Ideal settled staircase');ax[0,j].set(title='Ideal switches' if sw=='ideal' else 'Transistor transmission gates',ylabel='SC output (V)');ax[1,j].set(xlabel='Time (us)',ylabel='OTA common-mode error (mV)',xlim=(45,205));ax[0,j].legend(fontsize=8)
fig.suptitle('Same SC circuit: routed telescopic OTA loses CMFB control in the capacitance-extracted model')
fig.tight_layout();fig.savefig(R/'plots/sc_layout_comparison.png',dpi=170);fig.savefig(R/'plots/sc_layout_comparison.pdf');plt.close(fig)
fig,ax=plt.subplots(2,1,figsize=(10,7),sharex=True)
for x in loops:
 d=np.loadtxt(R/'results'/('cmfb_'+x['model'])/'ac.dat',skiprows=1);h=d[:,1]+1j*d[:,2]
 ax[0].semilogx(d[:,0],20*np.log10(abs(h)),label=labels[x['model']],color=cols[x['model']]);ax[1].semilogx(d[:,0],np.unwrap(np.angle(h))*180/np.pi,color=cols[x['model']])
ax[0].set(ylabel='CMFB return magnitude (dB)',title='CMFB sensing-gate injection: 5 V, 27 C, 5 pF per output');ax[0].axhline(0,color='grey',ls='--');ax[0].legend(fontsize=8)
ax[1].set(ylabel='CMFB return phase (degrees)',xlabel='Frequency (Hz)',xlim=(100,1e7));ax[1].axhline(-180,color='grey',ls='--')
fig.tight_layout();fig.savefig(R/'plots/cmfb_loop_comparison.png',dpi=170);fig.savefig(R/'plots/cmfb_loop_comparison.pdf');plt.close(fig)
rects=load('verification/geometry.json');palette={1:'#f2c273',2:'#57966a',3:'#f4da9c',4:'#c1534d',5:'#e0a49a',6:'#e6b4ae',7:'#222222',8:'#467fc2',9:'#252953',10:'#9271b4',36:'#c18c40',44:'#d77928'}
fig,ax=plt.subplots(1,2,figsize=(13,6))
for a in ax:
 for layer in [1,3,5,6,2,4,44,36,10,8,7,9]:
  boxes=[Rectangle((x1,y1),x2-x1,y2-y1) for la,x1,y1,x2,y2 in rects if la==layer]
  if boxes:a.add_collection(PatchCollection(boxes,facecolor=palette[layer],edgecolor='none',alpha=.50 if layer in [1,3,5,6,10] else .85,rasterized=True))
 a.set_aspect('equal');a.set(xlabel='um',ylabel='um')
ax[0].set(xlim=(-20,1930),ylim=(-20,1380),title=f'Actual GDS overview: {geo["area_mm2"]:.3f} mm2 bounding box')
ax[0].text(1000,1030,'Two 1 Mohm P-poly banks\n100 sections each',ha='center',bbox=dict(facecolor='white',alpha=.8,edgecolor='none'))
ax[0].text(350,680,'OTA + CMFB devices',ha='center',bbox=dict(facecolor='white',alpha=.8,edgecolor='none'))
ax[1].set(xlim=(130,500),ylim=(0,320),title='Device/contact/routing detail from the same GDS')
fig.suptitle('Telescopic OTA + buffered continuous-time CMFB; first-pass unoptimized macro layout')
fig.tight_layout();fig.savefig(R/'plots/layout.png',dpi=200);fig.savefig(R/'plots/layout.pdf');plt.close(fig)

# Reusable test decks retain relative model paths; main model includes physical bias diode.
(R/'tb').mkdir(exist_ok=True)
for model in ['schematic','layout_C']:
 for sw in ['ideal','tg']:
  x=row(model,sw);text=(R/'results'/x['name']/'tb.cir').read_text().replace(str(R/'models'/f'{model}.spice'),f'../models/{model}.spice').replace('wrdata transient.dat',f'wrdata {model}_{sw}.dat');(R/'tb'/f'{model}_{sw}.cir').write_text(text)
table='| Model | Switches | Third output (V) | Worst sampled error (mV) | Worst sampled CM error (mV) |\n|---|---|---:|---:|---:|\n'
for x in summary:table+=f"| {labels[x['model']]} | {x['switch']} | {x['last_out_V']:.6f} | {x['max_sample_error_mV']:.3f} | {x['max_CM_error_mV']:.3f} |\n"
pm={x['model']:x['min_PM_deg'] for x in loops};timesteps=[]
for x in diag:
 if x['dt_ns']!=2:continue
 old=row('layout_C',x['switch']);timesteps.append(dict(switch=x['switch'],max_error_10ns_mV=old['max_sample_error_mV'],max_error_2ns_mV=x['max_sample_error_mV'],third_output_difference_uV=(x['last_out_V']-old['last_out_V'])*1e6))
s.save('timestep_comparison',timesteps)
failed=[x for x in allrows+loops if x['status']!='OK']
status=dict(layout_DRC_markers=verify['DRC_markers'],layout_LVS_match=verify['LVS_match'],extracted_C_topology_LVS='MATCH',physical_macro_area_mm2=geo['area_mm2'],MOS_units=geo['MOS_units'],RPP_sections=geo['resistor_segments'],resistor_body_ground_C_pF=export['resistor_body_ground_C_pF'],schematic_CMFB_PM_deg=pm['schematic'],layout_C_CMFB_PM_deg=pm['layout_C'],diagnostic_without_body_ground_C_PM_deg=pm['diagnostic_no_res_body_C'],full_RC_qualified=False,RC_substrate_tile_errors=rc['substrate_tile_errors'],RC_missing_substrate_connections=rc['missing_substrate_connections'],SC_cases=len(allrows),CMFB_AC_cases=len(loops),execution_failures=len(failed),performance_status='FAIL: nominal C-extracted model has unstable CMFB; redesign needed before architecture acceptance')
(R/'verification/final_status.json').write_text(json.dumps(status,indent=2))
R.joinpath('README.md').write_text(f'''# Telescopic OTA layout and SC simulation — 1 November 2026

The ordinary telescopic OTA with buffered continuous-time CMFB was physically laid out, DRC/LVS checked, capacitance extracted, and actually simulated in the same single-ended SC circuit. **The layout passes connectivity/rule checks but the extracted-capacitance circuit fails stable common-mode control at nominal conditions.** This first-pass CMFB implementation should not proceed to fabrication.

Only the ordinary telescopic candidate was laid out in this step. The gain-boosted version is not claimed to have a verified layout; its shared CMFB concept should be corrected before investing in another macro.

## Physical implementation and checks

- Top cell: `ota_telescopic_layout`; actual GDS: `layout/ota_telescopic_layout.gds`.
- {geo['MOS_units']} physical MOS units, including integrated W20/L3.2 bias-reference diode and20 MOS compensation units. Original W/L and multiplicities retained; source/drain contact arrays were added. Single-poly/two-metal SCL08 layers, individual N-wells for output-tied PMOS capacitors, explicit well/substrate taps.
- Two native P-poly1 Mohm resistors:100 series sections each, sectionW2.4 um/L857.143 um. Each bank has approximately85.7 mm total resistor-body length. Geometry is snapped to the1 nm GDS database grid; extracted resistance agrees within the native LVS tolerance.
- Macro bounding box: {geo['bbox_um'][2]-geo['bbox_um'][0]:.3f} by {geo['bbox_um'][3]-geo['bbox_um'][1]:.3f} um = **{geo['area_mm2']:.6f} mm2**. This is an unoptimized floorplan bounding area, not a claimed minimum die area; resistor banks dominate the footprint.
- **DRC: {verify['DRC_markers']} markers** using the original unmodified local SCL CP8D KLayout deck.
- **LVS: MATCH** against the source-transistor reference with both1 Mohm resistors. Wrong-gate and wrong-width negative controls both fail as expected.
- **Extracted C-netlist topology: separately MATCHES the GDS in KLayout**, retaining all resistor sections after correcting the native tee-export issue.
- These are local-deck macro checks, not foundry signoff, full-chip density/pad/ESD qualification, or matching-optimized layout.

Ports are `INP INN OUTP OUTM VDD VSS IREF VCM VBN VBP`. The macro includes the reference diode; external current source feedsIREF. Cascode reference voltages remain external ideal supplies in the bench:VBN2.4 V andVBP=VDD-2.2 V. VCM=VDD/2. A fabricated reference generator and its power/noise are not included.

## Same SC testbench, nominal50 kHz

SCL800 native typical MOS and RPP,5 V,27 C,IREF3.5 uA. CS2.5 pF,CF7.5 pF,VP0.3 V,VREF1.5 V,OUTP5 pF,OUTM5 pF; identical switch sizes, timing, nonoverlap, reset and three-cycle integration sequence as the preceding SC comparison. Ideal expected output is1.5->2.1->2.7->3.3 V.

The OTA macro is layout extracted; the SC switches/sensor/feedback/load capacitors remain the original schematic models. This is not a layout extraction of the entire SC readout.

{table}
Worst errors cover all six settled sampling instants across two frames. The third output shown is the last sample of the second frame. Main runs use10 ns maximum timestep. The apparently smaller final transistor-switch error is not a valid improvement: it can arise from switch-error cancellation with the unstable common-mode trajectory. Full traces show output excursions close to the rails, and sampled common-mode errors approaching1.2 V with ideal switches.

## Cause and controlled diagnostic

The extraction estimates **{export['resistor_body_ground_C_pF']:.3f} pF total resistor-body ground capacitance**, approximately26.6 pF per1 Mohm bank. This parasitic was absent from the architectural schematic benchmark. The same physical resistance now drives substantial distributed capacitance and long high-impedance sensing routes.

Symmetric sensing-gate CMFB loop injection, with differential feedback closed and5 pF on each output, gives:

| Model | CMFB phase margin |
|---|---:|
| Schematic | {pm['schematic']:.2f} degrees |
| Extracted capacitance model | **{pm['layout_C']:.2f} degrees** |
| Diagnostic removing only resistor-body ground C | {pm['diagnostic_no_res_body_C']:.2f} degrees |

Removing exactly200 resistor-center ground-capacitor entries restores small SC errors in the diagnostic run, confirming that their contribution is dominant in this model. **This diagnostic is not a physical fix and is not an acceptable extracted model.** Its remaining CMFB margin is only about41 degrees, below our previous60-degree screening target; routing and other extracted capacitances also require attention. The injection result is an engineering loop diagnostic rather than a formal multi-loop pole-count/Nyquist certificate; the observed large transient oscillations independently support rejection of the nominal layout-C circuit.

Additional layout-C SC runs at5/25/100 kHz still show large errors. Lower clock alone does not cure the unstable continuous-time CMFB loop. Two2 ns repeats at50 kHz reproduce the failure; exact values are in`timestep_comparison.json`.

## Extraction validity and limitations

The simulation model is **capacitance-extracted, not qualified full interconnect/substrate RC**. It includes native MOS devices with extracted junction geometry, native200-section resistor bodies exported as400 half-resistor subcircuits, and{export['total_explicit_cap_count']} explicit capacitors. Resistance of those intentional P-poly bodies is included; distributed wire/contact/diffusion/well resistance is not qualified in this model.

Magic8.3.688 was rebuilt from the same pinned upstream source used previously. Original PDK files were not edited. As in the earlier OTA extraction work, temporary extraction-only adaptations omit raw marker paint that overwrites electrical device planes, retaining raw masks in boolean device derivation. The existing poly capacitance alias is extended to the resistor-body paint to include body capacitance. **This is an engineering extraction adaptation, not a foundry-qualified resistor-capacitance model.** The exact53 pF estimate needs PDK/extractor validation before treating it as a silicon prediction. It exposes a major sensitivity and prevents accepting the schematic result as layout-qualified.

Native ext2spice tee output forRPP drops one half. `export_models.py` restores both halves from actual`.ext` terminal/geometry records; independent numeric-resistor KLayout LVS verifies the corrected topology. The uncorrected`pex/ota_C_raw.spice` must not be used as a complete simulation model. Use`models/layout_C.spice`.

Shorted-source/drain PMOS capacitor extraction reports20 missing-terminal warnings and joins the remainder toOUTP/OUTM/VDD as appropriate. Their four-terminal connectivity was independently checked by the extracted-model LVS. These expected shorted-terminal warnings are not silently reinterpreted as full extractor qualification.

A separate full-RC attempt was actually made. It reports **{rc['substrate_tile_errors']} substrate-tile errors and{rc['missing_substrate_connections']} missing-substrate-connection messages**. Files under`pex/rc_diagnostic/` are unqualified and excluded from the performance simulations. No successful full-RC simulation or foundry signoff is claimed.

Existing SCL-HSPICE-to-ngspice ignored-parameter/noise limitations remain. No noise, mismatch, full PVT or reliability qualification was attempted for this nominally unstable layout. Testbench references and clock generators are ideal; CS/CF are ideal linear caps. No claim is made that MOS caps replace precision SC/SAR capacitors.

## Next design focus

Redesign the CMFB averaging/sensing network with a realistic parasitic and area budget. Investigate lower averaging resistance with suitably stronger, linear sensing buffers, a compact sensing topology, or clocked CMFB if its timing and charge-injection costs fit the system. Keep the high-impedance sense node and controller close in the revised layout. Re-extract and require both common-mode and signal-loop stability before continuing architecture selection. Increasing OTA gain or reducing the SC clock is not established as a solution to this failure.

## Reproduction and files

- `scripts/generate.py`: physical GDS and source-based reference generation; run using`klayout -b -r scripts/generate.py`.
- `scripts/verify.py`: original local SCL DRC/LVS and negative controls.
- `scripts/extract.py`: C extraction; `--rc` performs the separately recorded unqualified RC attempt. The system Magic8.3.105 is unchanged. If`/tmp/magic_ota_tool` is missing, run`scripts/rebuild_magic.py`; pinned source and Tk-header package are retained under`tools/build_inputs/`, requiring no system package installation. Upstream source:[Magic8.3.688](https://github.com/RTimothyEdwards/magic/releases/tag/8.3.688).
- `scripts/export_models.py`: native resistor tee correction, extracted-topology LVS, and same-interface schematic model.
- `scripts/run_sc.py`, `diagnose.py`, `check_cmfb.py`, `report.py`: actual SC/loop runs, diagnostics and report. Run extraction/model export before simulations; regenerate raw decks after relocating because they preserve original run paths.
- `tb/`: four standalone50 kHz SC decks using relative model paths. From this directory, run`ngspice -b -o layout_C_ideal.log layout_C_ideal.cir` or`layout_C_tg.cir`. PDK remains at`/home/berson_meshak/pdk/scl08/ngspice_models49`. Native PDK cards/decks are referenced, not redistributed.
- `plots/layout.png`, `sc_layout_comparison.png`, `cmfb_loop_comparison.png` plus PDFs.
- `verification/final_status.json`, DRC/LVS logs/databases,`comparison.csv`, `sc_nominal.json`, `sc_diagnostics.json`, `cmfb_comparison.json` retain the evidence.

SC runs:{len(allrows)}; CMFB AC runs:{len(loops)}; execution failures:{len(failed)}. Completion means data was generated, not that performance passed. Source/layout/model hashes are recorded in`hashes.json` and`verification/model_export.json`.
''')
hashes={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for folder in ['scripts','layout','models','schematic','tb'] for p in (R/folder).glob('*') if p.is_file()}
(R/'hashes.json').write_text(json.dumps(hashes,indent=2))
(R/'verification/tool_build.json').write_text(json.dumps(dict(version='Magic 8.3.688',source='https://github.com/RTimothyEdwards/magic/tree/8.3.688',archive_sha256=hashlib.sha256((R/'tools/build_inputs/magic_ota_688.tar.gz').read_bytes()).hexdigest(),system_magic='8.3.105 unchanged',rebuild='scripts/rebuild_magic.py'),indent=2))
print(json.dumps(status,indent=2));print(table)
