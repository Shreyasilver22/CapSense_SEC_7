import sc_simulate as s
import concurrent.futures,itertools
if __name__=='__main__':
 jobs=[dict(arch=a,switch=sw) for a,sw in itertools.product(['schematic','layout_C'],['ideal','tg'])]
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:r=list(ex.map(lambda j:s.run(**j),jobs))
 s.save('sc_nominal',r)
