from pathlib import Path
import json,shlex,itertools,concurrent.futures
import sc_simulate as s
R=s.R
if __name__=='__main__':
 raw=[shlex.split(x) for x in (R/'pex/ota_telescopic_layout.ext').read_text().splitlines()]
 bodies={x[10] for x in raw if x[:3]==['device','rsubckt','RPP']};out=[];removed=[]
 for line in (R/'models/layout_C.spice').read_text().splitlines():
  a=line.split()
  if a and a[0].startswith('C') and ((a[1] in bodies and a[2]=='0') or (a[2] in bodies and a[1]=='0')):removed.append(line);continue
  out.append(line)
 assert len(removed)==200,len(removed)
 (R/'models/diagnostic_no_res_body_C.spice').write_text('* DIAGNOSTIC ONLY: removed resistor-center ground C; never a physical signoff model.\n'+'\n'.join(out)+'\n')
 (R/'verification/diagnostic_removed_caps.json').write_text(json.dumps(removed,indent=2))
 jobs=[dict(arch='diagnostic_no_res_body_C',switch=sw) for sw in ['ideal','tg']]
 jobs += [dict(arch='layout_C',switch=sw,fs=f) for sw,f in itertools.product(['ideal','tg'],[5000,25000,100000])]
 jobs += [dict(arch='layout_C',switch=sw,dt=2) for sw in ['ideal','tg']]
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:r=list(ex.map(lambda j:s.run(**j),jobs))
 s.save('sc_diagnostics',r)
