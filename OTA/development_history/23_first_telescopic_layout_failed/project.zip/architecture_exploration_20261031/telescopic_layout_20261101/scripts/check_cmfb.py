from pathlib import Path
import subprocess,json,re
import numpy as np
import sc_simulate as s
R=s.R
def run(model):
 d=R/'results'/('cmfb_'+model);d.mkdir(exist_ok=True)
 text=(R/'models'/(model+'.spice')).read_text();ls=[];found=[]
 for line in text.splitlines():
  a=line.split()
  if a and a[0].startswith('M') and a[2] in ['OUTP','OUTM'] and re.search(r'\bw=40(?:\.0)?u\s+l=1\.6u',line,re.I):
   original=a[2];a[2]='SENSE_'+original;line=' '.join(a);found.append(original)
  if line.lower().startswith('.ends'):
   ls+=['LCMP OUTP SENSE_OUTP 1e12','LCMM OUTM SENSE_OUTM 1e12','CCMP SENSE_OUTP INJECT 1u','CCMM SENSE_OUTM INJECT 1u','VINJECT INJECT VSS dc 0 ac 1']
  ls.append(line)
 assert sorted(found)==['OUTM','OUTP'],found
 (d/'loop.spice').write_text('\n'.join(ls)+'\n')
 tb=f'''Symmetric CMFB sensing-gate injection, {model}
.include "{s.PDK}/mos/tntp49_5v"
.include "{s.PDK}/res/typ/ppr"
.include "{d}/loop.spice"
.options reltol=1e-5 vntol=1e-8 abstol=1e-12
.temp 27
VDD vdd 0 5
IREF vdd bias 3.5u
VCM vcm 0 2.5
VBN vbn 0 2.4
VBP vbp vdd -2.2
VIP inp 0 1.5
EFB inn 0 value={{1.5+v(outp)-v(outm)}}
XOTA inp inn outp outm vdd 0 bias vcm vbn vbp ota_telescopic_layout
CLP outp 0 5p
CLM outm 0 5p
.control
set wr_singlescale
set wr_vecnames
op
print v(outp) v(outm)
ac dec 120 100 1G
let gr=-real((v(outp)+v(outm))/2)
let gi=-imag((v(outp)+v(outm))/2)
wrdata ac.dat gr gi
quit
.endc
.end
'''
 (d/'tb.cir').write_text(tb);p=subprocess.run(['ngspice','-b','-o','sim.log','tb.cir'],cwd=d,capture_output=True,timeout=180)
 rec=dict(model=model,status='FAILED')
 try:
  a=np.loadtxt(d/'ac.dat',skiprows=1);assert p.returncode==0
  h=a[:,1]+1j*a[:,2];g=20*np.log10(abs(h));ph=np.unwrap(np.angle(h))*180/np.pi;cross=[]
  for i in np.where(g[:-1]*g[1:]<0)[0]:
   t=-g[i]/(g[i+1]-g[i]);cross.append(dict(f_MHz=float(10**(np.log10(a[i,0])+t*np.log10(a[i+1,0]/a[i,0]))/1e6),PM_deg=float(180+ph[i]+t*(ph[i+1]-ph[i]))))
  rec.update(status='OK',crossings=cross,min_PM_deg=min((x['PM_deg'] for x in cross),default=None))
 except Exception as e:rec['error']=str(e)
 print(rec,flush=True);return rec
if __name__=='__main__':
 rows=[run(x) for x in ['schematic','layout_C','diagnostic_no_res_body_C']]
 (R/'cmfb_comparison.json').write_text(json.dumps(rows,indent=2))
